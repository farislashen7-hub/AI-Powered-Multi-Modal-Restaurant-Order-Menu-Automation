# Setup
1. Supabase → SQL editor → run `supabase/schema.sql`.
2. Supabase → Auth → URL Configuration: Site URL `http://localhost:3000`, add Redirect `http://localhost:3000/auth/callback`.
3. `.env.local` from `.env.example`. Set a real `N8N_WEBHOOK_SECRET`.
4. `npm install && npm run dev`
5. Sign up, then run in SQL editor:
   `update public.profiles set role='admin' where id=(select id from auth.users where email='YOU@EMAIL.COM');`
6. n8n: Webhook node (POST) → IF `{{$json.headers['x-webhook-secret']}}` equals your secret → Switch on `{{$json.body.event}}`
   (`order.created`, `order.status_changed`, `user.signed_up`) → WhatsApp/Telegram/Email nodes.

# Update 2
- Run `supabase/migration_02_inventory_reports.sql` (after schema.sql): stock columns, atomic stock decrement, cancel restores stock, `sales_report()`.
- Hero video: put `hero.mp4` (H.264, muted, 10-15s loop, <8MB, 1080p or 720p) in `/public`. Optional: `hero.webm`, `hero-poster.jpg`.
- Video already in `/public` (hero.mp4, hero.webm, hero-poster.jpg, audio stripped). Used on home hero + login + signup via `components/VideoBackground.jsx`.

---
## Update: staff, extras, guest orders, invoice, security

**SQL order (Supabase → SQL Editor):**
`schema.sql` → `migration_02_inventory_reports.sql` → `migration_03_staff_extras.sql` → `migration_04_site_settings.sql` → `migration_05_login_lock.sql` → `migration_06_guest_orders.sql` → `migration_07_order_type.sql` → `migration_08_hardening.sql`
(`00_reset_old_tables.sql` DELETES all data — only for the old integer-id schema.)

**Env (.env.local + Vercel → Environment Variables):**
`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` (secret, server only),
`NEXT_PUBLIC_SITE_URL` (https://your-domain), optional `N8N_WEBHOOK_URL`, `N8N_WEBHOOK_SECRET`.

**Admin pages:** `/admin` orders · `/admin/menu` dishes + extras (multi-add) · `/admin/staff` roles · `/admin/settings` phone / address / Instagram / Facebook · `/admin/reports`.
Invoice: shown after checkout and at `/invoice/<order id>`.

After unzipping run `npm install` (Next.js upgraded to 14.2.35).

---
## Update: guest "طلباتي" + 12h window + cancel
Run `supabase/migration_09_guest_my_orders.sql` after migration_08. `/my-orders` is public (device cookie `rt_dev`), shows last 12h only. Cancel: pending = instant, preparing = request to staff via n8n.

## Staff-only signup
Customers order as guests (no account). `/signup` is for restaurant workers only.
1. Set `STAFF_SIGNUP_CODE` (min 8 chars, server env, also in Vercel). Empty = signup closed.
2. Supabase -> Authentication -> Sign In / Providers -> turn OFF "Allow new users to sign up" (accounts are created server-side with service_role, so this closes the public anon-key signup hole).
3. Worker opens `/signup`, enters name + email + password + code -> role `staff` set server-side, lands on `/admin`.
4. Code leaked? Change `STAFF_SIGNUP_CODE`, redeploy, set unwanted users to "موقوف" in `/admin/staff`.

---
## Update: reports + offers + delivery (migration_11)
Run `supabase/migration_11_reports_offers_delivery.sql` after migration_10.

**1) Reports (`/admin/reports`)**: top dish, top areas, avg order, delivery vs pickup, peak hours.
Checkout now asks for the **area** (delivery only) so areas can be ranked. Old orders show as "غير محدد".

**2) Offers (`/admin/offers`)**: owner adds an offer, sees the WhatsApp message live (left side), then "إرسال على واتساب".
Server builds message + recipients (past customers, last 90 days, distinct numbers) -> n8n webhook `res-offers`.
n8n: Webhook (POST, path `res-offers`) -> check `x-webhook-secret` -> Split Out `body.payload.recipients` -> Wait (random 8-20 s) -> IF `{{ $('Webhook').item.json.body.payload.has_image }}`:
- true  -> POST `{EVO}/message/sendMedia/{instance}` body `{ "number": "{{recipient}}", "mediatype": "image", "mimetype": "image/jpeg", "media": "{{ body.payload.media.media }}", "fileName": "offer.jpg", "caption": "{{ body.payload.media.caption }}" }`
- false -> Evolution API send text (`number` = recipient, `text` = `body.payload.message`).
(Image + caption = same look as the admin preview. Use JSON.stringify / expression mode for caption so newlines survive.)

**3) Delivery**: courier registers at `/signup` -> account type "مندوب توصيل" + staff code (phone required). Gets ID `D-001...`.
Courier screen `/delivery`: assigned orders, "تم التسليم" (only when staff set the order to "جاهز"), "خارج الخدمة" (returns his orders to the pool).
Staff/owner assign couriers from the order card in `/admin`. Owner manages couriers at `/admin/delivery`.
n8n webhook `res-Delivery` (case-sensitive) gets 3 events, Switch on `body.event`: `order.assigned`, `order.delivered`, `courier.out_of_service`.

**Env for n8n (local `.env.local` AND Vercel -> Settings -> Environment Variables, then redeploy):**
`N8N_WEBHOOK_BASE=https://<your-ngrok-domain>/webhook` (production URL, workflow must be Active; NOT `/webhook-test/`),
`N8N_WEBHOOK_SECRET=<same secret the n8n IF node checks>`, `N8N_PATH_OFFERS=res-offers`, `N8N_PATH_DELIVERY=res-Delivery`.

**3) Order an offer from the site**: run `supabase/migration_15_offer_orders.sql` once (after 14). Offer cards now have "أضف" and go through the normal cart/checkout (price, expiry, active read from DB).

**4) Offer look**: run `supabase/migration_16_offer_style.sql` once (after 15). In Admin > Offers the owner picks colors, layout (card / wide banner) and badge text, with a live preview.

**5) Free offer colors**: run `supabase/migration_17_offer_custom_colors.sql` once (after 16). In Admin > Offers > "شكل العرض" the owner can pick "ألوان حرّة" and choose background, text and button/badge colors with color pickers (badge/button text color is picked automatically for contrast).

---
## Update: WhatsApp chats in admin (migration_19)
Run `supabase/migration_19_whatsapp_chats.sql` once (after 18). New tab **/admin/chats** (admin + staff): every WhatsApp conversation, live.
- **تدخّل بشري**: AI goes silent for that customer, the composer opens, staff reply from the page.
- **المساعد الذكي**: gives the chat back to the AI. While in human mode the AI NEVER answers, until this button is pressed.

**n8n changes (the AI workflow that receives WhatsApp messages). Header on every call: `x-webhook-secret` = same secret as N8N_WEBHOOK_SECRET.**
1. After the WhatsApp Webhook (incoming, ignore `fromMe`): HTTP Request POST `{APP_URL}/api/whatsapp/log`
   body `{ "direction":"in", "phone":"{{remoteJid}}", "name":"{{pushName}}", "text":"{{message text}}", "message_id":"{{key.id}}" }`
   -> IF `{{ $json.ai_enabled }}` is true -> continue to the AI agent. False -> stop (human is in charge).
2. After the AI agent produces its answer, BEFORE sending it: HTTP Request POST `{APP_URL}/api/whatsapp/log`
   body `{ "direction":"out", "sender":"ai", "phone":"{{remoteJid}}", "text":"{{AI answer}}" }`
   -> IF `{{ $json.blocked }}` is not true -> send it with Evolution (if staff pressed "تدخّل بشري" while the AI was thinking, it is dropped).
3. New workflow/webhook **`res-human-reply`** (POST, check `x-webhook-secret`): body.payload = `{ number, text }` -> Evolution `sendText` (`number` = `body.payload.number`, `text` = `body.payload.text`). Must answer 200.
(Env: `N8N_PATH_HUMAN_REPLY`, default `res-human-reply`. Case-sensitive.)

---
## Update: global human-intervention button (migration_20)
Run `supabase/migration_20_global_human.sql` once (after 19). Red **تدخّل بشري** button at the top-left of /admin/chats: pressed -> the AI answers NO chat (n8n gets `ai_enabled:false` / `blocked:true`, no n8n change needed) and staff can reply in any chat. Press again to turn the AI back on.
