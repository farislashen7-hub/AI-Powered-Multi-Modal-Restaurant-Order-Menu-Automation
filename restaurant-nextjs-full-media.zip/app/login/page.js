import AuthForm from '@/components/AuthForm';
import Header from '@/components/Header';
import VideoBackground from '@/components/VideoBackground';
import { login } from '@/app/auth/actions';

export default function LoginPage({ searchParams }) {
  return (
    <>
      <Header />
      <main className="relative isolate flex min-h-[calc(100vh-60px)] items-center overflow-hidden bg-[#140b07] px-4 py-12">
        <VideoBackground overlay="from-black/80 via-black/55 to-black/45" />
        <AuthForm mode="login" action={login} next={searchParams?.next} /></main>
    </>
  );
}
