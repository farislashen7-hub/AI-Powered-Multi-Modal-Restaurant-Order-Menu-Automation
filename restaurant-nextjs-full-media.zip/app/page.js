import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import Menu from '@/components/Menu';
import { getSessionUser } from '@/lib/supabase/server';
import { getSite } from '@/lib/settings';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const { supabase, profile } = await getSessionUser();
  const info = await getSite();
  const { data: items } = await supabase
    .from('menu_items').select('*, menu_item_extras(id, name, price, available, sort_order)').eq('available', true).order('category').order('name');
  // active, not-expired offers (public RLS policy; table missing -> just no offers tab)
  const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo' }).format(new Date());
  const { data: offerRows } = await supabase
    .from('offers').select('*')
    .eq('active', true).order('created_at', { ascending: false }).limit(20);
  const offers = (offerRows || []).filter((o) => !o.valid_until || String(o.valid_until) >= today);
  return (
    <>
      <Header />
      <Hero info={info} />
      <Features />
      <Menu items={items || []} offers={offers} info={info} defaults={{ name: profile?.full_name || '', phone: profile?.phone || '' }} />
      <Footer info={info} />
      <WhatsAppButton info={info} />
    </>
  );
}
