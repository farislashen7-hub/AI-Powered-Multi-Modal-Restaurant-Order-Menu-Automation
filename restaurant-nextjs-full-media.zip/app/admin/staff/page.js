import { requireAdmin } from '@/lib/supabase/server';
import StaffManager from '@/components/StaffManager';

export default async function StaffPage() {
  const { supabase, user } = await requireAdmin();
  const { data } = await supabase
    .from('profiles').select('id, full_name, phone, email, role, created_at')
    .order('created_at', { ascending: false }).limit(300);
  return <StaffManager initial={data || []} meId={user.id} />;
}
