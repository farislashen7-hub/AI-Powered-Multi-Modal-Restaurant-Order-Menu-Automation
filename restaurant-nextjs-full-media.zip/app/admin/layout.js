import { redirect } from 'next/navigation';
import { Flame } from 'lucide-react';
import { getSessionUser } from '@/lib/supabase/server';
import AdminNav from '@/components/AdminNav';
import { site } from '@/lib/site';

export const dynamic = 'force-dynamic';

function NoAccess({ email, profile, profileError }) {
  const host = (() => { try { return new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname; } catch { return 'غير معروف'; } })();
  const safe = String(email).replace(/'/g, "''");
  const sql = `insert into public.profiles (id, full_name, role)
select id, raw_user_meta_data->>'full_name', 'admin'
from auth.users where email = '${safe}'
on conflict (id) do update set role = 'admin';`;
  const reason = profileError
    ? 'الموقع مقدرش يقرأ جدول profiles (غالبًا schema.sql ما اتشغّلش كامل على المشروع ده).'
    : !profile
    ? 'مفيش صف ليك في جدول profiles.'
    : `صلاحية حسابك "${profile.role}" مش admin أو staff.`;
  return (
    <main className="mx-auto max-w-2xl px-4 py-16">
      <div className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-ink/10">
        <h1 className="text-xl font-bold">الحساب ده مش أدمن ولا موظف</h1>
        <p className="mt-2 text-sm text-ink/70">{reason}</p>
        <dl className="mt-4 space-y-1 text-sm">
          <div className="flex gap-2"><dt className="font-semibold">الإيميل:</dt><dd dir="ltr">{email}</dd></div>
          <div className="flex gap-2"><dt className="font-semibold">الصلاحية:</dt><dd>{profile?.role ?? 'مفيش صف'}</dd></div>
          <div className="flex gap-2"><dt className="font-semibold">مشروع Supabase المتصل:</dt><dd dir="ltr">{host}</dd></div>
          {profileError && <div className="flex gap-2"><dt className="font-semibold">الخطأ:</dt><dd dir="ltr">{profileError}</dd></div>}
        </dl>
        <p className="mt-5 text-sm font-semibold">شغّل ده في Supabase → SQL Editor، في المشروع اللي اسمه فوق:</p>
        <pre dir="ltr" className="mt-2 overflow-x-auto rounded-xl bg-ink p-4 text-xs text-white">{sql}</pre>
        <p className="mt-3 text-sm text-ink/70">بعدها اعمل خروج، وادخل تاني، وافتح /admin.</p>
        <a href="/" className="mt-5 inline-flex min-h-[44px] items-center rounded-xl bg-ink px-5 text-sm font-semibold text-white">الرجوع للموقع</a>
      </div>
    </main>
  );
}

export default async function AdminLayout({ children }) {
  const { user, profile, profileError } = await getSessionUser();
  if (!user) redirect('/login?next=/admin');
  if (profile?.role === 'delivery') redirect('/delivery');
  if (!['admin', 'staff'].includes(profile?.role)) return <NoAccess email={user.email} profile={profile} profileError={profileError} />;

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[250px_1fr]">
      <aside className="flex flex-col bg-ink text-white lg:sticky lg:top-0 lg:h-screen">
        <div className="flex items-center gap-2.5 px-4 py-4">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-saf text-ink"><Flame className="h-5 w-5" aria-hidden /></span>
          <div className="leading-tight"><p className="font-bold">{site.name}</p><p className="text-xs text-white/60">لوحة الإدارة</p></div>
        </div>
        <AdminNav role={profile.role} />
      </aside>
      <div className="min-w-0 px-4 py-6 lg:px-8"><div className="mx-auto max-w-5xl">{children}</div></div>
    </div>
  );
}
