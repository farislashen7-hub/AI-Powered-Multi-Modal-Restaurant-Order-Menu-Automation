import { requireAdmin } from '@/lib/supabase/server';
import MenuManager from '@/components/MenuManager';

export default async function AdminMenu() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase
    .from('menu_items')
    .select('*, menu_item_extras(id, name, price, sort_order)')
    .order('created_at', { ascending: false });
  return <MenuManager initial={data || []} />;
}
