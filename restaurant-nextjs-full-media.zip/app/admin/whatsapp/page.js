import { getSessionUser } from '@/lib/supabase/server';
import WhatsAppInbox from '@/components/WhatsAppInbox';

export const dynamic = 'force-dynamic';

export default async function WhatsAppPage() {
  const { supabase } = await getSessionUser();
  const { data, error } = await supabase
    .from('wa_conversations').select('*')
    .order('last_message_at', { ascending: false }).limit(300);
  const { data: st } = await supabase.from('wa_settings').select('ai_enabled').eq('id', 1).maybeSingle();
  return (
    <WhatsAppInbox
      initial={data || []}
      initialGlobalAi={st?.ai_enabled !== false}
      loadError={error ? 'تعذّر تحميل المحادثات. شغّل migration_19_whatsapp_inbox.sql' : ''}
    />
  );
}
