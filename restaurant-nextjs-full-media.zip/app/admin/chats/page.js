import { getSessionUser } from '@/lib/supabase/server';
import ChatsBoard from '@/components/ChatsBoard';

export const dynamic = 'force-dynamic';

export default async function ChatsPage() {
  const { supabase, profile } = await getSessionUser(); // layout already limits this to admin/staff; RLS limits rows to staff
  const { data, error } = await supabase
    .from('wa_chats').select('*').order('last_message_at', { ascending: false }).limit(200);
  const { data: st } = await supabase.from('wa_settings').select('ai_enabled').eq('id', 1).maybeSingle();
  return (
    <ChatsBoard
      initial={data || []}
      initialAi={st?.ai_enabled !== false}
      isAdmin={profile?.role === 'admin'}
      loadError={error ? 'تعذّر تحميل المحادثات. شغّل migration_19_whatsapp_chats.sql' : ''}
    />
  );
}
