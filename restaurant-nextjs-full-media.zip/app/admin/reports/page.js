import { requireAdmin } from '@/lib/supabase/server';
import ReportsView from '@/components/ReportsView';

export default async function ReportsPage() {
  await requireAdmin();
  return <ReportsView />;
}
