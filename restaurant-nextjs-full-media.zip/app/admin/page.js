import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import OrdersBoard from '@/components/OrdersBoard';

export const dynamic = 'force-dynamic';

export default async function AdminOrders() {
  const { supabase, profile } = await getSessionUser();
  const { data } = await supabase
    .from('orders').select('*, order_items(id, name, qty, unit_price, extras, extras_total)')
    .order('created_at', { ascending: false }).limit(100);

  // couriers for the "assign" dropdown (names read server-side; staff can't read other profiles directly)
  let couriers = [];
  if (['admin', 'staff'].includes(profile?.role)) {
    try {
      const db = adminClient();
      const { data: cs } = await db.from('couriers').select('id, courier_no, status').order('courier_no');
      const ids = (cs || []).map((c) => c.id);
      const { data: ps } = ids.length ? await db.from('profiles').select('id, full_name, role').in('id', ids) : { data: [] };
      const name = Object.fromEntries((ps || []).filter((p) => p.role === 'delivery').map((p) => [p.id, p.full_name || 'مندوب']));
      couriers = (cs || []).filter((c) => name[c.id]).map((c) => ({ id: c.id, no: c.courier_no, status: c.status, name: name[c.id] }));
    } catch {}
  }
  return <OrdersBoard initial={data || []} couriers={couriers} />;
}
