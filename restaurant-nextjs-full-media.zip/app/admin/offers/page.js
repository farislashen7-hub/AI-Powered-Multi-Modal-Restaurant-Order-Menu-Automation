import { requireAdmin } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { getSite } from '@/lib/settings';
import { normalizePhone } from '@/lib/phone';
import OffersManager from '@/components/OffersManager';

export const dynamic = 'force-dynamic';

export default async function OffersPage() {
  const { supabase } = await requireAdmin();
  const site = await getSite();
  const { data: offers, error } = await supabase
    .from('offers').select('*')
    .order('created_at', { ascending: false }).limit(100);

  // how many past customers a broadcast would reach (same rule as the send API)
  let recipientCount = 0;
  try {
    const since = new Date(Date.now() - 90 * 864e5).toISOString();
    const { data } = await adminClient().from('orders').select('phone').neq('status', 'cancelled').gte('created_at', since).limit(5000);
    recipientCount = new Set((data || []).map((o) => normalizePhone(o.phone)).filter(Boolean)).size;
  } catch {}

  return (
    <OffersManager
      initial={offers || []}
      loadError={error ? 'تعذّر تحميل العروض. شغّل migration_11_reports_offers_delivery.sql' : ''}
      siteName={site.name}
      siteUrl={(process.env.NEXT_PUBLIC_SITE_URL || '').trim()}
      recipientCount={recipientCount}
    />
  );
}
