import { requireAdmin } from '@/lib/supabase/server';
import CourierManager from '@/components/CourierManager';

export const dynamic = 'force-dynamic';

export default async function DeliveryAdminPage() {
  const { supabase } = await requireAdmin();
  const { data: couriers, error } = await supabase
    .from('couriers')
    .select('id, courier_no, status, out_reason, status_changed_at, profile:profiles(full_name, phone, email, role)')
    .order('courier_no');

  const since = new Date(Date.now() - 30 * 864e5).toISOString();
  const { data: orders } = await supabase
    .from('orders').select('courier_id, status, delivered_at').not('courier_id', 'is', null).gte('created_at', since).limit(5000);
  const { data: delivered } = await supabase
    .from('orders')
    .select('id, order_no, courier_id, customer_name, phone, address, area, order_type, notes, total, delivery_fee, delivered_at, created_at, order_items(id, name, qty, unit_price, extras, extras_total)')
    .eq('status', 'delivered').not('courier_id', 'is', null).gte('created_at', since)
    .order('delivered_at', { ascending: false, nullsFirst: false }).limit(500);
  const byCourier = {};
  for (const o of delivered || []) (byCourier[o.courier_id] ||= []).push(o);
  const startToday = new Date(); startToday.setHours(0, 0, 0, 0);

  const stats = {};
  for (const o of orders || []) {
    const s = (stats[o.courier_id] ||= { active: 0, today: 0, month: 0 });
    if (['pending', 'preparing', 'ready'].includes(o.status)) s.active += 1;
    if (o.status === 'delivered') { s.month += 1; if (o.delivered_at && new Date(o.delivered_at) >= startToday) s.today += 1; }
  }
  return (
    <CourierManager
      initial={(couriers || []).filter((c) => c.profile?.role === 'delivery').map((c) => ({ ...c, stats: stats[c.id] || { active: 0, today: 0, month: 0 }, delivered: byCourier[c.id] || [] }))}
      loadError={error ? 'تعذّر تحميل المناديب. شغّل migration_11_reports_offers_delivery.sql' : ''}
    />
  );
}
