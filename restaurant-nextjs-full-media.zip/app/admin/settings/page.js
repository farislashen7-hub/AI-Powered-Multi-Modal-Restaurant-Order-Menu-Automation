import { requireAdmin } from '@/lib/supabase/server';
import SettingsForm from '@/components/SettingsForm';

export default async function SettingsPage() {
  const { supabase } = await requireAdmin();
  const { data } = await supabase.from('site_settings').select('*').eq('id', 1).maybeSingle();
  return <SettingsForm initial={data} />;
}
