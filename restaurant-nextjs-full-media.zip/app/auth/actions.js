'use server';
import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { createClient } from '@/lib/supabase/server';
import { notifyN8n } from '@/lib/n8n';
import crypto from 'node:crypto';
import { adminClient } from '@/lib/supabase/admin';
import { normalizePhone } from '@/lib/phone';
import { lockKey, clientIp, lockWait, lockFail, lockClear } from '@/lib/loginLock';

const safeNext = (n) => (typeof n === 'string' && n.startsWith('/') && !n.startsWith('//') ? n : null);

export async function login(_prev, formData) {
  const email = String(formData.get('email') || '').trim();
  const key = lockKey(email, clientIp(headers()));
  const wait = await lockWait(key);
  if (wait > 0) return { error: `محاولات كتير. استنى ${wait} ثانية` };

  const supabase = createClient();
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password: String(formData.get('password') || ''),
  });
  if (error) {
    const w = await lockFail(key);
    return { error: w > 0 ? `محاولات كتير. استنى ${w} ثانية` : 'البريد أو كلمة المرور غير صحيحة' };
  }
  await lockClear(key);

  const { data: profile } = await supabase
    .from('profiles').select('role').eq('id', data.user.id).maybeSingle();
  redirect(safeNext(formData.get('next')) || (['admin', 'staff'].includes(profile?.role) ? '/admin' : profile?.role === 'delivery' ? '/delivery' : '/'));
}

// Staff-only registration. Customers never need an account (guest checkout).
// Gate = shared signup code (Supabase app_secrets, or STAFF_SIGNUP_CODE env). Account + role are created server-side only.
const sha = (v) => crypto.createHash('sha256').update(String(v)).digest();
// code source: Supabase table app_secrets (editable in Table Editor), falls back to STAFF_SIGNUP_CODE env
async function realCode(admin) {
  try {
    const { data } = await admin.from('app_secrets').select('value').eq('key', 'staff_signup_code').maybeSingle();
    const v = String(data?.value || '').trim();
    if (v.length >= 8) return v;
  } catch {}
  return (process.env.STAFF_SIGNUP_CODE || '').trim();
}
const codeOk = (given, real) => real.length >= 8 && crypto.timingSafeEqual(sha(String(given).trim()), sha(real));
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function signup(_prev, formData) {
  const email = String(formData.get('email') || '').trim().toLowerCase();
  const password = String(formData.get('password') || '');
  const full_name = String(formData.get('full_name') || '').trim().slice(0, 80);
  const phone = String(formData.get('phone') || '').trim().slice(0, 30);
  const staffCode = String(formData.get('staff_code') || '');
  const kind = formData.get('account_type') === 'delivery' ? 'delivery' : 'staff'; // role is decided HERE, never trusted from a hidden role field

  if (!full_name) return { error: 'الاسم مطلوب' };
  if (kind === 'delivery' && !normalizePhone(phone)) return { error: 'رقم الموبايل مطلوب وصحيح للمندوب (مثال: 01012345678)' };
  if (!EMAIL_RE.test(email)) return { error: 'البريد الإلكتروني غير صحيح' };
  if (password.length < 8) return { error: 'كلمة المرور 8 أحرف على الأقل' };

  let admin;
  try { admin = adminClient(); } catch { return { error: 'السيرفر غير مهيأ. كلّم الأدمن.' }; }

  const real = await realCode(admin);
  if (real.length < 8) return { error: 'تسجيل الموظفين مقفول حاليًا. كلّم الأدمن.' };

  // every attempt counts (stops guessing the staff code)
  const ip = clientIp(headers());
  const { data: allowed } = await admin.rpc('rate_hit', { p_key: `staff-signup|${ip}`, p_limit: 8, p_window_secs: 3600 });
  if (allowed === false) return { error: 'محاولات كتير. جرّب بعد ساعة.' };

  if (!codeOk(staffCode, real)) return { error: 'كود الموظفين غير صحيح' };

  const { data, error } = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
    user_metadata: { full_name, phone: kind === 'delivery' ? normalizePhone(phone) : phone },
  });
  if (error || !data?.user) return { error: 'تعذّر إنشاء الحساب. جرّب بريد تاني أو كلّم الأدمن.' };

  const { error: roleErr } = await admin.from('profiles')
    .upsert({ id: data.user.id, full_name, phone: (kind === 'delivery' ? normalizePhone(phone) : phone) || null, email, role: kind }, { onConflict: 'id' });
  if (roleErr) {
    await admin.auth.admin.deleteUser(data.user.id); // never leave a half-made account
    return { error: 'حصل خطأ، حاول تاني.' };
  }

  await notifyN8n('user.signed_up', { id: data.user.id, email, full_name, phone, role: kind });

  const { error: signErr } = await createClient().auth.signInWithPassword({ email, password });
  if (signErr) return { ok: 'تم إنشاء حساب الموظف. سجّل الدخول.' };
  redirect(kind === 'delivery' ? '/delivery' : '/admin');
}

export async function logout() {
  await createClient().auth.signOut();
  redirect('/');
}
