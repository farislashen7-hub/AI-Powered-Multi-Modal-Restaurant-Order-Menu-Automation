// Removed: login (with brute-force lock) is handled by the server action in app/auth/actions.js.
// Kept as a stub so no second password-guessing endpoint exists.
export async function POST() {
  return new Response(null, { status: 410 });
}
