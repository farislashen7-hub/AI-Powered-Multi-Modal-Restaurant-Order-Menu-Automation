import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { getSite } from '@/lib/settings';
import { notifyN8n } from '@/lib/n8n';
import { normalizePhone } from '@/lib/phone';
import { buildOfferMessage } from '@/lib/offerMessage';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const MAX_RECIPIENTS = 500;
const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// Only our own Supabase public storage; reachable by WhatsApp gateway (HEAD check) or we fail BEFORE sending anyone anything.
async function checkImage(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== 'https:' || !u.hostname.endsWith('.supabase.co')) return false;
    const r = await fetch(u, { method: 'HEAD', signal: AbortSignal.timeout(5000) });
    return r.ok && (r.headers.get('content-type') || '').startsWith('image/');
  } catch { return false; }
}

// Owner only. Message + recipients are built HERE from the DB (never from the client).
export async function POST(request, { params }) {
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }
  const { user, profile } = await getSessionUser();
  if (!user || profile?.role !== 'admin') return bad('forbidden', 403);
  if (!UUID.test(params.id)) return bad('bad id');

  const db = adminClient();
  const { data: offer } = await db.from('offers').select('*').eq('id', params.id).maybeSingle();
  if (!offer) return bad('العرض مش موجود', 404);
  if (!offer.active) return bad('العرض متوقف. فعّله الأول');
  const today = new Date(Date.now() + 2 * 3600e3).toISOString().slice(0, 10); // ~Cairo date
  if (offer.valid_until && String(offer.valid_until) < today) return bad('العرض انتهى');

  // past customers (last 90 days, not cancelled), distinct normalized phones
  const since = new Date(Date.now() - 90 * 864e5).toISOString();
  const { data: rows } = await db.from('orders').select('phone').neq('status', 'cancelled').gte('created_at', since).limit(5000);
  const recipients = [...new Set((rows || []).map((o) => normalizePhone(o.phone)).filter(Boolean))].slice(0, MAX_RECIPIENTS);
  if (!recipients.length) return bad('مفيش عملاء سابقين نبعتلهم');

  if (offer.image_url && !(await checkImage(offer.image_url))) return bad('صورة العرض مش متاحة. ارفعها تاني أو شيلها وبعدين ابعت');

  const site = await getSite();
  // owner-edited WhatsApp text wins; otherwise auto-built from the offer fields
  const custom = String(offer.wa_message || '').trim().slice(0, 1000);
  const message = custom || buildOfferMessage(offer, { siteName: site.name, siteUrl: (process.env.NEXT_PUBLIC_SITE_URL || '').trim() });
  // image offer -> WhatsApp image + caption (same as the admin preview). n8n: IF has_image -> sendMedia, else sendText.
  const media = offer.image_url ? { mediatype: 'image', mimetype: 'image/jpeg', media: offer.image_url, fileName: 'offer.jpg', caption: message } : null;
  const r = await notifyN8n('offer.broadcast', { offer_id: offer.id, title: offer.title, image_url: offer.image_url || null, has_image: Boolean(media), media, message, recipients, count: recipients.length });
  if (!r.ok) {
    return bad('تعذّر الوصول لـ n8n. اتأكد إن الـ workflow شغال والـ webhook res-offers موجود', 502);
  }

  await db.from('offers').update({ last_sent_at: new Date().toISOString(), sent_count: recipients.length }).eq('id', offer.id);
  return NextResponse.json({ ok: true, count: recipients.length });
}
