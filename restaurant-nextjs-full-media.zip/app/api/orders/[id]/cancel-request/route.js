import { NextResponse } from 'next/server';
import { getMyOrder, UUID } from '@/lib/orderAccess';
import { adminClient } from '@/lib/supabase/admin';
import { notifyN8n } from '@/lib/n8n';

const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// Customer asks to cancel -> webhook to n8n. Order is NOT cancelled here; staff decides.
export async function POST(request, { params }) {
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }

  if (!UUID.test(params.id)) return bad('bad id');
  const mine = await getMyOrder(params.id);
  if (!mine) return bad('الطلب مش موجود', 404);
  const { order: full, user } = mine;
  const { user_id, device_token, ...order } = full;

  if (!['pending', 'preparing'].includes(order.status)) return bad('مينفعش إلغاء الطلب في الحالة دي');

  // max 3 requests per order per hour (fail-open if limiter unavailable)
  try {
    const { data: ok, error } = await adminClient().rpc('rate_hit', { p_key: `cancel-req:${order.id}`, p_limit: 3, p_window_secs: 3600 });
    if (!error && ok === false) return bad('اتبعت طلب الإلغاء قبل كده، استنى ردنا', 429);
  } catch {}

  const sent = await notifyN8n('order.cancel_requested', { ...order, requested_by: user?.id || 'guest', requested_email: user?.email || null });
  if (!sent.ok) {
    const hint = {
      no_url: 'N8N_WEBHOOK_URL مش متظبط على السيرفر',
      unreachable: 'السيرفر مش قادر يوصل لـ n8n (شغّال؟ الرابط صح؟)',
    }[sent.reason] || `n8n رد بخطأ (${sent.reason.replace('http_', '')}) — الـ workflow مفعّل؟ الرابط production مش test؟`;
    return bad(`تعذّر إرسال طلب الإلغاء: ${hint}`, 503);
  }
  return NextResponse.json({ ok: true });
}
