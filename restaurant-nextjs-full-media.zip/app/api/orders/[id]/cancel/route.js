import { NextResponse } from 'next/server';
import { adminClient } from '@/lib/supabase/admin';
import { getMyOrder } from '@/lib/orderAccess';
import { notifyN8n } from '@/lib/n8n';

const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// Customer (guest or logged-in) cancels own order while it is still `pending`.
// DB trigger orders_guard restores stock on cancel.
export async function POST(request, { params }) {
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }

  const mine = await getMyOrder(params.id);
  if (!mine) return bad('الطلب مش موجود', 404);
  const { user_id, device_token, ...order } = mine.order;

  const db = adminClient();
  try {
    const { data: ok, error } = await db.rpc('rate_hit', { p_key: `cancel:${order.id}`, p_limit: 5, p_window_secs: 3600 });
    if (!error && ok === false) return bad('محاولات كتير، حاول بعد شوية', 429);
  } catch {}

  // atomic: only flips if still pending
  const { data: upd, error } = await db.from('orders')
    .update({ status: 'cancelled' }).eq('id', order.id).eq('status', 'pending')
    .select('id').maybeSingle();
  if (error) { console.error('[cancel]', error.message); return bad('تعذّر إلغاء الطلب', 500); }
  if (!upd) return bad('الطلب اتحرك للتحضير، ابعت طلب إلغاء بدل كده', 409);

  await notifyN8n('order.status_changed', { ...order, status: 'cancelled' });
  return NextResponse.json({ ok: true });
}
