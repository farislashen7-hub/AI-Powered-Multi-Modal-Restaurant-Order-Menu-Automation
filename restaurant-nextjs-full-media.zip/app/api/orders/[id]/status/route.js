import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { notifyN8n } from '@/lib/n8n';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ALLOWED = ['pending', 'preparing', 'ready', 'delivered', 'cancelled'];

export async function PATCH(request, { params }) {
  const { supabase, user, profile } = await getSessionUser();
  if (!user || !['admin', 'staff'].includes(profile?.role)) return NextResponse.json({ error: 'forbidden' }, { status: 403 });

  if (!UUID.test(params.id)) return NextResponse.json({ error: 'bad id' }, { status: 400 });
  const { status } = await request.json().catch(() => ({}));
  if (!ALLOWED.includes(status)) return NextResponse.json({ error: 'bad status' }, { status: 400 });

  const { data: order, error } = await supabase
    .from('orders').update({ status }).eq('id', params.id)
    .select('*, order_items(name, qty, unit_price, extras, extras_total)').single();
  if (error) {
    console.error('[status]', error.message);
    const msg = /delivered order cannot be cancelled/.test(error.message) ? 'الطلب اتسلّم، مينفعش يتلغي'
      : /cancelled order cannot be reopened/.test(error.message) ? 'الطلب ملغي ومينفعش يتفتح تاني'
      : 'تعذّر تحديث الطلب';
    return NextResponse.json({ error: msg }, { status: 400 });
  }

  // Owner (admin) cancelling from the dashboard -> same n8n path as cancel requests (res-cancel-request).
  // Customer self-cancel and staff changes keep using order.status_changed.
  if (status === 'cancelled' && profile.role === 'admin') {
    await notifyN8n('order.cancelled_by_owner', { ...order, cancelled_by: 'owner' });
  } else {
    await notifyN8n('order.status_changed', order);
  }
  return NextResponse.json({ ok: true });
}
