import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { notifyN8n } from '@/lib/n8n';
import { courierCode } from '@/lib/courier';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// staff/admin: assign (or un-assign) a delivery order to a courier.
export async function POST(request, { params }) {
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }
  const { user, profile } = await getSessionUser();
  if (!user || !['admin', 'staff'].includes(profile?.role)) return bad('forbidden', 403);
  if (!UUID.test(params.id)) return bad('bad id');

  const body = await request.json().catch(() => ({}));
  const courierId = body.courier_id ? String(body.courier_id) : null;
  if (courierId && !UUID.test(courierId)) return bad('bad courier');

  const db = adminClient();
  const { data: order } = await db.from('orders').select('id, order_type, status').eq('id', params.id).maybeSingle();
  if (!order) return bad('الطلب مش موجود', 404);
  if (order.order_type !== 'delivery') return bad('الطلب ده استلام من المطعم مش توصيل');
  if (['delivered', 'cancelled'].includes(order.status)) return bad('الطلب خلص أو اتلغى');

  if (courierId) {
    const [{ data: c }, { data: p }] = await Promise.all([
      db.from('couriers').select('status').eq('id', courierId).maybeSingle(),
      db.from('profiles').select('role').eq('id', courierId).maybeSingle(),
    ]);
    if (!c || p?.role !== 'delivery') return bad('المندوب مش موجود');
    if (c.status !== 'available') return bad('المندوب ده خارج الخدمة');
  }

  const { error } = await db.from('orders')
    .update({ courier_id: courierId, assigned_at: courierId ? new Date().toISOString() : null }).eq('id', order.id);
  if (error) { console.error('[assign]', error.message); return bad('تعذّر تعيين المندوب (شغّل migration_11)', 500); }
  if (courierId) {
    const [{ data: full }, { data: p }, { data: c }] = await Promise.all([
      db.from('orders').select('id, order_no, customer_name, phone, address, area, notes, status, total, order_items(name, qty)').eq('id', order.id).single(),
      db.from('profiles').select('full_name, phone').eq('id', courierId).maybeSingle(),
      db.from('couriers').select('courier_no').eq('id', courierId).maybeSingle(),
    ]);
    await notifyN8n('order.assigned', { ...full, courier: { id: courierId, code: courierCode(c?.courier_no), name: p?.full_name || null, phone: p?.phone || null } });
  }
  return NextResponse.json({ ok: true });
}
