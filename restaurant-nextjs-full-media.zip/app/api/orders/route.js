import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { notifyN8n } from '@/lib/n8n';
import { cookies } from 'next/headers';
import { normalizePhone } from '@/lib/phone';
import { DEVICE_COOKIE, readDevice } from '@/lib/orderAccess';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const bad = (error, status = 400) => NextResponse.json({ error }, { status });

export async function POST(request) {
  // same-origin only (blocks cross-site form posts)
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }

  let body;
  try { body = await request.json(); } catch { return bad('bad request'); }

  // ---- validate (never trust the client) ----
  const name = String(body.name || '').trim().slice(0, 80);
  const phoneRaw = String(body.phone || '').trim().slice(0, 30);
  const type = body.type === 'pickup' ? 'pickup' : 'delivery';
  const address = type === 'pickup' ? '' : String(body.address || '').trim().slice(0, 300);
  const area = type === 'pickup' ? '' : String(body.area || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  const notes = String(body.notes || '').trim().slice(0, 500);
  const phone = /[^\d+\s-]/.test(phoneRaw) ? null : normalizePhone(phoneRaw); // +20..., +966... or null
  const digits = (phone || '').replace(/\D/g, '');
  if (name.length < 2) return bad('اكتب اسمك');
  if (!phone) return bad('رقم الموبايل غير صحيح. اختار الدولة أو اكتب الرقم بكود الدولة (+966...)');
  if (type === 'delivery' && area.length < 2) return bad('اكتب اسم المنطقة');
  if (type === 'delivery' && address.length < 5) return bad('اكتب العنوان بالتفصيل');

  const raw = Array.isArray(body.items) ? body.items.slice(0, 50) : [];
  const items = raw
    .filter((i) => i && (UUID.test(String(i.id)) || UUID.test(String(i.offer_id))))
    .map((i) => {
      const qty = Math.min(50, Math.max(1, parseInt(i.qty, 10) || 1));
      if (UUID.test(String(i.offer_id))) return { offer_id: String(i.offer_id), qty }; // offer line: price read from DB
      return {
        id: String(i.id), qty,
        extras: Array.isArray(i.extras) ? i.extras.filter((x) => UUID.test(String(x))).slice(0, 20).map(String) : [],
      };
    });
  if (!items.length) return bad('السلة فاضية');

  let db;
  try { db = adminClient(); } catch (e) { console.error('[orders]', e.message); return bad('الخدمة غير متاحة حاليًا', 503); }

  // ---- rate limit: per IP and per phone (fail-open if limiter unavailable) ----
  const ip = (request.headers.get('x-forwarded-for') || '').split(',')[0].trim() || 'unknown';
  for (const [key, limit] of [[`order-ip:${ip}`, 8], [`order-phone:${digits}`, 5]]) {
    const { data: ok, error } = await db.rpc('rate_hit', { p_key: key, p_limit: limit, p_window_secs: 600 });
    if (!error && ok === false) return bad('طلبات كتير في وقت قصير، حاول بعد شوية', 429);
  }

  // optional: link order to the logged-in user, otherwise guest
  const { data: { user } } = await createClient().auth.getUser();

  const { data: orderId, error } = await db.rpc('create_order_server', {
    p_user: user?.id || null,
    p_name: name,
    p_phone: phone,
    p_address: address,
    p_notes: notes,
    p_items: items,
    p_type: type,
  });
  if (error) {
    const m = /out of stock: (.+)/.exec(error.message || '');
    if (!m) console.error('[orders]', error.message);
    // DB not updated yet (migration_06 / migration_07 missing)
    if (/create_order_server|schema cache|order_type|order_no|delivery_fee/i.test(error.message || '')) {
      return bad('الموقع محتاج تحديث قاعدة البيانات (migration_06 و 07 و 10)', 503);
    }
    return bad(m ? `الصنف خلص: ${m[1]}` : 'تعذّر إنشاء الطلب');
  }

  const { data: order } = await db
    .from('orders')
    .select('id, order_no, order_type, created_at, customer_name, phone, address, notes, status, total, delivery_fee, order_items(name, qty, unit_price, extras, extras_total)')
    .eq('id', orderId).single();
  // link order to this browser so guests can see it in /my-orders
  const device = readDevice() || crypto.randomUUID();
  const { error: devErr } = await db.from('orders').update({ device_token: device }).eq('id', orderId);
  if (devErr) console.error('[orders] device_token (run migration_09)', devErr.message);
  cookies().set(DEVICE_COOKIE, device, {
    httpOnly: true, sameSite: 'lax', path: '/',
    secure: (request.headers.get('x-forwarded-proto') || request.nextUrl.protocol.replace(':', '')) === 'https', maxAge: 60 * 60 * 24 * 7,
  });

  if (area) {
    const { error: areaErr } = await db.from('orders').update({ area }).eq('id', orderId);
    if (areaErr) console.error('[orders] area (run migration_11)', areaErr.message);
  }

  await notifyN8n('order.created', { ...order, area: area || null });

  return NextResponse.json({ id: orderId, invoice: order });
}
