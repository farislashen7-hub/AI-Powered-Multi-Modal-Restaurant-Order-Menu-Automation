import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { setCourierStatus } from '@/lib/courierServer';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// Owner overrides a courier's status.
export async function PATCH(request, { params }) {
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }
  const { user, profile } = await getSessionUser();
  if (!user || profile?.role !== 'admin') return bad('forbidden', 403);
  if (!UUID.test(params.id)) return bad('bad id');
  const { status } = await request.json().catch(() => ({}));
  if (!['available', 'out_of_service'].includes(status)) return bad('bad status');
  const res = await setCourierStatus(adminClient(), params.id, status, status === 'out_of_service' ? 'من الإدارة' : null);
  if (!res.ok) return bad('تعذّر التحديث', 500);
  return NextResponse.json({ ok: true, released: res.released });
}
