import { NextResponse } from 'next/server';
import { bad, requireStaff } from '@/lib/whatsapp';
import { adminClient } from '@/lib/supabase/admin';
import { MEDIA_BUCKET, isSafeStoragePath } from '@/lib/waChat';

export const dynamic = 'force-dynamic';

// GET /api/admin/chats/media?path=incoming/2026/10/ABC.jpg
// Staff/admin only. Bucket stays PRIVATE: we hand the browser a 5-minute signed URL.
export async function GET(request) {
  const { error } = await requireStaff(request);
  if (error) return error;

  const path = new URL(request.url).searchParams.get('path') || '';
  if (!isSafeStoragePath(path)) return bad('bad path');

  const { data, error: e } = await adminClient().storage.from(MEDIA_BUCKET).createSignedUrl(path, 300);
  if (e || !data?.signedUrl) {
    console.error('[chats/media]', MEDIA_BUCKET, path, e?.message);
    return bad('الملف مش موجود (تأكد من اسم الـ bucket والمسار)', 404);
  }
  const res = NextResponse.redirect(data.signedUrl, 302);
  res.headers.set('Cache-Control', 'private, max-age=240');
  return res;
}
