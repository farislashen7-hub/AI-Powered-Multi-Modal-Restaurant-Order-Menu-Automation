import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { sameOrigin, isChatKey } from '@/lib/waChat';

const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// staff/admin: 'human' = take over (AI silent) · 'ai' = give the chat back to the smart assistant
export async function POST(request) {
  if (!sameOrigin(request)) return bad('forbidden', 403);
  const { user, profile } = await getSessionUser();
  if (!user || !['admin', 'staff'].includes(profile?.role)) return bad('forbidden', 403);

  const { phone, mode } = await request.json().catch(() => ({}));
  if (!isChatKey(phone) || !['ai', 'human'].includes(mode)) return bad('بيانات غلط');

  const db = adminClient();
  const { data: chat, error } = await db.from('wa_chats').update({
    mode, human_by: mode === 'human' ? user.id : null, mode_changed_at: new Date().toISOString(),
  }).eq('phone', phone).select('phone, mode').maybeSingle();
  if (error || !chat) return bad('المحادثة مش موجودة', 404);

  const who = profile.full_name || 'موظف';
  await db.from('wa_messages').insert({
    phone, direction: 'out', sender: 'system',
    body: mode === 'human' ? `${who} استلم المحادثة، المساعد الذكي متوقف` : `${who} رجّع المحادثة للمساعد الذكي`,
  });
  return NextResponse.json({ ok: true, mode });
}
