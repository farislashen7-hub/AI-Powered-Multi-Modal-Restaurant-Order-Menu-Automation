import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { sameOrigin } from '@/lib/waChat';

const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// staff/admin: { ai: false } = human intervention ON (AI silent in ALL chats) · { ai: true } = AI answers again
export async function POST(request) {
  if (!sameOrigin(request)) return bad('forbidden', 403);
  const { user, profile } = await getSessionUser();
  if (!user || !['admin', 'staff'].includes(profile?.role)) return bad('forbidden', 403);

  const { ai } = await request.json().catch(() => ({}));
  if (typeof ai !== 'boolean') return bad('بيانات غلط');

  const { error } = await adminClient().from('wa_settings')
    .upsert({ id: 1, ai_enabled: ai, changed_by: user.id, changed_at: new Date().toISOString() });
  if (error) return bad('تعذّر تغيير الوضع. شغّل migration_20_global_human.sql', 500);
  return NextResponse.json({ ok: true, ai });
}
