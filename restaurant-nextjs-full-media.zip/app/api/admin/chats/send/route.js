import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { notifyN8n } from '@/lib/n8n';
import { sameOrigin, isChatKey, sendNumber } from '@/lib/waChat';

const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// Staff reply typed in /admin/chats -> n8n (res-human-reply) sends it on WhatsApp -> logged as "human".
// Only allowed while the chat is in human mode (AI is silent), so staff and AI never talk at the same time.
export async function POST(request) {
  if (!sameOrigin(request)) return bad('forbidden', 403);
  const { user, profile } = await getSessionUser();
  if (!user || !['admin', 'staff'].includes(profile?.role)) return bad('forbidden', 403);

  const { phone, text } = await request.json().catch(() => ({}));
  const msg = String(text || '').trim().slice(0, 1000);
  if (!isChatKey(phone)) return bad('بيانات غلط');
  if (!msg) return bad('اكتب رسالة الأول');

  const db = adminClient();
  const { data: chat } = await db.from('wa_chats').select('mode').eq('phone', phone).maybeSingle();
  if (!chat) return bad('المحادثة مش موجودة', 404);
  const { data: st } = await db.from('wa_settings').select('ai_enabled').eq('id', 1).maybeSingle();
  if (chat.mode !== 'human' && st?.ai_enabled !== false) return bad('اضغط «تدخّل بشري» الأول عشان تكتب للعميل', 409);

  const r = await notifyN8n('whatsapp.human_reply', { phone, number: sendNumber(phone), text: msg, staff: profile.full_name || null });
  if (!r.ok) return bad('تعذّر الإرسال: n8n مش بيرد. اتأكد إن الـ workflow شغال والـ webhook res-human-reply موجود', 502);

  const { error } = await db.rpc('wa_log_message', {
    p_phone: phone, p_name: '', p_direction: 'out', p_sender: 'human', p_body: msg, p_media: null, p_ext: null,
  });
  if (error) console.error('[chats/send] log', error.message); // message already sent; only the log failed
  return NextResponse.json({ ok: true });
}
