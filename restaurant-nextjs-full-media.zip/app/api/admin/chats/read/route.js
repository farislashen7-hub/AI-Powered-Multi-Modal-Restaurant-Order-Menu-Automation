import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { sameOrigin, isChatKey } from '@/lib/waChat';

export async function POST(request) {
  if (!sameOrigin(request)) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  const { user, profile } = await getSessionUser();
  if (!user || !['admin', 'staff'].includes(profile?.role)) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  const { phone } = await request.json().catch(() => ({}));
  if (!isChatKey(phone)) return NextResponse.json({ error: 'bad phone' }, { status: 400 });
  await adminClient().from('wa_chats').update({ unread_count: 0 }).eq('phone', phone);
  return NextResponse.json({ ok: true });
}
