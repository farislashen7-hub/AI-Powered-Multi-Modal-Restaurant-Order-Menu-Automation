import { NextResponse } from 'next/server';
import { bad, requireStaff } from '@/lib/whatsapp';
import { adminClient } from '@/lib/supabase/admin';

export const maxDuration = 90;

// OWNER ONLY: زرار "مسح كل حاجة" -> webhook n8n (res-wipe-all) -> يمسح الملفات + الرسائل + جهات الاتصال.
export async function POST(request) {
  const { error, profile } = await requireStaff(request);
  if (error) return error;
  if (profile?.role !== 'admin') return bad('المسح للمالك فقط', 403);

  const body = await request.json().catch(() => ({}));
  if (body.confirm !== 'مسح') return bad('اكتب كلمة "مسح" للتأكيد');

  const base = (process.env.N8N_WEBHOOK_BASE || '').trim().replace(/\/+$/, '');
  const path = (process.env.N8N_PATH_WIPE || '').trim().replace(/^\/+|\/+$/g, '') || 'res-wipe-all';
  if (!base) return bad('N8N_WEBHOOK_BASE مش متظبط على السيرفر', 500);

  try {
    const res = await fetch(`${base}/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-webhook-secret': process.env.N8N_WEBHOOK_SECRET || '' },
      body: JSON.stringify({ event: 'admin.wipe_all', ts: new Date().toISOString() }),
      signal: AbortSignal.timeout(80000),
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) return bad(`n8n رد بخطأ (${res.status}) — الـ workflow مفعّل؟ والرابط production؟`, 502);
    // بعد ما n8n يخلص: امسح بيانات الداشبورد نفسها (wa_messages بتتمسح معاها بالـ cascade)
    const db = adminClient();
    const { error: e1 } = await db.from('wa_chats').delete().not('phone', 'is', null);
    if (e1) console.error('[wipe-all] wa_chats', e1.message);
    await db.from('wa_conversations').delete().not('id', 'is', null); // لو جدول الـ inbox القديم موجود
    await db.from('wa_messages').delete().not('id', 'is', null);
    if (e1) return bad('n8n مسح، لكن تعذّر مسح محادثات الداشبورد', 500);
    return NextResponse.json({ ok: true, ...j });
  } catch (e) {
    console.error('[wipe-all]', e.message);
    return bad('السيرفر مش قادر يوصل لـ n8n', 502);
  }
}
