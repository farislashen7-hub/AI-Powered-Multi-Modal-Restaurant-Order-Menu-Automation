import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { notifyN8n } from '@/lib/n8n';
import { courierCode } from '@/lib/courier';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// Courier confirms delivery. Only his OWN order. Counts as delivered immediately (no need to wait for staff `ready`).
// Idempotent: double tap / retry on a slow network returns ok instead of an error.
export async function POST(request, { params }) {
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }
  const { user, profile } = await getSessionUser();
  if (!user || profile?.role !== 'delivery') return bad('forbidden', 403);
  if (!UUID.test(params.id)) return bad('bad id');

  const db = adminClient();
  const { data, error } = await db.from('orders')
    .update({ status: 'delivered', delivered_at: new Date().toISOString() })
    .eq('id', params.id).eq('courier_id', user.id).in('status', ['pending', 'preparing', 'ready'])
    .select('id').maybeSingle();
  if (error) { console.error('[delivered]', error.message); return bad('تعذّر تسجيل التسليم', 500); }
  if (!data) {
    const { data: cur } = await db.from('orders').select('status, courier_id').eq('id', params.id).maybeSingle();
    if (cur?.courier_id === user.id && cur.status === 'delivered') return NextResponse.json({ ok: true, already: true }); // no 2nd webhook
    if (cur?.status === 'cancelled') return bad('الطلب ده اتلغى', 409);
    return bad('الطلب مش متعيّن ليك (ممكن المطعم حوّله لمندوب تاني)', 409);
  }
  const [{ data: full }, { data: c }] = await Promise.all([
    db.from('orders').select('id, order_no, customer_name, phone, address, area, total, delivered_at').eq('id', data.id).single(),
    db.from('couriers').select('courier_no').eq('id', user.id).maybeSingle(),
  ]);
  await notifyN8n('order.delivered', { ...full, courier: { id: user.id, code: courierCode(c?.courier_no), name: profile.full_name || null, phone: profile.phone || null } });
  return NextResponse.json({ ok: true });
}
