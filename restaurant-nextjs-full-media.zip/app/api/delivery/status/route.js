import { NextResponse } from 'next/server';
import { getSessionUser } from '@/lib/supabase/server';
import { adminClient } from '@/lib/supabase/admin';
import { setCourierStatus } from '@/lib/courierServer';
import { OUT_REASONS } from '@/lib/courier';

const bad = (error, status = 400) => NextResponse.json({ error }, { status });

// Courier toggles himself: available <-> out_of_service (+ reason).
export async function POST(request) {
  const origin = request.headers.get('origin');
  if (origin) {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host');
    try { if (new URL(origin).host !== host) return bad('forbidden', 403); } catch { return bad('forbidden', 403); }
  }
  const { user, profile } = await getSessionUser();
  if (!user || profile?.role !== 'delivery') return bad('forbidden', 403);

  const body = await request.json().catch(() => ({}));
  const status = body.status === 'out_of_service' ? 'out_of_service' : body.status === 'available' ? 'available' : null;
  if (!status) return bad('bad status');
  const r = String(body.reason || '').trim();
  const reason = OUT_REASONS.includes(r) ? r : null; // fixed list only

  const res = await setCourierStatus(adminClient(), user.id, status, reason);
  if (!res.ok) return bad('تعذّر تحديث الحالة', 500);
  return NextResponse.json({ ok: true, released: res.released });
}
