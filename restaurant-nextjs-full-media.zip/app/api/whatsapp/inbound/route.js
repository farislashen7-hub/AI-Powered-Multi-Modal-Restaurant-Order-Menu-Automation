import { NextResponse } from 'next/server';
import { adminClient } from '@/lib/supabase/admin';
import { bad, globalAiOn, secretOk, waPhone } from '@/lib/whatsapp';

// n8n -> site. Header: x-webhook-secret.
//
// POST  log a message and get back { ai_enabled }.
//   body: { phone, text, sender?: 'customer'|'ai'|'human', name?, message_id? }
//   customer = message the customer sent   (call this FIRST, then run the AI only if ai_enabled is true)
//   ai       = reply the AI assistant sent (log it after sending)
//   human    = reply typed directly on the restaurant phone (log only)
// GET   ?phone=...  -> { ai_enabled }  (re-check right before the AI sends its reply)
// ai_enabled = global switch ON and this chat in AI mode. Global "تدخل بشري" -> always false.

const SENDERS = { customer: 'in', ai: 'out', human: 'out' };

async function findOrCreate(db, phone, name) {
  const sel = () => db.from('wa_conversations').select('id, ai_enabled, unread_count, contact_name').eq('phone', phone).maybeSingle();
  let { data: conv } = await sel();
  if (conv) return conv;
  const { data: created, error } = await db.from('wa_conversations')
    .insert({ phone, contact_name: name || null }).select('id, ai_enabled, unread_count, contact_name').single();
  if (!error) return created;
  if (error.code === '23505') { ({ data: conv } = await sel()); return conv; } // created by a parallel request
  throw error;
}

export async function POST(request) {
  if (!secretOk(request)) return bad('forbidden', 403);
  const body = await request.json().catch(() => ({}));

  const phone = waPhone(body.phone);
  if (!phone) return bad('bad phone');
  const sender = body.sender ? String(body.sender) : 'customer';
  if (!(sender in SENDERS)) return bad('bad sender');
  const text = String(body.text ?? '').trim().slice(0, 4000);
  if (!text) return bad('empty text');
  const name = String(body.name || '').trim().slice(0, 80) || null;
  const externalId = body.message_id ? String(body.message_id).slice(0, 120) : null;

  try {
    const db = adminClient();
    const conv = await findOrCreate(db, phone, sender === 'customer' ? name : null);
    const aiOn = conv.ai_enabled && (await globalAiOn(db));

    const { error: mErr } = await db.from('wa_messages').insert({
      conversation_id: conv.id, direction: SENDERS[sender], sender, body: text, external_id: externalId,
    });
    if (mErr?.code === '23505') return NextResponse.json({ ok: true, duplicate: true, conversation_id: conv.id, ai_enabled: aiOn });
    if (mErr) throw mErr;

    const patch = { last_message: text.slice(0, 200), last_message_at: new Date().toISOString() };
    if (sender === 'customer') {
      patch.unread_count = (conv.unread_count || 0) + 1;
      if (name && !conv.contact_name) patch.contact_name = name;
    }
    await db.from('wa_conversations').update(patch).eq('id', conv.id);

    return NextResponse.json({ ok: true, conversation_id: conv.id, ai_enabled: aiOn });
  } catch (e) {
    console.error('[wa inbound]', e?.message || e);
    return bad('server error (شغّل migration_19_whatsapp_inbox.sql)', 500);
  }
}

export async function GET(request) {
  if (!secretOk(request)) return bad('forbidden', 403);
  const phone = waPhone(new URL(request.url).searchParams.get('phone'));
  if (!phone) return bad('bad phone');
  try {
    const db = adminClient();
    const { data } = await db.from('wa_conversations').select('ai_enabled').eq('phone', phone).maybeSingle();
    const aiOn = (data ? data.ai_enabled : true) && (await globalAiOn(db)); // unknown customer = AI on
    return NextResponse.json({ ok: true, ai_enabled: aiOn });
  } catch (e) {
    console.error('[wa status]', e?.message || e);
    return bad('server error', 500);
  }
}
