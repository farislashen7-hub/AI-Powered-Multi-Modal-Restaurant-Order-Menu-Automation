import { NextResponse } from 'next/server';
import { adminClient } from '@/lib/supabase/admin';
import { notifyN8n } from '@/lib/n8n';
import { UUID, bad, globalAiOn, requireStaff } from '@/lib/whatsapp';

// staff/admin: send a reply to the customer on WhatsApp (through n8n). Only while the AI is OFF (this chat or global human takeover).
export async function POST(request, { params }) {
  const { error, profile } = await requireStaff(request);
  if (error) return error;
  if (!UUID.test(params.id)) return bad('bad id');

  const body = await request.json().catch(() => ({}));
  const text = String(body.text ?? '').trim();
  if (!text) return bad('اكتب رسالة الأول');
  if (text.length > 4000) return bad('الرسالة طويلة (الحد 4000 حرف)');

  const db = adminClient();
  const { data: conv } = await db.from('wa_conversations').select('id, phone, ai_enabled').eq('id', params.id).maybeSingle();
  if (!conv) return bad('المحادثة مش موجودة', 404);
  if (conv.ai_enabled && (await globalAiOn(db))) return bad('المساعد الذكي شغال. اضغط "تدخل بشري" الأول', 409);

  const r = await notifyN8n('whatsapp.send', {
    conversation_id: conv.id, phone: conv.phone, number: conv.phone.replace(/\D/g, ''), text, staff: profile?.full_name || null,
  });
  if (!r.ok) return bad('تعذّر الوصول لـ n8n. اتأكد إن الـ workflow شغال والـ webhook res-wa-send موجود', 502);

  const { data: msg, error: mErr } = await db.from('wa_messages')
    .insert({ conversation_id: conv.id, direction: 'out', sender: 'human', body: text })
    .select('id, conversation_id, direction, sender, body, created_at').single();
  if (mErr) { console.error('[wa send]', mErr.message); return bad('اتبعتت بس متسجلتش في المحادثة', 500); }
  await db.from('wa_conversations').update({ last_message: text.slice(0, 200), last_message_at: msg.created_at }).eq('id', conv.id);
  return NextResponse.json({ ok: true, message: msg });
}
