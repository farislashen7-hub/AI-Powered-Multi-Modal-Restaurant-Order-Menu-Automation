import { NextResponse } from 'next/server';
import { adminClient } from '@/lib/supabase/admin';
import { UUID, bad, requireStaff } from '@/lib/whatsapp';

// staff/admin: switch a conversation between "المساعد الذكي" (ai_enabled=true) and "تدخل بشري" (false), or mark it read.
export async function PATCH(request, { params }) {
  const { error } = await requireStaff(request);
  if (error) return error;
  if (!UUID.test(params.id)) return bad('bad id');

  const body = await request.json().catch(() => ({}));
  const patch = {};
  if (typeof body.ai_enabled === 'boolean') {
    patch.ai_enabled = body.ai_enabled;
    patch.human_since = body.ai_enabled ? null : new Date().toISOString();
  }
  if (body.mark_read === true) patch.unread_count = 0;
  if (!Object.keys(patch).length) return bad('nothing to update');

  const { data, error: e } = await adminClient().from('wa_conversations')
    .update(patch).eq('id', params.id).select('id, ai_enabled, human_since, unread_count').maybeSingle();
  if (e) { console.error('[wa patch]', e.message); return bad('تعذّر التحديث', 500); }
  if (!data) return bad('المحادثة مش موجودة', 404);
  return NextResponse.json({ ok: true, conversation: data });
}
