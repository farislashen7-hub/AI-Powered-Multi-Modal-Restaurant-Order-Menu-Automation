import { NextResponse } from 'next/server';
import { adminClient } from '@/lib/supabase/admin';
import { validWebhookSecret, waPhone, mediaRef } from '@/lib/waChat';

// Called by n8n only (x-webhook-secret).
//  IN : { direction:'in',  phone, name, text, media_url?|storage_path?, message_id? }  (media = https URL or Storage path)  -> { ai_enabled }  (n8n continues to the AI only if true)
//  OUT: { direction:'out', sender:'ai'|'human', phone, text, message_id? } -> { blocked }   (n8n sends to WhatsApp only if !blocked)
export async function POST(request) {
  if (!validWebhookSecret(request)) return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  const b = await request.json().catch(() => ({}));

  const direction = b.direction === 'out' ? 'out' : 'in';
  const sender = direction === 'in' ? 'customer' : (b.sender === 'human' ? 'human' : 'ai');
  const phone = waPhone(b.phone);
  const text = String(b.text ?? '').slice(0, 4000);
  const media = mediaRef(b.media_url || b.storage_path || b.media_path);
  if (!phone) return NextResponse.json({ ok: true, skipped: true, ai_enabled: false }); // group / invalid number: AI stays out
  if (!text.trim() && !media) return NextResponse.json({ error: 'empty message' }, { status: 400 });

  const { data, error } = await adminClient().rpc('wa_log_message', {
    p_phone: phone,
    p_name: direction === 'in' ? String(b.name || '') : '',
    p_direction: direction,
    p_sender: sender,
    p_body: text,
    p_media: media || null,
    p_ext: String(b.message_id || '').slice(0, 200) || null,
  });
  if (error) {
    console.error('[wa/log]', error.message);
    // fail closed: if we can't verify mode, don't let the AI talk over a human
    return NextResponse.json({ error: 'db', ai_enabled: false, blocked: true }, { status: 500 });
  }
  return NextResponse.json(data);
}
