import { NextResponse } from 'next/server';
import { adminClient } from '@/lib/supabase/admin';
import { bad, requireStaff } from '@/lib/whatsapp';

// staff/admin: { ai: false } = human intervention ON (AI silent in ALL chats) · { ai: true } = AI answers again
export async function POST(request) {
  const { error, user } = await requireStaff(request);
  if (error) return error;

  const body = await request.json().catch(() => ({}));
  if (typeof body.ai !== 'boolean') return bad('بيانات غلط');

  const { error: e } = await adminClient().from('wa_settings')
    .upsert({ id: 1, ai_enabled: body.ai, changed_by: user.id, changed_at: new Date().toISOString() });
  if (e) { console.error('[wa global]', e.message); return bad('تعذّر تغيير الوضع. شغّل migration_20_global_human.sql', 500); }
  return NextResponse.json({ ok: true, ai: body.ai });
}
