import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getSessionUser } from '@/lib/supabase/server';
import CourierApp from '@/components/CourierApp';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'شاشة المندوب' };

export default async function DeliveryPage() {
  const { supabase, user, profile } = await getSessionUser();
  if (!user) redirect('/login?next=/delivery');
  if (['admin', 'staff'].includes(profile?.role)) redirect('/admin');
  if (profile?.role !== 'delivery') {
    return (
      <main className="mx-auto max-w-md px-4 py-16 text-center">
        <h1 className="text-xl font-bold">الحساب ده مش حساب مندوب</h1>
        <p className="mt-2 text-sm text-ink/70">سجّل كمندوب توصيل من صفحة التسجيل، أو كلّم الإدارة.</p>
        <Link href="/" className="mt-5 inline-flex min-h-[44px] items-center rounded-xl bg-ink px-5 text-sm font-semibold text-white">الرجوع للموقع</Link>
      </main>
    );
  }
  const { data: courier } = await supabase.from('couriers').select('courier_no, status, out_reason').eq('id', user.id).maybeSingle();
  return (
    <CourierApp
      me={{ id: user.id, name: profile.full_name || 'مندوب', phone: profile.phone || '', email: user.email || '' }}
      initialCourier={courier || { courier_no: null, status: 'available', out_reason: null }}
    />
  );
}
