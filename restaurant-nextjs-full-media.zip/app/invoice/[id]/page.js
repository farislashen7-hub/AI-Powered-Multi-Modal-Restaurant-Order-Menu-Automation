import Link from 'next/link';
import { notFound } from 'next/navigation';
import { adminClient } from '@/lib/supabase/admin';
import { getSite } from '@/lib/settings';
import InvoiceView from '@/components/InvoiceView';
import PrintButton from '@/components/PrintButton';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'الفاتورة', robots: { index: false, follow: false } };

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// The order id (random uuid) is the access token: only someone who has the link can open it.
export default async function InvoicePage({ params }) {
  if (!UUID.test(params.id)) notFound();
  const { data: order } = await adminClient()
    .from('orders')
    .select('id, order_no, order_type, created_at, customer_name, phone, address, notes, status, total, delivery_fee, order_items(name, qty, unit_price, extras, extras_total)')
    .eq('id', params.id).maybeSingle();
  if (!order) notFound();
  const info = await getSite();
  return (
    <main className="mx-auto max-w-md px-4 py-8 print:p-0">
      <InvoiceView order={order} info={info} />
      <div className="mt-4 flex gap-2 print:hidden">
        <PrintButton />
        <Link href="/" className="inline-flex min-h-[44px] items-center rounded-xl px-5 text-sm font-semibold ring-1 ring-ink/20">رجوع للموقع</Link>
      </div>
    </main>
  );
}
