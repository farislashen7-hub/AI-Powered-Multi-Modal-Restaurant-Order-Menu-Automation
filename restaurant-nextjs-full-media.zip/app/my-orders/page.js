import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import InvoiceView from '@/components/InvoiceView';
import CancelRequestButton from '@/components/CancelRequestButton';
import { listMyOrders } from '@/lib/orderAccess';
import { getSite } from '@/lib/settings';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'طلباتي' };

const STATUS = {
  pending: ['قيد الانتظار', 'bg-saf/30 text-ink'],
  preparing: ['بيتحضّر', 'bg-mint text-ink'],
  ready: ['جاهز', 'bg-emerald-100 text-emerald-800'],
  delivered: ['اتسلّم', 'bg-emerald-100 text-emerald-800'],
  cancelled: ['ملغي', 'bg-coral/15 text-coral'],
};

export default async function MyOrders() {
  const { orders, error } = await listMyOrders();

  const info = await getSite();

  return (
    <>
      <Header />
      <main className="mx-auto max-w-2xl px-4 py-10">
        <h1 className="mb-1 text-2xl font-bold">طلباتي</h1>
        <p className="mb-6 text-xs text-ink/60">الطلبات بتفضل ظاهرة 12 ساعة بس وبعدها بتتمسح من القايمة دي.</p>

        {error && (
          <div role="alert" className="mb-4 rounded-2xl bg-coral/15 p-4 text-sm text-coral">
            {/device_token/i.test(error) ? 'شغّل supabase/migration_09_guest_my_orders.sql في Supabase الأول.' : 'تعذّر تحميل الطلبات، حاول تاني.'}
          </div>
        )}

        {!error && (!orders || orders.length === 0) && (
          <div className="rounded-2xl bg-white p-8 text-center ring-1 ring-ink/10">
            <p className="text-ink/70">لسه معندكش طلبات.</p>
            <Link href="/#menu" className="mt-4 inline-flex min-h-[44px] items-center rounded-xl bg-ink px-5 text-sm font-semibold text-white">اطلب دلوقتي</Link>
          </div>
        )}

        <ul className="space-y-4">
          {(orders || []).map((o) => {
            const [label, cls] = STATUS[o.status] || [o.status, 'bg-ink/10'];
            const code = o.order_no ? `#${o.order_no}` : `#${String(o.id).slice(0, 8).toUpperCase()}`;
            return (
              <li key={o.id} className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold">طلب {code}</span>
                  <span className={`rounded-full px-3 py-1 text-xs font-semibold ${cls}`}>{label}</span>
                </div>
                <details className="mt-3">
                  <summary className="min-h-[44px] cursor-pointer py-2 text-sm font-semibold underline">عرض التفاصيل</summary>
                  <div className="mt-2"><InvoiceView order={o} info={info} /></div>
                </details>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Link href={`/invoice/${o.id}`} target="_blank" className="inline-flex min-h-[44px] items-center rounded-xl px-4 text-sm font-semibold ring-1 ring-ink/20">الفاتورة</Link>
                  {['pending', 'preparing'].includes(o.status) && <CancelRequestButton orderId={o.id} direct={o.status === 'pending'} />}
                </div>
                {o.status === 'cancelled' && <p className="mt-2 text-xs text-ink/60">الطلب ده اتلغى من المطعم.</p>}
              </li>
            );
          })}
        </ul>
      </main>
      <Footer info={info} />
    </>
  );
}
