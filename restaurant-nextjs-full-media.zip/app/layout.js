import './globals.css';
import { IBM_Plex_Sans_Arabic } from 'next/font/google';

const font = IBM_Plex_Sans_Arabic({
  subsets: ['arabic', 'latin'],
  weight: ['400', '500', '600', '700'],
  display: 'swap',
  variable: '--font-plex',
});

export const metadata = {
  title: 'مطعمنا',
  description: 'اطلب أشهى الأكلات أونلاين',
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl" className={font.variable}>
      <body className="min-h-screen bg-[#F6F7F4] font-sans text-ink antialiased">{children}</body>
    </html>
  );
}
