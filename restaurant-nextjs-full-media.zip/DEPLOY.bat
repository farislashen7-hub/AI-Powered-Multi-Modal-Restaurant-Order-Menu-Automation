@echo off
cd /d "%~dp0"
if not exist "app\my-orders\page.js" (
  echo ERROR: wrong folder.
  pause
  exit /b 1
)
rem one-time: install CLI globally (npx re-downloads it every run = slow)
where vercel >nul 2>nul
if errorlevel 1 (
  echo Installing Vercel CLI once...
  call npm i -g vercel
)
rem link only the first time
if not exist ".vercel\project.json" (
  call vercel link --yes --project restourant21 --scope portfolio-site8
  if errorlevel 1 (
    echo Link failed. Run: vercel login
    pause
    exit /b 1
  )
)
echo Deploying to production...
call vercel --prod --yes
pause
