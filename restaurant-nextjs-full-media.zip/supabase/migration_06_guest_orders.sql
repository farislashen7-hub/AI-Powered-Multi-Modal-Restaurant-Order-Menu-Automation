-- Run AFTER migration_05. Idempotent.
-- Guest checkout (no login) + invoice number + order rate-limit.
-- Orders are now created ONLY by the server (service_role) via create_order_server().

alter table public.orders alter column user_id drop not null;
alter table public.orders add column if not exists order_no bigint generated always as identity (start with 1001);

-- generic rate limiter (service_role only)
create table if not exists public.rate_limits (
  key text primary key,
  hits int not null default 0,
  window_start timestamptz not null default now()
);
alter table public.rate_limits enable row level security;  -- no policies

create or replace function public.rate_hit(p_key text, p_limit int, p_window_secs int)
returns boolean language plpgsql security definer set search_path = public as $$
declare r public.rate_limits;
begin
  insert into public.rate_limits as a (key, hits, window_start) values (p_key, 1, now())
  on conflict (key) do update set
    hits = case when a.window_start < now() - make_interval(secs => p_window_secs) then 1 else a.hits + 1 end,
    window_start = case when a.window_start < now() - make_interval(secs => p_window_secs) then now() else a.window_start end
  returning * into r;
  return r.hits <= p_limit;
end $$;
revoke all on function public.rate_hit(text, int, int) from public, anon, authenticated;
grant execute on function public.rate_hit(text, int, int) to service_role;
grant all on public.rate_limits to service_role;

-- server-side order creation (user may be null = guest). Prices always come from DB.
create or replace function public.create_order_server(
  p_user uuid, p_name text, p_phone text, p_address text, p_notes text, p_items jsonb)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_order uuid; v_total numeric; v_name text := nullif(left(trim(coalesce(p_name, '')), 80), '');
  r record; l record; m public.menu_items%rowtype;
  v_extras jsonb; v_etotal numeric;
begin
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'empty cart';
  end if;
  if v_name is null and p_user is not null then
    select full_name into v_name from public.profiles where id = p_user;
  end if;
  insert into public.orders (user_id, customer_name, phone, address, notes)
  values (p_user, v_name, left(p_phone, 30), left(p_address, 300), left(p_notes, 500))
  returning id into v_order;

  for r in
    select id, sum(q)::int as qty from (
      select (i->>'id')::uuid as id,
             least(greatest(coalesce((i->>'qty')::int, 1), 1), 50) as q
      from jsonb_array_elements(p_items) i) s
    group by id order by id
  loop
    select * into m from public.menu_items where id = r.id and available for update;
    if not found then continue; end if;
    if m.track_stock then
      if m.stock_qty < r.qty then raise exception 'out of stock: %', m.name; end if;
      update public.menu_items set stock_qty = stock_qty - r.qty where id = m.id;
    end if;
  end loop;

  for l in
    select (i->>'id')::uuid as id,
           least(greatest(coalesce((i->>'qty')::int, 1), 1), 50) as qty,
           case when jsonb_typeof(i->'extras') = 'array' then i->'extras' else '[]'::jsonb end as extras
    from jsonb_array_elements(p_items) i
  loop
    select * into m from public.menu_items where id = l.id and available;
    if not found then continue; end if;
    select coalesce(jsonb_agg(jsonb_build_object('name', e.name, 'price', e.price) order by e.sort_order, e.name), '[]'::jsonb),
           coalesce(sum(e.price), 0)
      into v_extras, v_etotal
    from public.menu_item_extras e
    where e.menu_item_id = m.id and e.available
      and e.id::text in (select jsonb_array_elements_text(l.extras));
    insert into public.order_items (order_id, menu_item_id, name, unit_price, qty, extras, extras_total)
    values (v_order, m.id, m.name, m.price, l.qty, v_extras, v_etotal);
  end loop;

  select coalesce(sum((unit_price + extras_total) * qty), 0) into v_total
  from public.order_items where order_id = v_order;
  if v_total = 0 then raise exception 'no valid items'; end if;
  update public.orders set total = v_total where id = v_order;
  return v_order;
end $$;
revoke all on function public.create_order_server(uuid, text, text, text, text, jsonb) from public, anon, authenticated;
grant execute on function public.create_order_server(uuid, text, text, text, text, jsonb) to service_role;

-- close the old client-callable path (it bypassed rate limits)
revoke execute on function public.create_order(jsonb, text, text, text) from public, anon, authenticated;
