-- Run AFTER migration_04. Idempotent. Lock 60s after 5 wrong passwords.
create table if not exists public.login_attempts (
  key text primary key,
  fails int not null default 0,
  locked_until timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.login_attempts enable row level security; -- no policies: only service_role

create or replace function public.login_check(p_key text) returns int
language sql security definer set search_path = public as $$
  select coalesce(ceil(extract(epoch from (locked_until - now())))::int, 0)
  from public.login_attempts where key = p_key and locked_until > now()
  union all select 0 limit 1;
$$;

create or replace function public.login_fail(p_key text) returns int
language plpgsql security definer set search_path = public as $$
declare r public.login_attempts;
begin
  insert into public.login_attempts as a (key, fails) values (p_key, 1)
  on conflict (key) do update set
    fails = case when a.updated_at < now() - interval '15 minutes' then 1 else a.fails + 1 end,
    updated_at = now()
  returning * into r;
  if r.fails >= 5 then
    update public.login_attempts set fails = 0, locked_until = now() + interval '60 seconds' where key = p_key;
    return 60;
  end if;
  return 0;
end $$;

create or replace function public.login_ok(p_key text) returns void
language sql security definer set search_path = public as $$
  delete from public.login_attempts where key = p_key;
$$;

revoke all on function public.login_check(text), public.login_fail(text), public.login_ok(text) from public, anon, authenticated;
grant execute on function public.login_check(text), public.login_fail(text), public.login_ok(text) to service_role;
grant all on public.login_attempts to service_role;
