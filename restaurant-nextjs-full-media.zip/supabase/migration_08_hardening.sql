-- Run AFTER migration_07. Idempotent. Security hardening.

-- 1) rate_limits / login_attempts must not grow forever (cleanup ~1% of calls)
create or replace function public.rate_hit(p_key text, p_limit int, p_window_secs int)
returns boolean language plpgsql security definer set search_path = public as $$
declare r public.rate_limits;
begin
  if random() < 0.01 then
    delete from public.rate_limits where window_start < now() - interval '1 day';
    delete from public.login_attempts where updated_at < now() - interval '1 day';
  end if;
  insert into public.rate_limits as a (key, hits, window_start) values (left(p_key, 200), 1, now())
  on conflict (key) do update set
    hits = case when a.window_start < now() - make_interval(secs => p_window_secs) then 1 else a.hits + 1 end,
    window_start = case when a.window_start < now() - make_interval(secs => p_window_secs) then now() else a.window_start end
  returning * into r;
  return r.hits <= p_limit;
end $$;
revoke all on function public.rate_hit(text, int, int) from public, anon, authenticated;
grant execute on function public.rate_hit(text, int, int) to service_role;

-- 2) make sure the old client-callable order function is closed (even if re-created by schema.sql)
do $$ begin
  if to_regprocedure('public.create_order(jsonb,text,text,text)') is not null then
    revoke execute on function public.create_order(jsonb, text, text, text) from public, anon, authenticated;
  end if;
end $$;

-- 3) customers' phone/address only readable by owner/staff/admin (policies exist); verify RLS is ON everywhere
alter table public.orders             enable row level security;
alter table public.order_items        enable row level security;
alter table public.profiles           enable row level security;
alter table public.menu_items         enable row level security;
alter table public.menu_item_extras   enable row level security;
alter table public.site_settings      enable row level security;
alter table public.rate_limits        enable row level security;
alter table public.login_attempts     enable row level security;
