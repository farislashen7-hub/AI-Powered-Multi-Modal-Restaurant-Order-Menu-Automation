-- Run AFTER migration_17. Idempotent. Owner-editable WhatsApp text per offer (null = auto-built message).
alter table public.offers add column if not exists wa_message text;
alter table public.offers drop constraint if exists offers_wa_message_check;
alter table public.offers add constraint offers_wa_message_check
  check (wa_message is null or char_length(wa_message) <= 1000);

grant update (title, description, price, old_price, valid_until, active, image_url, image_path,
              card_theme, card_layout, badge_text, card_bg, card_fg, card_accent, wa_message) on public.offers to authenticated;
