-- Run AFTER migration_11. Idempotent. Offer image (stored in the existing public 'menu-images' bucket).
alter table public.offers add column if not exists image_url text;
alter table public.offers add column if not exists image_path text;
grant update (title, description, price, old_price, valid_until, active, image_url, image_path) on public.offers to authenticated;
