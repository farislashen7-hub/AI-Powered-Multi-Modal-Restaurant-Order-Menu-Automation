-- Run AFTER schema.sql + migration_02. Idempotent.
-- Adds: staff role, staff management, menu extras (add-ons), extras in orders/reports.

-- 1) Staff role + email on profiles -------------------------------------
alter table public.profiles add column if not exists email text;
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles
  add constraint profiles_role_check check (role in ('customer','staff','admin'));

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, phone, email)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone', new.email)
  on conflict (id) do nothing;
  return new;
end $$;

-- profile for every existing auth user
insert into public.profiles (id, full_name, phone, email)
select id, raw_user_meta_data->>'full_name', raw_user_meta_data->>'phone', email
from auth.users
on conflict (id) do update set email = excluded.email;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role in ('staff','admin'));
$$;

-- admin can change roles of OTHER users (never own row: no self-lockout)
drop policy if exists "profile admin update" on public.profiles;
create policy "profile admin update" on public.profiles for update
  using (public.is_admin() and id <> auth.uid())
  with check (public.is_admin() and id <> auth.uid());

-- staff: read + update status of orders (not menu, not reports, not profiles)
drop policy if exists "orders staff read" on public.orders;
create policy "orders staff read" on public.orders for select using (public.is_staff());
drop policy if exists "orders staff update" on public.orders;
create policy "orders staff update" on public.orders for update
  using (public.is_staff()) with check (public.is_staff());
drop policy if exists "order_items staff read" on public.order_items;
create policy "order_items staff read" on public.order_items for select using (public.is_staff());

-- only `status` is updatable on orders from the client (total/phone/... locked)
revoke update on public.orders from anon, authenticated;
grant  update (status) on public.orders to authenticated;

-- 2) Menu extras ---------------------------------------------------------
create table if not exists public.menu_item_extras (
  id uuid primary key default gen_random_uuid(),
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  price numeric(10,2) not null default 0 check (price >= 0),
  available boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists menu_item_extras_item_idx on public.menu_item_extras (menu_item_id);
alter table public.menu_item_extras enable row level security;

drop policy if exists "extras public read" on public.menu_item_extras;
create policy "extras public read" on public.menu_item_extras for select
  using (available or public.is_admin());
drop policy if exists "extras admin write" on public.menu_item_extras;
create policy "extras admin write" on public.menu_item_extras for all
  using (public.is_admin()) with check (public.is_admin());

-- price snapshot of chosen extras per order line
alter table public.order_items
  add column if not exists extras jsonb not null default '[]'::jsonb,
  add column if not exists extras_total numeric(10,2) not null default 0;

-- 3) create_order: cart lines = {id, qty, extras:[extra_id,...]} ----------
-- Prices (item + extras) always come from the DB, never from the client.
create or replace function public.create_order(p_items jsonb, p_phone text, p_address text, p_notes text)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_order uuid; v_total numeric; v_name text;
  r record; l record; m public.menu_items%rowtype;
  v_extras jsonb; v_etotal numeric;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'empty cart';
  end if;
  select full_name into v_name from public.profiles where id = auth.uid();
  insert into public.orders (user_id, customer_name, phone, address, notes)
  values (auth.uid(), v_name, left(p_phone, 30), left(p_address, 300), left(p_notes, 500))
  returning id into v_order;

  -- stock: grouped per item, ordered by id (row locks, no deadlock)
  for r in
    select id, sum(q)::int as qty from (
      select (i->>'id')::uuid as id,
             least(greatest(coalesce((i->>'qty')::int, 1), 1), 50) as q
      from jsonb_array_elements(p_items) i) s
    group by id order by id
  loop
    select * into m from public.menu_items where id = r.id and available for update;
    if not found then continue; end if;
    if m.track_stock then
      if m.stock_qty < r.qty then raise exception 'out of stock: %', m.name; end if;
      update public.menu_items set stock_qty = stock_qty - r.qty where id = m.id;
    end if;
  end loop;

  -- one order line per (item, extras combination)
  for l in
    select (i->>'id')::uuid as id,
           least(greatest(coalesce((i->>'qty')::int, 1), 1), 50) as qty,
           case when jsonb_typeof(i->'extras') = 'array' then i->'extras' else '[]'::jsonb end as extras
    from jsonb_array_elements(p_items) i
  loop
    select * into m from public.menu_items where id = l.id and available;
    if not found then continue; end if;
    select coalesce(jsonb_agg(jsonb_build_object('name', e.name, 'price', e.price) order by e.sort_order, e.name), '[]'::jsonb),
           coalesce(sum(e.price), 0)
      into v_extras, v_etotal
    from public.menu_item_extras e
    where e.menu_item_id = m.id and e.available
      and e.id::text in (select jsonb_array_elements_text(l.extras));
    insert into public.order_items (order_id, menu_item_id, name, unit_price, qty, extras, extras_total)
    values (v_order, m.id, m.name, m.price, l.qty, v_extras, v_etotal);
  end loop;

  select coalesce(sum((unit_price + extras_total) * qty), 0) into v_total
  from public.order_items where order_id = v_order;
  if v_total = 0 then raise exception 'no valid items'; end if;
  update public.orders set total = v_total where id = v_order;
  return v_order;
end $$;
revoke all on function public.create_order(jsonb, text, text, text) from public, anon;
grant execute on function public.create_order(jsonb, text, text, text) to authenticated;

-- 4) sales_report counts extras ------------------------------------------
create or replace function public.sales_report(p_from timestamptz, p_to timestamptz)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return jsonb_build_object(
    'orders',    (select count(*) from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled'),
    'cancelled', (select count(*) from orders where created_at >= p_from and created_at < p_to and status = 'cancelled'),
    'revenue',   (select coalesce(sum(total), 0) from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled'),
    'delivered_revenue', (select coalesce(sum(total), 0) from orders where created_at >= p_from and created_at < p_to and status = 'delivered'),
    'daily', (select coalesce(jsonb_agg(to_jsonb(d) order by d.day), '[]'::jsonb) from (
        select (created_at at time zone 'Africa/Cairo')::date as day, count(*) as orders, sum(total) as revenue
        from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled' group by 1) d),
    'top_items', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (
        select oi.name, sum(oi.qty)::int as qty, sum(oi.qty * (oi.unit_price + oi.extras_total)) as revenue
        from order_items oi join orders o on o.id = oi.order_id
        where o.created_at >= p_from and o.created_at < p_to and o.status <> 'cancelled'
        group by oi.name order by qty desc limit 10) t)
  );
end $$;
revoke all on function public.sales_report(timestamptz, timestamptz) from public, anon;
grant execute on function public.sales_report(timestamptz, timestamptz) to authenticated;

-- 5) Make yourself admin --------------------------------------------------
update public.profiles set role = 'admin'
where id = (select id from auth.users where email = 'farislashen7@gmail.com');
