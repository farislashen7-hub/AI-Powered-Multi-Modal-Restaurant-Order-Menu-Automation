-- Run AFTER migration_10. Idempotent.
-- 1) Reports: orders.area + richer sales_report (top dish, top areas, order types, peak hours)
-- 2) Offers: owner-managed offers + WhatsApp broadcast bookkeeping
-- 3) Delivery: 'delivery' role, couriers profile (ID, status), order assignment

-- ============ 1) Orders: area + courier columns ============
alter table public.orders add column if not exists area text check (char_length(area) <= 80);
alter table public.orders add column if not exists courier_id uuid references public.profiles(id) on delete set null;
alter table public.orders add column if not exists assigned_at timestamptz;
alter table public.orders add column if not exists delivered_at timestamptz;
create index if not exists orders_courier_idx on public.orders (courier_id, status);
create index if not exists orders_created_area_idx on public.orders (created_at, area);
-- clients can still only update `status` (grant from migration_03 unchanged);
-- courier_id / delivered_at are written by the server (service_role) only.

-- ============ 2) Offers ============
create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 80),
  description text check (char_length(description) <= 500),
  price numeric(10,2) check (price >= 0),
  old_price numeric(10,2) check (old_price >= 0),
  valid_until date,
  active boolean not null default true,
  last_sent_at timestamptz,
  sent_count int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.offers enable row level security;
drop policy if exists "offers public read active" on public.offers;
create policy "offers public read active" on public.offers for select
  using ((active and (valid_until is null or valid_until >= current_date)) or public.is_admin());
drop policy if exists "offers admin write" on public.offers;
create policy "offers admin write" on public.offers for all
  using (public.is_admin()) with check (public.is_admin());
-- broadcast bookkeeping is written by the server only
revoke update on public.offers from anon, authenticated;
grant update (title, description, price, old_price, valid_until, active) on public.offers to authenticated;

-- ============ 3) Delivery ============
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles
  add constraint profiles_role_check check (role in ('customer','staff','admin','delivery'));

create table if not exists public.couriers (
  id uuid primary key references public.profiles(id) on delete cascade,
  courier_no int generated always as identity (start with 1),
  status text not null default 'available' check (status in ('available','out_of_service')),
  out_reason text check (char_length(out_reason) <= 120),
  status_changed_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (courier_no)
);
alter table public.couriers enable row level security;
drop policy if exists "couriers read own/staff" on public.couriers;
create policy "couriers read own/staff" on public.couriers for select
  using (id = auth.uid() or public.is_staff());
revoke insert, update, delete on public.couriers from anon, authenticated; -- server (service_role) writes only

-- role = delivery -> courier row (ID) is created automatically; leaving the role frees active orders
create or replace function public.ensure_courier() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role = 'delivery' then
    insert into public.couriers (id) values (new.id) on conflict (id) do nothing;
  end if;
  if tg_op = 'UPDATE' then
    if old.role = 'delivery' and new.role <> 'delivery' then
      update public.orders set courier_id = null, assigned_at = null
      where courier_id = new.id and status not in ('delivered', 'cancelled');
    end if;
  end if;
  return new;
end $$;
drop trigger if exists profiles_courier_trg on public.profiles;
create trigger profiles_courier_trg after insert or update of role on public.profiles
  for each row execute function public.ensure_courier();
insert into public.couriers (id) select id from public.profiles where role = 'delivery' on conflict do nothing;

-- courier sees only orders assigned to him
drop policy if exists "orders courier read" on public.orders;
create policy "orders courier read" on public.orders for select using (courier_id = auth.uid());
drop policy if exists "order_items courier read" on public.order_items;
create policy "order_items courier read" on public.order_items for select using (
  exists (select 1 from public.orders o where o.id = order_id and o.courier_id = auth.uid()));

-- ============ 4) sales_report v3 ============
create or replace function public.sales_report(p_from timestamptz, p_to timestamptz)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return jsonb_build_object(
    'orders',    (select count(*) from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled'),
    'cancelled', (select count(*) from orders where created_at >= p_from and created_at < p_to and status = 'cancelled'),
    'revenue',   (select coalesce(sum(total), 0) from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled'),
    'delivered_revenue', (select coalesce(sum(total), 0) from orders where created_at >= p_from and created_at < p_to and status = 'delivered'),
    'avg_order', (select coalesce(round(avg(total), 2), 0) from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled'),
    'daily', (select coalesce(jsonb_agg(to_jsonb(d) order by d.day), '[]'::jsonb) from (
        select (created_at at time zone 'Africa/Cairo')::date as day, count(*) as orders, sum(total) as revenue
        from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled' group by 1) d),
    'top_items', (select coalesce(jsonb_agg(to_jsonb(t) order by t.qty desc, t.revenue desc), '[]'::jsonb) from (
        select oi.name, sum(oi.qty)::int as qty, sum(oi.qty * (oi.unit_price + oi.extras_total)) as revenue
        from order_items oi join orders o on o.id = oi.order_id
        where o.created_at >= p_from and o.created_at < p_to and o.status <> 'cancelled'
        group by oi.name order by qty desc, revenue desc limit 10) t),
    'top_areas', (select coalesce(jsonb_agg(to_jsonb(a) order by a.orders desc, a.revenue desc), '[]'::jsonb) from (
        select area, count(*)::int as orders, sum(total) as revenue from (
          select coalesce(nullif(lower(trim(regexp_replace(o.area, '\s+', ' ', 'g'))), ''), 'غير محدد') as area, o.total
          from orders o
          where o.created_at >= p_from and o.created_at < p_to and o.status <> 'cancelled' and o.order_type = 'delivery') x
        group by area order by orders desc, revenue desc limit 10) a),
    'by_type', (select coalesce(jsonb_agg(to_jsonb(b)), '[]'::jsonb) from (
        select order_type as type, count(*)::int as orders, sum(total) as revenue
        from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled' group by 1) b),
    'by_hour', (select coalesce(jsonb_agg(to_jsonb(h) order by h.hour), '[]'::jsonb) from (
        select extract(hour from created_at at time zone 'Africa/Cairo')::int as hour, count(*)::int as orders
        from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled' group by 1) h)
  );
end $$;
revoke all on function public.sales_report(timestamptz, timestamptz) from public, anon;
grant execute on function public.sales_report(timestamptz, timestamptz) to authenticated;
