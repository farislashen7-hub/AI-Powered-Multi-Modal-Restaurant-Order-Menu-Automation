-- !! DESTRUCTIVE !! Deletes ALL data in these public tables (old integer-id schema).
-- Run ONLY if the Supabase project holds test data. Then run, in order:
--   schema.sql -> migration_02_inventory_reports.sql -> migration_03_staff_extras.sql
drop function if exists public.add_menu_items_bulk(jsonb);
drop function if exists public.create_order(jsonb, text, text, text);
drop function if exists public.sales_report(timestamptz, timestamptz);

drop table if exists
  public.order_item_extras, public.menu_item_extras, public.order_status_history,
  public.order_items, public.orders, public.menu_items, public.categories, public.profiles
cascade;

-- storage policies are recreated by schema.sql
drop policy if exists "menu-images public read"   on storage.objects;
drop policy if exists "menu-images admin insert"  on storage.objects;
drop policy if exists "menu-images admin update"  on storage.objects;
drop policy if exists "menu-images admin delete"  on storage.objects;
