-- Run AFTER migration_18. Idempotent.
-- WhatsApp inbox: every conversation + message is stored here.
-- ai_enabled = true  -> the AI assistant (n8n) may reply.
-- ai_enabled = false -> human takeover: the AI stays silent until staff press "المساعد الذكي".
-- All writes happen server-side (service_role). Staff/admin only read (RLS) so realtime works.

create table if not exists public.wa_conversations (
  id uuid primary key default gen_random_uuid(),
  phone text not null unique check (char_length(phone) between 6 and 20),
  contact_name text check (contact_name is null or char_length(contact_name) <= 80),
  ai_enabled boolean not null default true,
  human_since timestamptz,
  unread_count int not null default 0 check (unread_count >= 0),
  last_message text,
  last_message_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index if not exists wa_conversations_last_idx on public.wa_conversations (last_message_at desc);

create table if not exists public.wa_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.wa_conversations(id) on delete cascade,
  direction text not null check (direction in ('in', 'out')),
  sender text not null check (sender in ('customer', 'ai', 'human')),
  body text not null check (char_length(body) between 1 and 4000),
  external_id text check (external_id is null or char_length(external_id) <= 120),
  created_at timestamptz not null default now()
);
create index if not exists wa_messages_conv_idx on public.wa_messages (conversation_id, created_at);
-- same WhatsApp message delivered twice by n8n/Evolution is stored once
create unique index if not exists wa_messages_ext_uq on public.wa_messages (conversation_id, external_id) where external_id is not null;

alter table public.wa_conversations enable row level security;
alter table public.wa_messages enable row level security;

drop policy if exists "wa_conversations staff read" on public.wa_conversations;
create policy "wa_conversations staff read" on public.wa_conversations for select using (public.is_staff());
drop policy if exists "wa_messages staff read" on public.wa_messages;
create policy "wa_messages staff read" on public.wa_messages for select using (public.is_staff());

revoke all on public.wa_conversations from anon, authenticated;
revoke all on public.wa_messages from anon, authenticated;
grant select on public.wa_conversations to authenticated;
grant select on public.wa_messages to authenticated;

-- realtime (safe to re-run)
do $$
begin
  begin alter publication supabase_realtime add table public.wa_conversations; exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.wa_messages; exception when duplicate_object then null; end;
end $$;
