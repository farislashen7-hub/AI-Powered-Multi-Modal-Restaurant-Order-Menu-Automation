-- Run AFTER migration_08. Idempotent.
-- Guest "طلباتي": device token links guest orders to the browser that placed them.
alter table public.orders add column if not exists device_token text;
create index if not exists orders_device_idx on public.orders (device_token, created_at desc);

-- OPTIONAL hard delete after 12h (also wipes data used by admin reports!). Default = hide from customer only.
-- create extension if not exists pg_cron;
-- select cron.schedule('purge-old-orders', '0 * * * *',
--   $$delete from public.orders where created_at < now() - interval '12 hours'$$);
