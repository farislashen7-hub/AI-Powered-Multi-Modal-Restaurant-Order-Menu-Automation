-- Run after migration_03. Idempotent. Restaurant contact info editable from /admin/settings.
create table if not exists public.site_settings (
  id int primary key default 1 check (id = 1),
  phone     text check (char_length(phone)     <= 30),
  whatsapp  text check (char_length(whatsapp)  <= 30),
  address   text check (char_length(address)   <= 300),
  maps_url  text check (char_length(maps_url)  <= 500),
  instagram text check (char_length(instagram) <= 300),
  facebook  text check (char_length(facebook)  <= 300),
  hours     text check (char_length(hours)     <= 200),
  updated_at timestamptz not null default now()
);
insert into public.site_settings (id) values (1) on conflict (id) do nothing;
alter table public.site_settings enable row level security;

drop policy if exists "settings public read" on public.site_settings;
create policy "settings public read" on public.site_settings for select using (true);
drop policy if exists "settings admin write" on public.site_settings;
create policy "settings admin write" on public.site_settings for all
  using (public.is_admin()) with check (public.is_admin());
