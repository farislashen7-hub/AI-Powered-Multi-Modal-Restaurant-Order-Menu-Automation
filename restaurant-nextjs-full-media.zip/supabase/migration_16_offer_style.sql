-- Run AFTER migration_12. Idempotent. Owner-controlled offer look (theme, layout, badge text).
alter table public.offers add column if not exists card_theme text not null default 'classic';
alter table public.offers add column if not exists card_layout text not null default 'card';
alter table public.offers add column if not exists badge_text text;

alter table public.offers drop constraint if exists offers_card_theme_check;
alter table public.offers add constraint offers_card_theme_check
  check (card_theme in ('classic','dark','saffron','coral','mint','royal'));
alter table public.offers drop constraint if exists offers_card_layout_check;
alter table public.offers add constraint offers_card_layout_check
  check (card_layout in ('card','banner'));
alter table public.offers drop constraint if exists offers_badge_text_check;
alter table public.offers add constraint offers_badge_text_check
  check (badge_text is null or char_length(badge_text) <= 20);

grant update (title, description, price, old_price, valid_until, active, image_url, image_path,
              card_theme, card_layout, badge_text) on public.offers to authenticated;
