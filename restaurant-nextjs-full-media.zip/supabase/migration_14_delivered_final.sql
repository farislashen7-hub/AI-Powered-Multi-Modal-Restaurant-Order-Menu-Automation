-- Run AFTER migration_13. Idempotent.
-- Rules: (1) delivered_at is stamped automatically whenever an order becomes 'delivered' (courier OR staff)
--        (2) a delivered order can NOT be cancelled (stock must not be returned for food already handed over)
--        (3) cancelled stays final + cancelling returns stock (unchanged)
create or replace function public.orders_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.status = 'cancelled' and new.status <> 'cancelled' then
    raise exception 'cancelled order cannot be reopened';
  end if;
  if old.status = 'delivered' and new.status = 'cancelled' then
    raise exception 'delivered order cannot be cancelled';
  end if;
  if new.status = 'cancelled' and old.status <> 'cancelled' then
    update public.menu_items m set stock_qty = m.stock_qty + oi.qty
    from public.order_items oi
    where oi.order_id = new.id and oi.menu_item_id = m.id and m.track_stock;
  end if;
  if new.status = 'delivered' and old.status <> 'delivered' then
    new.delivered_at := coalesce(new.delivered_at, now());
  elsif old.status = 'delivered' and new.status <> 'delivered' then
    new.delivered_at := null;  -- reopened by admin/staff: no longer counted as delivered
  end if;
  return new;
end $$;
drop trigger if exists orders_guard_trg on public.orders;
create trigger orders_guard_trg before update of status on public.orders
  for each row execute function public.orders_guard();

-- old rows that were marked delivered by staff before this fix (no timestamp)
update public.orders set delivered_at = created_at where status = 'delivered' and delivered_at is null;
