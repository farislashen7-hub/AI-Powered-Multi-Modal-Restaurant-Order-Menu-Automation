-- Run AFTER migration_20. Idempotent.
-- Media (images/voice/video) is uploaded by n8n AFTER the text row is logged. When n8n calls wa_log_message a second time
-- with the same external_id + p_media, the existing message now gets its media_url filled in (realtime UPDATE shows it live).
create or replace function public.wa_log_message(
  p_phone text, p_name text, p_direction text, p_sender text,
  p_body text, p_media text default null, p_ext text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_mode text; v_id bigint;
  v_body text := left(coalesce(p_body, ''), 4000);
begin
  insert into public.wa_chats (phone, customer_name)
  values (p_phone, nullif(left(trim(coalesce(p_name, '')), 80), ''))
  on conflict (phone) do update
    set customer_name = coalesce(public.wa_chats.customer_name, excluded.customer_name);

  select mode into v_mode from public.wa_chats where phone = p_phone for update;

  if p_direction = 'out' and p_sender = 'ai' and v_mode = 'human' then
    return jsonb_build_object('ok', true, 'blocked', true, 'ai_enabled', false, 'mode', v_mode);
  end if;

  insert into public.wa_messages (phone, direction, sender, body, media_url, external_id)
  values (p_phone, p_direction, p_sender, v_body, nullif(p_media, ''), nullif(p_ext, ''))
  on conflict (external_id) where external_id is not null do nothing
  returning id into v_id;

  if v_id is null then  -- duplicate delivery OR late media for an already-logged message
    if nullif(p_media, '') is not null and nullif(p_ext, '') is not null then
      update public.wa_messages set media_url = p_media
      where external_id = p_ext and phone = p_phone and (media_url is null or media_url = '');
    end if;
    return jsonb_build_object('ok', true, 'duplicate', true, 'ai_enabled', v_mode = 'ai', 'mode', v_mode);
  end if;

  update public.wa_chats set
    last_message    = left(case when v_body <> '' then v_body else '[مرفق]' end, 200),
    last_sender     = p_sender,
    last_message_at = now(),
    unread_count    = case when p_direction = 'in' then unread_count + 1
                           when p_sender = 'human'  then 0
                           else unread_count end
  where phone = p_phone;

  return jsonb_build_object('ok', true, 'id', v_id, 'ai_enabled', v_mode = 'ai', 'mode', v_mode);
end $$;
revoke all on function public.wa_log_message(text, text, text, text, text, text, text) from public, anon, authenticated;
grant execute on function public.wa_log_message(text, text, text, text, text, text, text) to service_role;
