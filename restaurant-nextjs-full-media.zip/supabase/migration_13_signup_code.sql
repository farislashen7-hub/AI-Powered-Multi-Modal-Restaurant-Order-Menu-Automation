-- Run AFTER migration_12. Idempotent.
-- Staff/courier signup code, editable from Supabase (Table Editor). NOT in site_settings (that table is public-read).
create table if not exists public.app_secrets (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);
alter table public.app_secrets enable row level security;  -- no policies = anon/authenticated can't read or write
revoke all on public.app_secrets from anon, authenticated;  -- only the server (service_role) reads it

-- 👇 CHANGE THIS VALUE (min 8 chars) then run, or edit the row later in Table Editor
insert into public.app_secrets (key, value) values ('staff_signup_code', 'CHANGE-ME-Mtamna-2026')
on conflict (key) do nothing;
