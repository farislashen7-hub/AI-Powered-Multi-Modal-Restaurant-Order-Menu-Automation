-- Run AFTER migration_19. Idempotent. Global switch: "تدخّل بشري" at the top of /admin/chats.
-- ai_enabled = false -> the AI answers NO chat (n8n gets ai_enabled:false / blocked:true) until staff turn it back on.
create table if not exists public.wa_settings (
  id         int primary key default 1 check (id = 1),
  ai_enabled boolean not null default true,
  changed_by uuid references auth.users(id) on delete set null,
  changed_at timestamptz
);
insert into public.wa_settings (id) values (1) on conflict (id) do nothing;
alter table public.wa_settings enable row level security;
drop policy if exists "wa_settings staff read" on public.wa_settings;
create policy "wa_settings staff read" on public.wa_settings for select using (public.is_staff());
-- no write policies: only the server (service_role) writes.

create or replace function public.wa_log_message(
  p_phone text, p_name text, p_direction text, p_sender text,
  p_body text, p_media text default null, p_ext text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_mode text; v_id bigint; v_global boolean; v_on boolean;
  v_body text := left(coalesce(p_body, ''), 4000);
begin
  insert into public.wa_chats (phone, customer_name)
  values (p_phone, nullif(left(trim(coalesce(p_name, '')), 80), ''))
  on conflict (phone) do update
    set customer_name = coalesce(public.wa_chats.customer_name, excluded.customer_name);

  select mode into v_mode from public.wa_chats where phone = p_phone for update;
  select coalesce(ai_enabled, true) into v_global from public.wa_settings where id = 1;
  v_global := coalesce(v_global, true);
  v_on := v_global and v_mode = 'ai';

  -- human in charge (this chat or globally) -> the AI must not answer
  if p_direction = 'out' and p_sender = 'ai' and not v_on then
    return jsonb_build_object('ok', true, 'blocked', true, 'ai_enabled', false, 'mode', v_mode, 'global_ai', v_global);
  end if;

  insert into public.wa_messages (phone, direction, sender, body, media_url, external_id)
  values (p_phone, p_direction, p_sender, v_body, nullif(p_media, ''), nullif(p_ext, ''))
  on conflict (external_id) where external_id is not null do nothing
  returning id into v_id;

  if v_id is null then
    return jsonb_build_object('ok', true, 'duplicate', true, 'ai_enabled', v_on, 'mode', v_mode, 'global_ai', v_global);
  end if;

  update public.wa_chats set
    last_message    = left(case when v_body <> '' then v_body else '[مرفق]' end, 200),
    last_sender     = p_sender,
    last_message_at = now(),
    unread_count    = case when p_direction = 'in' then unread_count + 1
                           when p_sender = 'human'  then 0
                           else unread_count end
  where phone = p_phone;

  return jsonb_build_object('ok', true, 'id', v_id, 'ai_enabled', v_on, 'mode', v_mode, 'global_ai', v_global);
end $$;
revoke all on function public.wa_log_message(text, text, text, text, text, text, text) from public, anon, authenticated;
grant execute on function public.wa_log_message(text, text, text, text, text, text, text) to service_role;

do $$ begin
  alter publication supabase_realtime add table public.wa_settings;
exception when duplicate_object then null; end $$;
