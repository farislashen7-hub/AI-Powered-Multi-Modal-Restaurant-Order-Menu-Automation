-- Run AFTER migration_18. Idempotent. WhatsApp conversations inside /admin/chats.
-- n8n logs every customer / AI message (service_role via /api/whatsapp/log). Staff read them live.
-- mode: 'ai' = the smart assistant replies. 'human' = AI stays silent until staff press "المساعد الذكي".

create table if not exists public.wa_chats (
  phone           text primary key,                       -- normalized, e.g. +201012345678
  customer_name   text,
  mode            text not null default 'ai' check (mode in ('ai','human')),
  last_message    text,
  last_sender     text,
  last_message_at timestamptz not null default now(),
  unread_count    int  not null default 0,
  human_by        uuid references auth.users(id) on delete set null,
  mode_changed_at timestamptz,
  created_at      timestamptz not null default now()
);
create index if not exists wa_chats_last_idx on public.wa_chats (last_message_at desc);

create table if not exists public.wa_messages (
  id          bigint generated always as identity primary key,
  phone       text not null references public.wa_chats(phone) on delete cascade,
  direction   text not null check (direction in ('in','out')),
  sender      text not null check (sender in ('customer','ai','human','system')),
  body        text not null default '' check (char_length(body) <= 4000),
  media_url   text,
  external_id text,                                        -- WhatsApp message id (dedupe n8n retries)
  created_at  timestamptz not null default now()
);
create index if not exists wa_messages_phone_idx on public.wa_messages (phone, id);
create unique index if not exists wa_messages_ext_uq on public.wa_messages (external_id) where external_id is not null;

alter table public.wa_chats    enable row level security;
alter table public.wa_messages enable row level security;
drop policy if exists "wa_chats staff read" on public.wa_chats;
create policy "wa_chats staff read" on public.wa_chats for select using (public.is_staff());
drop policy if exists "wa_messages staff read" on public.wa_messages;
create policy "wa_messages staff read" on public.wa_messages for select using (public.is_staff());
-- no insert/update/delete policies: only the server (service_role) writes.

-- One atomic call from the server: upsert chat, refuse AI replies while a human is in charge, store message.
create or replace function public.wa_log_message(
  p_phone text, p_name text, p_direction text, p_sender text,
  p_body text, p_media text default null, p_ext text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_mode text; v_id bigint;
  v_body text := left(coalesce(p_body, ''), 4000);
begin
  insert into public.wa_chats (phone, customer_name)
  values (p_phone, nullif(left(trim(coalesce(p_name, '')), 80), ''))
  on conflict (phone) do update
    set customer_name = coalesce(public.wa_chats.customer_name, excluded.customer_name);

  select mode into v_mode from public.wa_chats where phone = p_phone for update;

  -- human took over -> the AI must not answer (n8n checks "blocked" before sending)
  if p_direction = 'out' and p_sender = 'ai' and v_mode = 'human' then
    return jsonb_build_object('ok', true, 'blocked', true, 'ai_enabled', false, 'mode', v_mode);
  end if;

  insert into public.wa_messages (phone, direction, sender, body, media_url, external_id)
  values (p_phone, p_direction, p_sender, v_body, nullif(p_media, ''), nullif(p_ext, ''))
  on conflict (external_id) where external_id is not null do nothing
  returning id into v_id;

  if v_id is null then  -- duplicate delivery from n8n
    return jsonb_build_object('ok', true, 'duplicate', true, 'ai_enabled', v_mode = 'ai', 'mode', v_mode);
  end if;

  update public.wa_chats set
    last_message    = left(case when v_body <> '' then v_body else '[مرفق]' end, 200),
    last_sender     = p_sender,
    last_message_at = now(),
    unread_count    = case when p_direction = 'in' then unread_count + 1
                           when p_sender = 'human'  then 0
                           else unread_count end
  where phone = p_phone;

  return jsonb_build_object('ok', true, 'id', v_id, 'ai_enabled', v_mode = 'ai', 'mode', v_mode);
end $$;
revoke all on function public.wa_log_message(text, text, text, text, text, text, text) from public, anon, authenticated;
grant execute on function public.wa_log_message(text, text, text, text, text, text, text) to service_role;

-- live updates in the admin page
do $$ begin
  alter publication supabase_realtime add table public.wa_chats;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.wa_messages;
exception when duplicate_object then null; end $$;
