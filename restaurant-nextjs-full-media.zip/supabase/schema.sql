-- Run once in Supabase SQL editor.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, phone)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone')
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create table if not exists public.menu_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  price numeric(10,2) not null check (price >= 0),
  category text,
  image_url text,
  image_path text,
  available boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id),
  customer_name text,
  phone text not null,
  address text not null,
  notes text,
  status text not null default 'pending'
    check (status in ('pending','preparing','ready','delivered','cancelled')),
  total numeric(10,2) not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists orders_created_idx on public.orders (created_at desc);
create index if not exists orders_user_idx on public.orders (user_id);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  menu_item_id uuid references public.menu_items(id) on delete set null,
  name text not null,
  unit_price numeric(10,2) not null,
  qty int not null check (qty between 1 and 50)
);
create index if not exists order_items_order_idx on public.order_items (order_id);

-- RLS
alter table public.profiles    enable row level security;
alter table public.menu_items  enable row level security;
alter table public.orders      enable row level security;
alter table public.order_items enable row level security;

create policy "profile read own/admin" on public.profiles for select
  using (id = auth.uid() or public.is_admin());
-- no UPDATE policy on profiles: users cannot self-promote to admin.

create policy "menu public read" on public.menu_items for select
  using (available or public.is_admin());
create policy "menu admin write" on public.menu_items for all
  using (public.is_admin()) with check (public.is_admin());

create policy "orders read own/admin" on public.orders for select
  using (user_id = auth.uid() or public.is_admin());
create policy "orders admin update" on public.orders for update
  using (public.is_admin()) with check (public.is_admin());

create policy "order_items read own/admin" on public.order_items for select
  using (public.is_admin() or exists (
    select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));

-- Atomic order creation; prices come from DB, never from the client.
create or replace function public.create_order(p_items jsonb, p_phone text, p_address text, p_notes text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_order uuid; v_total numeric; v_name text;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'empty cart';
  end if;
  select full_name into v_name from public.profiles where id = auth.uid();
  insert into public.orders (user_id, customer_name, phone, address, notes)
  values (auth.uid(), v_name, left(p_phone, 30), left(p_address, 300), left(p_notes, 500))
  returning id into v_order;
  insert into public.order_items (order_id, menu_item_id, name, unit_price, qty)
  select v_order, m.id, m.name, m.price, least(greatest((i->>'qty')::int, 1), 50)
  from jsonb_array_elements(p_items) i
  join public.menu_items m on m.id = (i->>'id')::uuid and m.available;
  select coalesce(sum(unit_price * qty), 0) into v_total from public.order_items where order_id = v_order;
  if v_total = 0 then raise exception 'no valid items'; end if;
  update public.orders set total = v_total where id = v_order;
  return v_order;
end $$;
revoke all on function public.create_order(jsonb, text, text, text) from public, anon;
grant execute on function public.create_order(jsonb, text, text, text) to authenticated;

-- Realtime for the admin board
alter publication supabase_realtime add table public.orders;

-- Storage: public read, admin-only write
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('menu-images', 'menu-images', true, 3145728, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "menu-images public read" on storage.objects for select
  using (bucket_id = 'menu-images');
create policy "menu-images admin insert" on storage.objects for insert
  with check (bucket_id = 'menu-images' and public.is_admin());
create policy "menu-images admin update" on storage.objects for update
  using (bucket_id = 'menu-images' and public.is_admin());
create policy "menu-images admin delete" on storage.objects for delete
  using (bucket_id = 'menu-images' and public.is_admin());

-- Make yourself admin (after signing up):
-- update public.profiles set role = 'admin' where id = (select id from auth.users where email = 'YOU@EMAIL.COM');
