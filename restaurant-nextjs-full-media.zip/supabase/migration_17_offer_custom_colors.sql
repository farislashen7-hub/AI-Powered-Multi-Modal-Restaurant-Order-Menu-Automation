-- Run AFTER migration_16. Idempotent. Owner can pick free colors for an offer card (card_theme = 'custom').
alter table public.offers add column if not exists card_bg text;
alter table public.offers add column if not exists card_fg text;
alter table public.offers add column if not exists card_accent text;

alter table public.offers drop constraint if exists offers_card_theme_check;
alter table public.offers add constraint offers_card_theme_check
  check (card_theme in ('classic','dark','saffron','coral','mint','royal','custom'));
alter table public.offers drop constraint if exists offers_card_colors_check;
alter table public.offers add constraint offers_card_colors_check
  check ((card_bg is null or card_bg ~ '^#[0-9a-fA-F]{6}$')
     and (card_fg is null or card_fg ~ '^#[0-9a-fA-F]{6}$')
     and (card_accent is null or card_accent ~ '^#[0-9a-fA-F]{6}$'));

grant update (title, description, price, old_price, valid_until, active, image_url, image_path,
              card_theme, card_layout, badge_text, card_bg, card_fg, card_accent) on public.offers to authenticated;
