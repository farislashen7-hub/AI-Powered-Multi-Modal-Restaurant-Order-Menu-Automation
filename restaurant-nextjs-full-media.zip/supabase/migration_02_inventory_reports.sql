-- Run once AFTER schema.sql. Idempotent.
alter table public.menu_items
  add column if not exists track_stock boolean not null default false,
  add column if not exists stock_qty int not null default 0 check (stock_qty >= 0),
  add column if not exists low_stock_at int not null default 5;

-- Order creation now checks + decrements stock atomically (row locks).
create or replace function public.create_order(p_items jsonb, p_phone text, p_address text, p_notes text)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_order uuid; v_total numeric; v_name text;
  r record; m public.menu_items%rowtype;
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'empty cart';
  end if;
  select full_name into v_name from public.profiles where id = auth.uid();
  insert into public.orders (user_id, customer_name, phone, address, notes)
  values (auth.uid(), v_name, left(p_phone, 30), left(p_address, 300), left(p_notes, 500))
  returning id into v_order;

  for r in
    select (i->>'id')::uuid as id,
           least(greatest(sum((i->>'qty')::int), 1), 50) as qty
    from jsonb_array_elements(p_items) i
    group by 1 order by 1
  loop
    select * into m from public.menu_items where id = r.id and available for update;
    if not found then continue; end if;
    if m.track_stock then
      if m.stock_qty < r.qty then raise exception 'out of stock: %', m.name; end if;
      update public.menu_items set stock_qty = stock_qty - r.qty where id = m.id;
    end if;
    insert into public.order_items (order_id, menu_item_id, name, unit_price, qty)
    values (v_order, m.id, m.name, m.price, r.qty);
  end loop;

  select coalesce(sum(unit_price * qty), 0) into v_total from public.order_items where order_id = v_order;
  if v_total = 0 then raise exception 'no valid items'; end if;
  update public.orders set total = v_total where id = v_order;
  return v_order;
end $$;

-- Cancelled is final; cancelling returns stock.
create or replace function public.orders_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if old.status = 'cancelled' and new.status <> 'cancelled' then
    raise exception 'cancelled order cannot be reopened';
  end if;
  if new.status = 'cancelled' and old.status <> 'cancelled' then
    update public.menu_items m set stock_qty = m.stock_qty + oi.qty
    from public.order_items oi
    where oi.order_id = new.id and oi.menu_item_id = m.id and m.track_stock;
  end if;
  return new;
end $$;
drop trigger if exists orders_guard_trg on public.orders;
create trigger orders_guard_trg before update of status on public.orders
  for each row execute function public.orders_guard();

-- Admin-only sales report. Revenue excludes cancelled orders.
create or replace function public.sales_report(p_from timestamptz, p_to timestamptz)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  return jsonb_build_object(
    'orders',    (select count(*) from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled'),
    'cancelled', (select count(*) from orders where created_at >= p_from and created_at < p_to and status = 'cancelled'),
    'revenue',   (select coalesce(sum(total), 0) from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled'),
    'delivered_revenue', (select coalesce(sum(total), 0) from orders where created_at >= p_from and created_at < p_to and status = 'delivered'),
    'daily', (select coalesce(jsonb_agg(to_jsonb(d) order by d.day), '[]'::jsonb) from (
        select (created_at at time zone 'Africa/Cairo')::date as day, count(*) as orders, sum(total) as revenue
        from orders where created_at >= p_from and created_at < p_to and status <> 'cancelled' group by 1) d),
    'top_items', (select coalesce(jsonb_agg(to_jsonb(t)), '[]'::jsonb) from (
        select oi.name, sum(oi.qty)::int as qty, sum(oi.qty * oi.unit_price) as revenue
        from order_items oi join orders o on o.id = oi.order_id
        where o.created_at >= p_from and o.created_at < p_to and o.status <> 'cancelled'
        group by oi.name order by qty desc limit 10) t)
  );
end $$;
revoke all on function public.sales_report(timestamptz, timestamptz) from public, anon;
grant execute on function public.sales_report(timestamptz, timestamptz) to authenticated;
