module.exports = {
  content: ['./app/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['var(--font-plex)', 'Tahoma', 'sans-serif'] },
      colors: { ink: '#0F3D3E', saf: '#E8A317', coral: '#E4572E', mint: '#DDEFE6' },
    },
  },
  plugins: [],
};
