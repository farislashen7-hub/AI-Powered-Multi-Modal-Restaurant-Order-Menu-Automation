import { MessageCircle } from 'lucide-react';
import { site as defaults } from '@/lib/site';

// Floating button -> opens the restaurant's WhatsApp chat (set site.whatsapp in lib/site.js).
export default function WhatsAppButton({ info }) {
  const site = info || defaults;
  const digits = String(site.whatsapp || '').replace(/\D/g, '');
  if (!digits) return null;
  const href = `https://wa.me/${digits}?text=${encodeURIComponent(`أهلًا ${site.name}، عندي استفسار`)}`;
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" aria-label="تواصل معنا على واتساب"
      className="fixed bottom-24 left-4 z-40 grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-xl transition hover:scale-105 focus-visible:outline-offset-4">
      <span aria-hidden className="absolute inset-0 rounded-full bg-[#25D366] opacity-40 motion-safe:animate-ping" />
      <MessageCircle className="relative h-7 w-7" aria-hidden />
    </a>
  );
}
