import Link from 'next/link';
import { Flame, LogIn, LogOut, LayoutDashboard, ClipboardList } from 'lucide-react';
import { getSessionUser } from '@/lib/supabase/server';
import { logout } from '@/app/auth/actions';
import { site } from '@/lib/site';

const btn = 'inline-flex min-h-[44px] items-center gap-2 rounded-xl px-3 text-sm font-semibold transition';

export default async function Header() {
  const { user, profile } = await getSessionUser();
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-ink text-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-4 py-2">
        <Link href="/" className="flex items-center gap-2.5 text-lg font-bold">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-saf text-ink"><Flame className="h-5 w-5" aria-hidden /></span>
          {site.name}
        </Link>
        <nav className="hidden items-center gap-1 md:flex" aria-label="التنقل الرئيسي">
          <Link href="/#menu" className={`${btn} text-white/80 hover:bg-white/10 hover:text-white`}>المنيو</Link>
          <Link href="/#info" className={`${btn} text-white/80 hover:bg-white/10 hover:text-white`}>تواصل معنا</Link>
        </nav>
        <div className="flex items-center gap-1">
          {['admin', 'staff'].includes(profile?.role) && (
            <Link href="/admin" className={`${btn} text-white hover:bg-white/10`}>
              <LayoutDashboard className="h-4 w-4" aria-hidden /> <span className="hidden sm:inline">الإدارة</span>
            </Link>
          )}
          <Link href="/my-orders" className={`${btn} text-white hover:bg-white/10`}>
            <ClipboardList className="h-4 w-4" aria-hidden /> طلباتي
          </Link>
          {user ? (
            <form action={logout}>
              <button className={`${btn} text-white hover:bg-white/10`}>
                <LogOut className="h-4 w-4" aria-hidden /> خروج
              </button>
            </form>
          ) : (
            <Link href="/login" className={`${btn} text-white/70 hover:bg-white/10 hover:text-white`}>
              <LogIn className="h-4 w-4" aria-hidden /> <span className="hidden sm:inline">دخول الموظفين</span>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
