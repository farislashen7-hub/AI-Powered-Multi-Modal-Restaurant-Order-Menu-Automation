'use client';
import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import ConfirmDialog from '@/components/ConfirmDialog';

// direct=true  -> cancels now (order still pending)
// direct=false -> sends cancel request to staff (already preparing)
export default function CancelRequestButton({ orderId, direct = false }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [st, setSt] = useState({ loading: false, done: false, error: '' });
  const close = useCallback(() => setOpen(false), []);

  async function send() {
    setSt({ loading: true, done: false, error: '' });
    try {
      const res = await fetch(`/api/orders/${orderId}/${direct ? 'cancel' : 'cancel-request'}`, { method: 'POST' });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.error || 'حصلت مشكلة، حاول تاني');
      setSt({ loading: false, done: true, error: '' });
      setOpen(false);
      if (direct) router.refresh();
    } catch (e) {
      setSt({ loading: false, done: false, error: e.message });
      setOpen(false);
    }
  }

  if (st.done) return <p role="status" className="inline-flex min-h-[44px] items-center text-sm font-semibold text-emerald-700">{direct ? 'تم إلغاء الطلب.' : 'اتبعت طلب الإلغاء، هنكلمك للتأكيد.'}</p>;
  return (
    <span className="inline-flex flex-col">
      <button type="button" onClick={() => { setSt((s) => ({ ...s, error: '' })); setOpen(true); }}
        className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-coral px-4 text-sm font-semibold text-white">
        {direct ? 'إلغاء الطلب' : 'طلب إلغاء'}
      </button>
      {st.error && <span role="alert" className="mt-1 text-xs text-coral">{st.error}</span>}
      <ConfirmDialog
        open={open}
        loading={st.loading}
        title="متأكد إنك عايز تلغي الطلب؟"
        description={direct ? 'الطلب هيتلغي فوراً ومش هينفع ترجّعه.' : 'هنبعت طلب الإلغاء للمطعم، والطلب بيتحضّر دلوقتي فالموظف هو اللي يقرر.'}
        confirmLabel={direct ? 'أيوه، إلغي الطلب' : 'أيوه، ابعت طلب الإلغاء'}
        cancelLabel="لا، سيب الطلب"
        onConfirm={send}
        onCancel={close}
      />
    </span>
  );
}
