import { Flame, Truck, ShieldCheck } from 'lucide-react';
import { site } from '@/lib/site';

const icons = { Flame, Truck, ShieldCheck };

export default function Features() {
  return (
    <section className="border-b border-ink/10 bg-white">
      <ul className="mx-auto grid max-w-6xl gap-6 px-4 py-8 md:grid-cols-3">
        {site.features.map((f) => {
          const Icon = icons[f.icon] || Flame;
          return (
            <li key={f.title} className="flex items-start gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-mint text-ink"><Icon className="h-6 w-6" aria-hidden /></span>
              <div>
                <h3 className="font-bold">{f.title}</h3>
                <p className="mt-0.5 text-sm leading-relaxed text-ink/65">{f.text}</p>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
