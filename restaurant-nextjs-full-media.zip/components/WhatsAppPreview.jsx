'use client';
import { useEffect, useState } from 'react';
import { CheckCheck } from 'lucide-react';
import { parseWhatsApp } from '@/lib/offerMessage';

// Phone-style chat: shows the offer exactly as the customer receives it.
export default function WhatsAppPreview({ message, sender, time, image = null }) {
  const parts = parseWhatsApp(message);
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [image]);
  const showImg = Boolean(image) && !failed;
  return (
    <figure className="wa-frame" aria-label="معاينة رسالة العرض على واتساب">
      <div className="wa-head">
        <span className="wa-avatar" aria-hidden>{(sender || 'م').trim().slice(0, 1)}</span>
        <div className="min-w-0 leading-tight">
          <p className="truncate text-sm font-semibold">{sender || 'المطعم'}</p>
          <p className="text-[11px] opacity-80">حساب تجاري</p>
        </div>
      </div>
      <div className="wa-chat" dir="rtl">
        <div className={`wa-bubble${showImg ? ' wa-bubble--media' : ''}`}>
          {showImg && (
            // plain <img>: works for blob: previews and remote URLs alike (WhatsApp shows the image above the caption)
            // eslint-disable-next-line @next/next/no-img-element
            <img src={image} alt="" className="wa-media" loading="eager" decoding="async" onError={() => setFailed(true)} />
          )}
          <p className="wa-text">
            {parts.map((p, i) => (p.t === 'b' ? <strong key={i}>{p.v}</strong> : p.t === 's' ? <s key={i}>{p.v}</s> : <span key={i}>{p.v}</span>))}
          </p>
          <p className="wa-meta"><span>{time}</span><CheckCheck className="h-3.5 w-3.5" aria-hidden /></p>
        </div>
        {Boolean(image) && failed && <p className="mt-2 text-xs text-[#B3422D]">الصورة مش بتتحمّل. ارفعها تاني.</p>}
      </div>
      <figcaption className="sr-only">معاينة فقط</figcaption>
    </figure>
  );
}
