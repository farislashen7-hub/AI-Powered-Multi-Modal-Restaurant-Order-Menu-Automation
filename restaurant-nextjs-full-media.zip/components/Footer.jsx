import { Flame, Phone, MapPin, Clock, MessageCircle, Instagram, Facebook } from 'lucide-react';
import { site as defaults } from '@/lib/site';

export default function Footer({ info }) {
  const site = info || defaults;
  return (
    <footer id="info" className="mt-16 bg-ink text-white">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-3">
        <div>
          <p className="flex items-center gap-2.5 text-lg font-bold">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-saf text-ink"><Flame className="h-5 w-5" aria-hidden /></span>
            {site.name}
          </p>
          <p className="mt-3 text-sm leading-relaxed text-white/70">{site.tagline}</p>
        </div>
        <ul className="space-y-3 text-sm">
          <li className="flex items-center gap-3"><Phone className="h-4 w-4 text-saf" aria-hidden /><a href={`tel:${site.phone}`} dir="ltr" className="hover:underline">{site.phone}</a></li>
          <li className="flex items-center gap-3"><MessageCircle className="h-4 w-4 text-saf" aria-hidden /><a href={`https://wa.me/${site.whatsapp}`} className="hover:underline">واتساب</a></li>
          <li className="flex items-start gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-saf" aria-hidden />
            {site.mapsUrl ? <a href={site.mapsUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">{site.address}</a> : site.address}
          </li>
          {site.instagram && <li className="flex items-center gap-3"><Instagram className="h-4 w-4 text-saf" aria-hidden /><a href={site.instagram} target="_blank" rel="noopener noreferrer" className="hover:underline">انستجرام</a></li>}
          {site.facebook && <li className="flex items-center gap-3"><Facebook className="h-4 w-4 text-saf" aria-hidden /><a href={site.facebook} target="_blank" rel="noopener noreferrer" className="hover:underline">فيسبوك</a></li>}
        </ul>
        <div className="flex items-start gap-3 text-sm"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-saf" aria-hidden /><div><p className="font-semibold">أوقات العمل</p><p className="mt-1 text-white/70">{site.hours}</p></div></div>
      </div>
      <p className="border-t border-white/10 py-4 text-center text-xs text-white/50">© {new Date().getFullYear()} {site.name}. جميع الحقوق محفوظة.</p>
    </footer>
  );
}
