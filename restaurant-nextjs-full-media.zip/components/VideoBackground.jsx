'use client';
import { useState } from 'react';

// Fills the nearest `relative` parent. Files: /public/hero.webm, /public/hero.mp4, /public/hero-poster.jpg
// Gradient shows until the video loads (or if it never does). Hidden when user prefers reduced motion.
export default function VideoBackground({ overlay = 'from-black/75 via-black/45 to-black/30' }) {
  const [ready, setReady] = useState(false);
  return (
    <>
      <div aria-hidden className="absolute inset-0 -z-20 bg-gradient-to-br from-[#2a130a] via-[#6a230e] to-coral" />
      <video
        aria-hidden
        className={`absolute inset-0 -z-10 h-full w-full object-cover object-[center_40%] transition-opacity duration-700 motion-reduce:hidden ${ready ? 'opacity-100' : 'opacity-0'}`}
        autoPlay muted loop playsInline preload="auto" poster="/hero-poster.jpg"
        onLoadedData={() => setReady(true)}
      >
        <source src="/hero.webm" type="video/webm" />
        <source src="/hero.mp4" type="video/mp4" />
      </video>
      <div aria-hidden className={`absolute inset-0 -z-10 bg-gradient-to-t ${overlay}`} />
    </>
  );
}
