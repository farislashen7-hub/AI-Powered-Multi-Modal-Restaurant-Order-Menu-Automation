'use client';
import { useMemo, useState } from 'react';
import { Search, Loader2, ShieldCheck, UserCog, User, Bike } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

const ROLES = [['customer', 'موقوف (بدون صلاحية)', User], ['staff', 'موظف', UserCog], ['delivery', 'مندوب توصيل', Bike], ['admin', 'أدمن', ShieldCheck]];

export default function StaffManager({ initial, meId }) {
  const supabase = createClient();
  const [rows, setRows] = useState(initial);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');

  const shown = useMemo(() => {
    const s = q.trim().toLowerCase();
    const list = s
      ? rows.filter((r) => `${r.full_name || ''} ${r.email || ''} ${r.phone || ''}`.toLowerCase().includes(s))
      : rows;
    const rank = { admin: 0, staff: 1, delivery: 2, customer: 3 };
    return [...list].sort((a, b) => rank[a.role] - rank[b.role]);
  }, [rows, q]);

  async function setRole(r, role) {
    if (role === r.role) return;
    if (role === 'admin' && !confirm(`إعطاء صلاحية أدمن كاملة لـ ${r.email || r.full_name}؟`)) return;
    setBusy(r.id); setError('');
    const { error: err } = await supabase.from('profiles').update({ role }).eq('id', r.id);
    if (err) setError('تعذّر تغيير الصلاحية');
    else setRows((l) => l.map((x) => (x.id === r.id ? { ...x, role } : x)));
    setBusy(null);
  }

  return (
    <section>
      <h1 className="text-xl font-bold">الموظفين والصلاحيات</h1>
      <p className="mt-1 text-sm text-ink/70">
        الموظف بيسجّل من صفحة /signup بكود الموظفين وبياخد صلاحية &quot;موظف&quot; تلقائي. الموظف بيشوف الطلبات ويغيّر حالتها بس. لإيقاف موظف غيّره لـ &quot;موقوف&quot;.
      </p>
      <div className="relative my-4">
        <Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" aria-hidden />
        <input value={q} onChange={(e) => setQ(e.target.value)} aria-label="بحث" placeholder="ابحث بالاسم أو الإيميل أو الموبايل"
          className="min-h-[44px] w-full rounded-xl border border-ink/20 bg-white ps-10 pe-3" />
      </div>
      {error && <p role="alert" className="mb-3 text-sm text-coral">{error}</p>}
      <ul className="divide-y divide-ink/10 rounded-2xl bg-white ring-1 ring-ink/10">
        {shown.length === 0 && <li className="p-6 text-center text-ink/60">مفيش نتائج.</li>}
        {shown.map((r) => (
          <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="min-w-0">
              <p className="truncate font-semibold">{r.full_name || 'بدون اسم'}{r.id === meId && <span className="ms-2 text-xs text-ink/50">(أنت)</span>}</p>
              <p className="truncate text-sm text-ink/60" dir="ltr">{r.email || '—'}{r.phone ? ` · ${r.phone}` : ''}</p>
            </div>
            <div className="flex items-center gap-2">
              {busy === r.id && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
              <select aria-label="الصلاحية" value={r.role} disabled={r.id === meId || busy === r.id}
                onChange={(e) => setRole(r, e.target.value)}
                className="min-h-[44px] rounded-xl border border-ink/20 bg-white px-3 text-sm disabled:opacity-60">
                {ROLES.map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
