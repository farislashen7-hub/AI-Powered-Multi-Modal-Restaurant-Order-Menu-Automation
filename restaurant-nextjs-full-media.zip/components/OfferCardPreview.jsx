import Image from 'next/image';
import { Tag, ImageOff, Clock } from 'lucide-react';
import { offerLook } from '@/lib/offerStyle';

const money = (n) => `${Number(n).toLocaleString('ar-EG')} ج.م`;

// Static preview of how the offer card looks on the public menu (same look as Menu.jsx, no cart controls).
export default function OfferCardPreview({ offer, image, pct = 0, unoptimized = false }) {
  const t = offerLook(offer);
  const banner = offer.card_layout === 'banner';
  return (
    <div className={`flex overflow-hidden rounded-2xl shadow-sm ring-1 ring-ink/10 ${banner ? 'flex-col sm:flex-row' : 'flex-col'}`} style={{ background: t.bg, color: t.fg }}>
      <span className={`relative block overflow-hidden bg-mint ${banner ? 'aspect-[4/3] sm:aspect-auto sm:min-h-[180px] sm:w-2/5 sm:shrink-0' : 'aspect-[4/3]'}`}>
        {image
          ? <Image src={image} alt="" fill sizes="(max-width:640px) 100vw, 400px" unoptimized={unoptimized} className="object-cover" />
          : <ImageOff className="absolute inset-0 m-auto h-8 w-8 text-ink/30" aria-hidden />}
        <span className="absolute start-3 top-3 inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold shadow" style={{ background: t.badge, color: t.badgeFg }}>
          <Tag className="h-3.5 w-3.5" aria-hidden /> {offer.badge_text?.trim() || 'عرض'}
        </span>
        {pct > 0 && <span className="absolute end-3 top-3 rounded-full px-3 py-1 text-xs font-bold shadow" style={{ background: t.pill, color: t.pillFg }}>خصم {pct.toLocaleString('ar-EG')}%</span>}
      </span>
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="px-4 pt-4">
          <p className="text-lg font-semibold">{offer.title || 'عنوان العرض'}</p>
          {offer.description && <p className="mt-1 line-clamp-2 whitespace-pre-line text-sm opacity-75">{offer.description}</p>}
          {offer.valid_until && <p className="mt-1 inline-flex items-center gap-1 text-xs opacity-70"><Clock className="h-3.5 w-3.5" aria-hidden /> ساري حتى {offer.valid_until}</p>}
        </div>
        <div className="mt-auto flex items-center justify-between gap-2 p-4 pt-2">
          {offer.price !== '' && offer.price != null ? (
            <span className="flex items-baseline gap-2">
              <span className="text-lg font-bold tabular-nums">{money(offer.price)}</span>
              {pct > 0 && <s className="text-sm tabular-nums opacity-60">{money(offer.old_price)}</s>}
            </span>
          ) : <span />}
          <span className="inline-flex min-h-[44px] items-center rounded-xl px-4 text-sm font-semibold" style={{ background: t.accent, color: t.accentFg }}>+ أضف</span>
        </div>
      </div>
    </div>
  );
}
