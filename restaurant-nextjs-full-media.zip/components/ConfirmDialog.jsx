'use client';
import { useEffect, useRef } from 'react';
import { AlertTriangle, Loader2 } from 'lucide-react';

// Accessible confirm modal. Esc / backdrop = cancel. Focus lands on the SAFE button.
export default function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'تأكيد',
  cancelLabel = 'رجوع',
  loading = false,
  onConfirm,
  onCancel,
  tone = 'danger',
  children,
}) {
  const panelRef = useRef(null);
  const cancelRef = useRef(null);
  const lastFocus = useRef(null);

  useEffect(() => {
    if (!open) return;
    lastFocus.current = document.activeElement;
    cancelRef.current?.focus();
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    function onKey(e) {
      if (e.key === 'Escape' && !loading) { e.preventDefault(); onCancel(); return; }
      if (e.key !== 'Tab') return;
      const f = panelRef.current?.querySelectorAll('button:not([disabled]), select, input');
      if (!f || !f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
      lastFocus.current?.focus?.();
    };
  }, [open, loading, onCancel]);

  if (!open) return null;
  return (
    <div className="dlg-overlay" onMouseDown={(e) => { if (e.target === e.currentTarget && !loading) onCancel(); }}>
      <div ref={panelRef} role="alertdialog" aria-modal="true" aria-labelledby="dlg-title" aria-describedby="dlg-desc" className="dlg-panel">
        <div className="dlg-icon" aria-hidden><AlertTriangle className="h-6 w-6" /></div>
        <h2 id="dlg-title" className="dlg-title">{title}</h2>
        {description && <p id="dlg-desc" className="dlg-desc">{description}</p>}
        {children && <div className="mt-3 text-start">{children}</div>}
        <div className="dlg-actions">
          <button type="button" onClick={onConfirm} disabled={loading} className={`dlg-btn ${tone === 'success' ? 'dlg-btn-success' : 'dlg-btn-danger'}`}>
            {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />} {confirmLabel}
          </button>
          <button type="button" ref={cancelRef} onClick={onCancel} disabled={loading} className="dlg-btn dlg-btn-ghost">
            {cancelLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
