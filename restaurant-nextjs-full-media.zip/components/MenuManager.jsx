'use client';
import { useState } from 'react';
import Image from 'next/image';
import { Upload, Trash2, Eye, EyeOff, Loader2, ImageOff, Pencil, Save, X, AlertTriangle, Plus } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

const BUCKET = 'menu-images';
const MAX = 3 * 1024 * 1024;
const TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const blank = () => ({ key: crypto.randomUUID(), name: '', description: '', price: '', category: '', track_stock: false, stock_qty: 0, low_stock_at: 5, extras: [], file: null });
const cleanExtras = (list) => (list || [])
  .map((x) => ({ name: String(x.name || '').trim().slice(0, 80), price: Math.max(0, Number(x.price) || 0) }))
  .filter((x) => x.name);
const sortExtras = (list) => [...(list || [])].sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));

function ExtrasEditor({ value, onChange }) {
  const upd = (i, patch) => onChange(value.map((x, j) => (j === i ? { ...x, ...patch } : x)));
  return (
    <div className="min-w-0 rounded-xl bg-mint/40 p-3 sm:col-span-2">
      <p className="mb-2 text-sm font-medium">الزيادات (جبنة زيادة، صوص…)</p>
      <ul className="space-y-2">
        {value.map((x, i) => (
          <li key={i} className="flex flex-wrap items-center gap-2">
            <input aria-label="اسم الزيادة" placeholder="اسم الزيادة" value={x.name} onChange={(e) => upd(i, { name: e.target.value })} className="min-h-[44px] w-full min-w-0 basis-full rounded-xl border border-ink/20 bg-white px-3 sm:basis-0 sm:flex-1" />
            <input aria-label="سعر الزيادة" placeholder="السعر" type="number" min="0" step="0.5" inputMode="decimal" value={x.price} onChange={(e) => upd(i, { price: e.target.value })} className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-ink/20 bg-white px-3 sm:w-28 sm:flex-none" />
            <button type="button" aria-label="حذف الزيادة" onClick={() => onChange(value.filter((_, j) => j !== i))} className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-coral ring-1 ring-coral/30 hover:bg-coral/10"><X className="h-4 w-4" /></button>
          </li>
        ))}
      </ul>
      <button type="button" onClick={() => onChange([...value, { name: '', price: '' }])} className="mt-2 inline-flex min-h-[44px] items-center gap-1 text-sm font-semibold underline">
        <Plus className="h-4 w-4" aria-hidden /> إضافة زيادة
      </button>
    </div>
  );
}
const inp = 'min-h-[44px] w-full min-w-0 max-w-full rounded-xl border border-ink/20 bg-white px-3';

// module level: an inner component remounts inputs on each keystroke (focus lost)
const L = ({ t, children, cls = '' }) => (<label className={`block min-w-0 ${cls}`}><span className="mb-1 block text-sm font-medium">{t}</span>{children}</label>);

function Fields({ f, set }) {
  return (
    <>
      <L t="اسم الصنف"><input required value={f.name} onChange={(e) => set({ ...f, name: e.target.value })} className={inp} /></L>
      <L t="السعر (ج.م)"><input required type="number" min="0" step="0.5" inputMode="decimal" value={f.price} onChange={(e) => set({ ...f, price: e.target.value })} className={inp} /></L>
      <L t="التصنيف"><input value={f.category || ''} onChange={(e) => set({ ...f, category: e.target.value })} className={inp} placeholder="فراخ، مقبلات…" /></L>
      <L t="الوصف"><input value={f.description || ''} onChange={(e) => set({ ...f, description: e.target.value })} className={inp} /></L>
      <label className="flex min-h-[44px] items-center gap-2 sm:col-span-2">
        <input type="checkbox" checked={f.track_stock} onChange={(e) => set({ ...f, track_stock: e.target.checked })} className="h-5 w-5" />
        <span className="text-sm font-medium">تتبّع المخزون (الكمية تنقص مع كل طلب)</span>
      </label>
      {f.track_stock && (
        <>
          <L t="الكمية المتاحة"><input type="number" min="0" value={f.stock_qty} onChange={(e) => set({ ...f, stock_qty: e.target.value })} className={inp} /></L>
          <L t="تنبيه لما تقل عن"><input type="number" min="0" value={f.low_stock_at} onChange={(e) => set({ ...f, low_stock_at: e.target.value })} className={inp} /></L>
        </>
      )}
      <ExtrasEditor value={f.extras || []} onChange={(extras) => set({ ...f, extras })} />
    </>
  );
}

export default function MenuManager({ initial }) {
  const supabase = createClient();
  const [items, setItems] = useState(initial);
  const [drafts, setDrafts] = useState(() => [blank()]);
  const [st, setSt] = useState({ loading: false, error: '' });
  const [editId, setEditId] = useState(null);
  const [edit, setEdit] = useState(null);
  const [editFile, setEditFile] = useState(null);
  const [editSt, setEditSt] = useState({ loading: false, error: '' });

  async function upload(f) {
    if (!TYPES.includes(f.type)) throw new Error('الصورة لازم JPG أو PNG أو WebP');
    if (f.size > MAX) throw new Error('حجم الصورة أقصاه 3MB');
    const ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }[f.type];
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from(BUCKET).upload(path, f, { contentType: f.type, cacheControl: '31536000' });
    if (error) throw error;
    return { image_path: path, image_url: supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl };
  }
  const payload = (f) => ({
    name: f.name.trim(), description: f.description || null, category: f.category || null,
    price: Number(f.price), track_stock: !!f.track_stock,
    stock_qty: f.track_stock ? Math.max(0, parseInt(f.stock_qty, 10) || 0) : 0,
    low_stock_at: Math.max(0, parseInt(f.low_stock_at, 10) || 0),
  });

  const setDraft = (key, next) => setDrafts((l) => l.map((d) => (d.key === key ? { ...next, key } : d)));

  // inserts extras for an item; returns saved rows
  async function insertExtras(itemId, list) {
    const ex = cleanExtras(list);
    if (!ex.length) return [];
    const { data, error } = await supabase.from('menu_item_extras')
      .insert(ex.map((x, i) => ({ menu_item_id: itemId, name: x.name, price: x.price, sort_order: i }))).select();
    if (error) throw error;
    return data;
  }

  async function addAll(e) {
    e.preventDefault();
    setSt({ loading: true, error: '' });
    const remaining = [];
    const added = [];
    for (const d of drafts) {
      let img = {};
      try {
        if (d.file) img = await upload(d.file);
        const { data, error } = await supabase.from('menu_items').insert({ ...payload(d), ...img }).select().single();
        if (error) { if (img.image_path) await supabase.storage.from(BUCKET).remove([img.image_path]); throw error; }
        let saved = [];
        try { saved = await insertExtras(data.id, d.extras); }
        catch { remaining.push({ ...blank(), name: '', error: `تم حفظ "${d.name}" لكن الزيادات فشلت، ضيفها من زر تعديل.` }); }
        added.push({ ...data, menu_item_extras: saved });
      } catch (err) {
        remaining.push({ ...d, error: err.message || 'فشل الحفظ' });
      }
    }
    if (added.length) setItems((l) => [...added, ...l]);
    const failed = remaining.filter((r) => r.name || r.price);
    const notes = remaining.filter((r) => !r.name && r.error);
    setDrafts(failed.length ? failed : [blank()]);
    setSt({
      loading: false,
      error: [...failed.map((r) => `${r.name}: ${r.error}`), ...notes.map((r) => r.error)].join(' | '),
    });
  }

  function startEdit(it) {
    setEditId(it.id); setEditFile(null); setEditSt({ loading: false, error: '' });
    setEdit({ name: it.name, description: it.description || '', price: it.price, category: it.category || '',
      track_stock: it.track_stock, stock_qty: it.stock_qty, low_stock_at: it.low_stock_at,
      extras: sortExtras(it.menu_item_extras).map((x) => ({ name: x.name, price: x.price })) });
  }

  async function saveEdit(it) {
    setEditSt({ loading: true, error: '' });
    let img = {};
    try {
      if (editFile) img = await upload(editFile);
      const { data, error } = await supabase.from('menu_items').update({ ...payload(edit), ...img }).eq('id', it.id).select().single();
      if (error) { if (img.image_path) await supabase.storage.from(BUCKET).remove([img.image_path]); throw error; }
      if (img.image_path && it.image_path) await supabase.storage.from(BUCKET).remove([it.image_path]);
      const oldIds = (it.menu_item_extras || []).map((x) => x.id);
      const saved = await insertExtras(it.id, edit.extras);
      if (oldIds.length) await supabase.from('menu_item_extras').delete().in('id', oldIds);
      setItems((l) => l.map((x) => (x.id === it.id ? { ...data, menu_item_extras: saved } : x)));
      setEditId(null);
    } catch (err) { setEditSt({ loading: false, error: err.message || 'فشل الحفظ' }); return; }
    setEditSt({ loading: false, error: '' });
  }

  async function toggle(it) {
    const { error } = await supabase.from('menu_items').update({ available: !it.available }).eq('id', it.id);
    if (!error) setItems((l) => l.map((x) => (x.id === it.id ? { ...x, available: !it.available } : x)));
  }

  async function remove(it) {
    if (!confirm(`حذف "${it.name}"؟`)) return;
    const { error } = await supabase.from('menu_items').delete().eq('id', it.id);
    if (error) return;
    if (it.image_path) await supabase.storage.from(BUCKET).remove([it.image_path]);
    setItems((l) => l.filter((x) => x.id !== it.id));
  }

  return (
    <section className="space-y-6">
      <form onSubmit={addAll} className="space-y-4">
        <h2 className="text-lg font-bold">إضافة أصناف</h2>
        {drafts.map((d, n) => (
          <div key={d.key} className="grid gap-3 rounded-2xl bg-white p-4 ring-1 ring-ink/10 sm:grid-cols-2">
            <div className="flex items-center justify-between sm:col-span-2">
              <p className="font-semibold">صنف {n + 1}</p>
              {drafts.length > 1 && (
                <button type="button" aria-label={`حذف الصنف ${n + 1}`} onClick={() => setDrafts((l) => l.filter((x) => x.key !== d.key))}
                  className="grid h-11 w-11 place-items-center rounded-xl text-coral ring-1 ring-coral/30 hover:bg-coral/10"><Trash2 className="h-4 w-4" /></button>
              )}
            </div>
            <Fields f={d} set={(next) => setDraft(d.key, next)} />
            <label className="block min-w-0 sm:col-span-2"><span className="mb-1 block text-sm font-medium">الصورة</span>
              <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setDraft(d.key, { ...d, file: e.target.files?.[0] || null })} className={`${inp} py-2 text-sm file:me-3 file:rounded-lg file:border-0 file:bg-mint file:px-3 file:py-1.5 file:text-sm file:font-semibold`} /></label>
          </div>
        ))}
        {st.error && <p role="alert" className="text-sm text-coral">{st.error}</p>}
        <div className="flex flex-col gap-2 sm:flex-row">
          <button type="button" onClick={() => setDrafts((l) => [...l, blank()])}
            className="flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-xl ring-1 ring-ink/20 font-semibold hover:bg-mint">
            <Plus className="h-4 w-4" aria-hidden /> صنف تاني
          </button>
          <button disabled={st.loading} className="flex min-h-[48px] flex-1 items-center justify-center gap-2 rounded-xl bg-ink font-semibold text-white disabled:opacity-60">
            {st.loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Upload className="h-4 w-4" aria-hidden />}
            {drafts.length > 1 ? `إضافة ${drafts.length} أصناف للمنيو` : 'إضافة للمنيو'}
          </button>
        </div>
      </form>

      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => {
          const low = it.track_stock && it.stock_qty <= it.low_stock_at;
          return (
            <li key={it.id} className={`min-w-0 overflow-hidden rounded-2xl bg-white ring-1 ring-ink/10 ${editId === it.id ? 'sm:col-span-2 lg:col-span-3' : ''} ${it.available ? '' : 'opacity-60'}`}>
              <div className="relative aspect-[4/3] bg-mint">
                {it.image_url ? <Image src={it.image_url} alt={it.name} fill sizes="33vw" className="object-cover" />
                  : <ImageOff className="absolute inset-0 m-auto h-8 w-8 text-ink/30" aria-hidden />}
              </div>
              <div className="min-w-0 p-4">
                {editId === it.id ? (
                  <div className="grid min-w-0 gap-3 sm:grid-cols-2">
                    <Fields f={edit} set={setEdit} />
                    <label className="block min-w-0 sm:col-span-2"><span className="mb-1 block text-sm font-medium">صورة جديدة (اختياري)</span>
                      <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setEditFile(e.target.files?.[0] || null)} className={`${inp} py-2 text-sm file:me-3 file:rounded-lg file:border-0 file:bg-mint file:px-3 file:py-1.5 file:text-sm file:font-semibold`} /></label>
                    {editSt.error && <p role="alert" className="text-sm text-coral sm:col-span-2">{editSt.error}</p>}
                    <div className="flex gap-2 sm:col-span-2">
                      <button onClick={() => saveEdit(it)} disabled={editSt.loading} className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-ink font-semibold text-white disabled:opacity-60">
                        {editSt.loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Save className="h-4 w-4" aria-hidden />} حفظ
                      </button>
                      <button aria-label="إلغاء" onClick={() => setEditId(null)} className="grid h-11 w-11 place-items-center rounded-xl ring-1 ring-ink/20"><X className="h-4 w-4" /></button>
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="font-semibold">{it.name}</p>
                    <p className="text-sm text-ink/60">{it.category || 'بدون تصنيف'} · {Number(it.price).toLocaleString('ar-EG')} ج.م</p>
                    {sortExtras(it.menu_item_extras).length > 0 && (
                      <p className="mt-1 text-xs text-ink/60">زيادات: {sortExtras(it.menu_item_extras).map((x) => `${x.name} (+${Number(x.price)})`).join('، ')}</p>
                    )}
                    {it.track_stock && (
                      <p className={`mt-1 inline-flex items-center gap-1 text-sm font-semibold ${low ? 'text-coral' : 'text-ink/70'}`}>
                        {low && <AlertTriangle className="h-4 w-4" aria-hidden />}
                        {it.stock_qty === 0 ? 'خلص' : `المخزون: ${it.stock_qty}`}
                      </p>
                    )}
                    <div className="mt-3 flex gap-2">
                      <button onClick={() => startEdit(it)} className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl ring-1 ring-ink/20 text-sm font-semibold hover:bg-mint">
                        <Pencil className="h-4 w-4" aria-hidden /> تعديل
                      </button>
                      <button aria-label={it.available ? `إخفاء ${it.name}` : `إظهار ${it.name}`} onClick={() => toggle(it)} className="grid h-11 w-11 place-items-center rounded-xl ring-1 ring-ink/20 hover:bg-mint">
                        {it.available ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                      <button aria-label={`حذف ${it.name}`} onClick={() => remove(it)} className="grid h-11 w-11 place-items-center rounded-xl text-coral ring-1 ring-coral/30 hover:bg-coral/10">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
