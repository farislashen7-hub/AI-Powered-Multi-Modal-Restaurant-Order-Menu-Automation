import { Phone } from 'lucide-react';
import VideoBackground from '@/components/VideoBackground';
import { site as defaults } from '@/lib/site';

export default function Hero({ info }) {
  const site = info || defaults;
  return (
    <section className="relative isolate overflow-hidden bg-[#140b07] text-white">
      <VideoBackground />
      <div className="mx-auto max-w-6xl px-4 py-28 text-center md:py-44">
        <p className="mb-4 inline-flex items-center rounded-full border border-white/25 bg-white/10 px-4 py-1.5 text-sm font-medium backdrop-blur">
          {site.tagline}
        </p>
        <h1 className="mx-auto max-w-3xl text-4xl font-bold leading-[1.25] tracking-tight md:text-6xl">
          طعم الفحم الأصلي،<br className="hidden md:block" /> سخن من الشواية لحد بيتك
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-lg leading-relaxed text-white/85">
          اختار من المنيو واطلب أونلاين في دقيقة.
        </p>
        <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
          <a href="#menu" className="inline-flex min-h-[50px] items-center rounded-xl bg-saf px-8 font-bold text-ink shadow-lg transition hover:brightness-95">
            اطلب دلوقتي
          </a>
          <a href={`tel:${site.phone}`} className="inline-flex min-h-[50px] items-center gap-2 rounded-xl border border-white/30 px-6 font-semibold text-white transition hover:bg-white/10">
            <Phone className="h-4 w-4" aria-hidden /> <span dir="ltr">{site.phone}</span>
          </a>
        </div>
      </div>
    </section>
  );
}
