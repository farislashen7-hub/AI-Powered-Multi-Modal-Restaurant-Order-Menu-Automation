'use client';
import { useCallback, useEffect, useState } from 'react';
import { Phone, MapPin, Navigation, PackageCheck, Clock, Loader2, Radio, LogOut, Banknote, Ban, Power, StickyNote, CheckCircle2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { logout } from '@/app/auth/actions';
import ConfirmDialog from '@/components/ConfirmDialog';
import { courierCode, mapsLink, OUT_REASONS } from '@/lib/courier';

const SEL = 'id, order_no, order_type, created_at, customer_name, phone, address, area, notes, status, total, delivery_fee, assigned_at, order_items(id, name, qty, extras)';
const DONE_SEL = 'id, order_no, customer_name, total, delivered_at';
const money = (n) => `${Number(n || 0).toLocaleString('ar-EG')} ج.م`;
const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.toISOString(); };

export default function CourierApp({ me, initialCourier }) {
  const [courier, setCourier] = useState(initialCourier);
  const [orders, setOrders] = useState([]);
  const [doneList, setDoneList] = useState([]);
  const doneToday = doneList.length;
  const collected = doneList.reduce((s, o) => s + Number(o.total || 0), 0);
  const [loaded, setLoaded] = useState(false);
  const [live, setLive] = useState(false);
  const [busy, setBusy] = useState(null);
  const [err, setErr] = useState('');
  const [confirm, setConfirm] = useState(null); // { kind:'deliver', order } | { kind:'out' }
  const [reason, setReason] = useState(OUT_REASONS[0]);
  const out = courier.status === 'out_of_service';

  const load = useCallback(async () => {
    const supabase = createClient();
    const [act, done] = await Promise.all([
      supabase.from('orders').select(SEL).eq('courier_id', me.id).in('status', ['pending', 'preparing', 'ready']).order('assigned_at', { ascending: true }),
      supabase.from('orders').select(DONE_SEL).eq('courier_id', me.id).eq('status', 'delivered').gte('delivered_at', startOfToday()).order('delivered_at', { ascending: false }).limit(200),
    ]);
    if (act.error) setErr('تعذّر تحميل الطلبات. اتأكد إن الإدارة شغّلت migration_11.');
    else { setErr(''); setOrders(act.data || []); }
    if (!done.error) setDoneList(done.data || []);
    setLoaded(true);
  }, [me.id]);

  useEffect(() => {
    load();
    const supabase = createClient();
    const ch = supabase.channel('courier-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => load())
      .subscribe((s) => setLive(s === 'SUBSCRIBED'));
    const t = setInterval(load, 30000); // fallback if realtime drops
    return () => { clearInterval(t); supabase.removeChannel(ch); };
  }, [load]);

  async function post(url, body) {
    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(j.error || 'حصلت مشكلة، حاول تاني');
    return j;
  }

  async function run() {
    const c = confirm;
    setBusy(c.kind === 'deliver' ? c.order.id : 'status'); setErr('');
    try {
      if (c.kind === 'deliver') {
        await post(`/api/delivery/orders/${c.order.id}/delivered`);
        setOrders((l) => l.filter((o) => o.id !== c.order.id));
        setDoneList((l) => (l.some((x) => x.id === c.order.id) ? l : [{ id: c.order.id, order_no: c.order.order_no, customer_name: c.order.customer_name, total: c.order.total, delivered_at: new Date().toISOString() }, ...l]));
        load(); // resync with the server
      } else {
        await post('/api/delivery/status', { status: 'out_of_service', reason });
        setCourier((x) => ({ ...x, status: 'out_of_service', out_reason: reason }));
        setOrders([]);
      }
      setConfirm(null);
    } catch (e) { setErr(e.message); setConfirm(null); load(); } // stale list (reassigned/cancelled) -> refresh
    setBusy(null);
  }

  async function backToService() {
    setBusy('status'); setErr('');
    try {
      await post('/api/delivery/status', { status: 'available' });
      setCourier((x) => ({ ...x, status: 'available', out_reason: null }));
      load();
    } catch (e) { setErr(e.message); }
    setBusy(null);
  }

  return (
    <main className="mx-auto max-w-xl px-4 pb-16 pt-4">
      {/* profile */}
      <header className="rounded-3xl bg-ink p-4 text-white">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-saf text-lg font-bold text-ink" aria-hidden>{me.name.trim().slice(0, 1)}</span>
            <div className="min-w-0 leading-tight">
              <p className="truncate text-lg font-bold">{me.name}</p>
              <p className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-white/80">
                <span className="rounded-md bg-white/15 px-2 py-0.5 font-semibold tabular-nums" dir="ltr">ID {courierCode(courier.courier_no)}</span>
                {me.phone && <a href={`tel:${me.phone}`} dir="ltr" className="inline-flex items-center gap-1"><Phone className="h-3.5 w-3.5" aria-hidden />{me.phone}</a>}
              </p>
            </div>
          </div>
          <form action={logout}>
            <button aria-label="تسجيل الخروج" className="grid h-11 w-11 place-items-center rounded-xl bg-white/10 hover:bg-white/20"><LogOut className="h-5 w-5" aria-hidden /></button>
          </form>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          {[['للتوصيل', orders.length], ['اتسلّم النهاردة', doneToday], ['اتحصّل', collected]].map(([t, v]) => (
            <div key={t} className="rounded-2xl bg-white/10 p-2"><p className="text-xl font-bold tabular-nums">{Number(v).toLocaleString('ar-EG')}{t === 'اتحصّل' && <span className="text-xs font-normal"> ج.م</span>}</p><p className="text-xs text-white/70">{t}</p></div>
          ))}
        </div>
        <p className="mt-3 flex items-center gap-2 text-xs text-white/70"><Radio className={`h-4 w-4 ${live ? 'text-emerald-300' : 'text-white/40'}`} aria-hidden />{live ? 'تحديث لحظي شغال' : 'جاري الاتصال…'}</p>
      </header>

      {err && <p role="alert" className="mt-3 rounded-xl bg-coral/10 p-3 text-sm text-coral">{err}</p>}

      {/* service status */}
      {out ? (
        <div className="mt-4 rounded-2xl bg-coral/10 p-4 ring-1 ring-coral/30">
          <p className="flex items-center gap-2 font-bold text-coral"><Ban className="h-5 w-5" aria-hidden /> أنت خارج الخدمة</p>
          {courier.out_reason && <p className="mt-1 text-sm">السبب: {courier.out_reason}</p>}
          <p className="mt-1 text-sm text-ink/70">طلباتك رجعت للمطعم وهيوزعها على مندوب تاني.</p>
          <button onClick={backToService} disabled={busy === 'status'} className="mt-3 inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#0F7B4F] font-bold text-white disabled:opacity-60">
            {busy === 'status' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Power className="h-4 w-4" aria-hidden />} رجوع للخدمة
          </button>
        </div>
      ) : (
        <button onClick={() => setConfirm({ kind: 'out' })} className="mt-4 inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl text-sm font-bold text-coral ring-1 ring-coral/40 hover:bg-coral/10">
          <Ban className="h-4 w-4" aria-hidden /> خارج الخدمة (في مشكلة)
        </button>
      )}

      {/* orders */}
      {!out && (
        <section className="mt-5" aria-label="الطلبات اللي هتوصّلها">
          <h1 className="mb-3 text-lg font-bold">الطلبات اللي هتوصّلها</h1>
          {!loaded && <Loader2 className="mx-auto h-6 w-6 animate-spin" aria-label="تحميل" />}
          {loaded && orders.length === 0 && <p className="rounded-2xl bg-white p-8 text-center text-ink/60 ring-1 ring-ink/10">مفيش طلبات متعيّنة ليك دلوقتي.</p>}
          <ul className="space-y-4">
            {orders.map((o) => {
              const isReady = o.status === 'ready';
              return (
                <li key={o.id} className={`rounded-2xl bg-white p-4 ring-1 ${isReady ? 'ring-2 ring-emerald-500' : 'ring-ink/10'}`}>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-bold">{o.customer_name || 'عميل'} <span className="text-xs font-normal text-ink/60">#{o.order_no}</span></p>
                      <p className="text-xs text-ink/60">{new Date(o.created_at).toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit' })}</p>
                    </div>
                    <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold ${isReady ? 'bg-emerald-100 text-emerald-900' : 'bg-saf/25 text-ink'}`}>
                      {isReady ? <PackageCheck className="h-3.5 w-3.5" aria-hidden /> : <Clock className="h-3.5 w-3.5" aria-hidden />}{isReady ? 'جاهز للتوصيل' : 'لسه بيتحضر'}
                    </span>
                  </div>

                  <p className="mt-3 flex items-start gap-2 text-sm"><MapPin className="mt-0.5 h-4 w-4 shrink-0" aria-hidden /><span>{o.area ? <b>{o.area} · </b> : null}{o.address}</span></p>
                  {o.notes && <p className="mt-2 flex items-start gap-2 rounded-lg bg-mint p-2 text-sm"><StickyNote className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />{o.notes}</p>}
                  <p className="mt-2 text-sm text-ink/70">{(o.order_items || []).map((i) => `${i.qty}× ${i.name}`).join('، ')}</p>

                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <a href={`tel:${o.phone}`} className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl text-sm font-semibold ring-1 ring-ink/20"><Phone className="h-4 w-4" aria-hidden /> اتصل بالعميل</a>
                    <a href={mapsLink(`${o.area || ''} ${o.address}`)} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl text-sm font-semibold ring-1 ring-ink/20"><Navigation className="h-4 w-4" aria-hidden /> الخريطة</a>
                  </div>

                  <p className="mt-3 flex items-center justify-between rounded-xl bg-ink/5 p-3 text-sm"><span className="flex items-center gap-2"><Banknote className="h-4 w-4" aria-hidden /> المطلوب تحصيله</span><b className="text-base tabular-nums">{money(o.total)}</b></p>

                  <button onClick={() => setConfirm({ kind: 'deliver', order: o })} disabled={busy === o.id}
                    className="mt-3 inline-flex min-h-[52px] w-full items-center justify-center gap-2 rounded-xl bg-[#0F7B4F] text-base font-bold text-white disabled:opacity-60">
                    {busy === o.id ? <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> : <PackageCheck className="h-5 w-5" aria-hidden />} تم التسليم
                  </button>
                  {!isReady && <p className="mt-1 text-center text-xs text-ink/60">الطلب لسه بيتحضر في المطعم. اتأكد إنك استلمته قبل ما تضغط تم التسليم.</p>}
                </li>
              );
            })}
          </ul>
        </section>
      )}

      {doneList.length > 0 && (
        <details className="mt-6 rounded-2xl bg-white ring-1 ring-ink/10">
          <summary className="flex min-h-[48px] cursor-pointer items-center gap-2 px-4 font-bold">
            <CheckCircle2 className="h-5 w-5 text-[#0F7B4F]" aria-hidden /> اتسلّمت النهاردة ({doneList.length.toLocaleString('ar-EG')})
          </summary>
          <ul className="divide-y divide-ink/10 px-4 pb-2">
            {doneList.map((o) => (
              <li key={o.id} className="flex items-center justify-between gap-2 py-3 text-sm">
                <span className="min-w-0"><b>#{o.order_no}</b> <span className="text-ink/70">{o.customer_name || 'عميل'}</span>
                  <span className="block text-xs text-ink/60">{o.delivered_at ? new Date(o.delivered_at).toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit' }) : ''}</span></span>
                <b className="shrink-0 tabular-nums">{money(o.total)}</b>
              </li>
            ))}
          </ul>
        </details>
      )}

      <ConfirmDialog
        open={Boolean(confirm)}
        tone={confirm?.kind === 'deliver' ? 'success' : 'danger'}
        title={confirm?.kind === 'deliver' ? `تأكيد تسليم الطلب #${confirm.order.order_no}؟` : 'تحويل حالتك لخارج الخدمة؟'}
        description={confirm?.kind === 'deliver' ? `اتأكد إنك استلمت ${money(confirm.order.total)} من العميل. الطلب هيتحسب اتسلّم فورًا.${confirm.order.status !== 'ready' ? ' (المطعم لسه ماعلّمهوش جاهز)' : ''}` : 'طلباتك الحالية هترجع للمطعم يوزعها على مندوب تاني.'}
        confirmLabel={confirm?.kind === 'deliver' ? 'تم التسليم' : 'خارج الخدمة'}
        loading={Boolean(confirm) && busy !== null}
        onConfirm={run}
        onCancel={() => setConfirm(null)}
      >
        {confirm?.kind === 'out' && (
          <label className="block">
            <span className="mb-1 block text-sm font-medium">السبب</span>
            <select value={reason} onChange={(e) => setReason(e.target.value)} className="min-h-[44px] w-full rounded-xl border border-ink/20 bg-white px-3">
              {OUT_REASONS.map((r) => <option key={r}>{r}</option>)}
            </select>
          </label>
        )}
      </ConfirmDialog>
    </main>
  );
}
