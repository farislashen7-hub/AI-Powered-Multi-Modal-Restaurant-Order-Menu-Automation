'use client';
import { useFormState, useFormStatus } from 'react-dom';
import Link from 'next/link';
import { Loader2 } from 'lucide-react';

function Submit({ label }) {
  const { pending } = useFormStatus();
  return (
    <button disabled={pending}
      className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-ink px-4 font-bold text-white transition hover:bg-ink/90 disabled:opacity-60">
      {pending && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />} {label}
    </button>
  );
}

const Field = ({ label, name, type = 'text', autoComplete, required = true }) => (
  <label className="block">
    <span className="mb-1 block text-sm font-medium">{label}</span>
    <input name={name} type={type} required={required} autoComplete={autoComplete}
      className="min-h-[46px] w-full rounded-xl border border-ink/20 bg-white px-3 outline-none transition focus:border-ink focus:ring-2 focus:ring-saf/60" />
  </label>
);

export default function AuthForm({ mode, action, next }) {
  const [state, formAction] = useFormState(action, null);
  const signup = mode === 'signup';
  return (
    <form action={formAction} className="mx-auto w-full max-w-md space-y-4 rounded-3xl bg-white/95 p-7 shadow-2xl backdrop-blur">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{signup ? 'تسجيل حساب جديد' : 'دخول الموظفين والمناديب'}</h1>
        <p className="mt-1 text-sm text-ink/60">{signup ? 'التسجيل لعمال ومناديب المطعم بس. اطلب الكود من الأدمن.' : 'الصفحة دي لموظفي ومناديب المطعم. العملاء بيطلبوا من غير حساب.'}</p>
      </div>
      {signup && (
        <label className="block">
          <span className="mb-1 block text-sm font-medium">نوع الحساب</span>
          <select name="account_type" defaultValue="staff" className="min-h-[46px] w-full rounded-xl border border-ink/20 bg-white px-3 outline-none transition focus:border-ink focus:ring-2 focus:ring-saf/60">
            <option value="staff">موظف (طلبات المطعم)</option>
            <option value="delivery">مندوب توصيل</option>
          </select>
        </label>
      )}
      {signup && <Field label="الاسم" name="full_name" autoComplete="name" />}
      {signup && <Field label="رقم الموبايل (إجباري للمندوب)" name="phone" type="tel" autoComplete="tel" required={false} />}
      <Field label="البريد الإلكتروني" name="email" type="email" autoComplete="email" />
      <Field label="كلمة المرور" name="password" type="password" autoComplete={signup ? 'new-password' : 'current-password'} />
      {signup && <Field label="كود التسجيل (من الأدمن)" name="staff_code" type="password" autoComplete="off" />}
      {next && <input type="hidden" name="next" value={next} />}
      {state?.error && <p role="alert" className="text-sm text-coral">{state.error}</p>}
      {state?.ok && <p role="status" className="text-sm text-ink">{state.ok}</p>}
      <Submit label={signup ? 'تسجيل' : 'دخول'} />
      <p className="text-center text-sm">
        {signup ? 'عندك حساب؟ ' : 'موظف جديد؟ '}
        <Link href={signup ? '/login' : '/signup'} className="font-semibold underline">
          {signup ? 'سجّل الدخول' : 'سجّل كموظف'}
        </Link>
      </p>
    </form>
  );
}
