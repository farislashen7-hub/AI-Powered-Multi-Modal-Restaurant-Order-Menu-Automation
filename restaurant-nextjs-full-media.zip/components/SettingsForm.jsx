'use client';
import { useState } from 'react';
import { Loader2, Save, CheckCircle2 } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

const inp = 'min-h-[44px] w-full rounded-xl border border-ink/20 bg-white px-3';

// "@name" or "name" -> full profile URL; full URLs must be http(s)
function social(v, base) {
  const t = String(v || '').trim();
  if (!t) return null;
  if (/^https?:\/\//i.test(t)) return t;
  if (/^[a-z][a-z0-9+.-]*:/i.test(t)) throw new Error('الرابط لازم يبدأ بـ https://');
  return `${base}${t.replace(/^@/, '').replace(/^\/+/, '')}`;
}

// module level: an inner component remounts inputs on each keystroke (focus lost)
const L = ({ t, hint, children }) => (
  <label className="block"><span className="mb-1 block text-sm font-medium">{t}</span>{children}
    {hint && <span className="mt-1 block text-xs text-ink/60">{hint}</span>}</label>
);

export default function SettingsForm({ initial }) {
  const supabase = createClient();
  const [f, setF] = useState({
    phone: initial?.phone || '', whatsapp: initial?.whatsapp || '', address: initial?.address || '',
    maps_url: initial?.maps_url || '', instagram: initial?.instagram || '', facebook: initial?.facebook || '',
    hours: initial?.hours || '', delivery_fee: initial?.delivery_fee ?? 0,
  });
  const [st, setSt] = useState({ loading: false, error: '', ok: false });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function save(e) {
    e.preventDefault();
    setSt({ loading: true, error: '', ok: false });
    try {
      const fee = Number(String(f.delivery_fee).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(',', '.'));
      if (!Number.isFinite(fee) || fee < 0 || fee > 10000) throw new Error('سعر التوصيل لازم يكون رقم من 0 لـ 10000');
      const row = {
        id: 1,
        delivery_fee: Math.round(fee * 100) / 100,
        phone: f.phone.trim() || null,
        whatsapp: f.whatsapp.replace(/\D/g, '') || null,
        address: f.address.trim() || null,
        hours: f.hours.trim() || null,
        maps_url: social(f.maps_url, 'https://www.google.com/maps/search/?api=1&query='),
        instagram: social(f.instagram, 'https://instagram.com/'),
        facebook: social(f.facebook, 'https://facebook.com/'),
        updated_at: new Date().toISOString(),
      };
      const { error } = await supabase.from('site_settings').upsert(row);
      if (error) throw new Error(/delivery_fee/i.test(error.message) ? 'شغّل supabase/migration_10_delivery_fee.sql في Supabase الأول.' : error.message);
      setSt({ loading: false, error: '', ok: true });
    } catch (err) {
      setSt({ loading: false, error: err.message || 'فشل الحفظ', ok: false });
    }
  }

  return (
    <form onSubmit={save} className="grid gap-4 rounded-2xl bg-white p-5 ring-1 ring-ink/10 md:grid-cols-2">
      <h1 className="text-xl font-bold md:col-span-2">بيانات المطعم</h1>
      <L t="رقم التليفون" hint="زي 01012345678"><input dir="ltr" type="tel" value={f.phone} onChange={set('phone')} className={inp} /></L>
      <L t="رقم الواتساب" hint="بكود الدولة من غير + وصفر: 201012345678"><input dir="ltr" inputMode="numeric" value={f.whatsapp} onChange={set('whatsapp')} className={inp} /></L>
      <L t="العنوان"><input value={f.address} onChange={set('address')} className={inp} /></L>
      <L t="رابط الموقع على الخريطة" hint="الصق رابط Google Maps، أو اكتب اسم المكان"><input dir="ltr" value={f.maps_url} onChange={set('maps_url')} className={inp} /></L>
      <L t="انستجرام" hint="اليوزر (@name) أو الرابط الكامل"><input dir="ltr" value={f.instagram} onChange={set('instagram')} className={inp} /></L>
      <L t="فيسبوك" hint="اسم الصفحة أو الرابط الكامل"><input dir="ltr" value={f.facebook} onChange={set('facebook')} className={inp} /></L>
      <L t="سعر التوصيل (ج.م)" hint="بيتضاف على طلبات التوصيل بس. اكتب 0 لو التوصيل مجاني."><input dir="ltr" inputMode="decimal" min="0" value={f.delivery_fee} onChange={set('delivery_fee')} className={inp} /></L>
      <div className="md:col-span-2"><L t="أوقات العمل"><input value={f.hours} onChange={set('hours')} className={inp} /></L></div>
      {st.error && <p role="alert" className="text-sm text-coral md:col-span-2">{st.error}</p>}
      {st.ok && <p className="flex items-center gap-2 text-sm font-semibold text-emerald-700 md:col-span-2"><CheckCircle2 className="h-4 w-4" aria-hidden /> اتحفظ. التغيير ظاهر على الموقع.</p>}
      <button disabled={st.loading} className="flex min-h-[48px] items-center justify-center gap-2 rounded-xl bg-ink font-semibold text-white disabled:opacity-60 md:col-span-2">
        {st.loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Save className="h-4 w-4" aria-hidden />} حفظ
      </button>
    </form>
  );
}
