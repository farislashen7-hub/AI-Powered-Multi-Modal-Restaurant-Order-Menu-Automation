'use client';
import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Plus, Minus, ShoppingCart, X, Loader2, ImageOff, CheckCircle2, ExternalLink, Tag, MessageCircle, Clock } from 'lucide-react';
import { discountPct } from '@/lib/offerMessage';
import { offerLook, offerRing } from '@/lib/offerStyle';
import InvoiceView from '@/components/InvoiceView';
import { COUNTRIES, buildPhone } from '@/lib/phone';

const money = (n) => `${Number(n).toLocaleString('ar-EG')} ج.م`;
const OFFERS = '__offers__'; // virtual first tab, only when the owner has active offers
const offerDate = (d) => new Date(`${String(d).slice(0, 10)}T12:00:00Z`).toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', timeZone: 'UTC' });
const inputCls = 'min-h-[44px] w-full rounded-xl border border-ink/20 px-3';

export default function Menu({ items, offers = [], info, defaults }) {
  const [cat, setCat] = useState('');
  const [cart, setCart] = useState({}); // key -> { id, extras: [extraId], qty }
  const [ocart, setOcart] = useState({}); // offerId -> qty (offers order like normal items)
  const [detail, setDetail] = useState(null); // { item, sel: [extraId], qty }
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: defaults?.name || '', phone: defaults?.phone || '', address: '', area: '', notes: '' });
  const [type, setType] = useState('delivery'); // delivery | pickup
  const [cc, setCc] = useState('20'); // phone country code (Egypt default)
  const [st, setSt] = useState({ loading: false, error: '', invoice: null });

  // tab order: food → desserts → drinks (others keep their DB order; missing groups just skip)
  const cats = useMemo(() => {
    const rank = (c) => {
      const t = c.toLowerCase().replace(/[\u064B-\u065F]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه');
      if (/مشروب|مشاريب|عصير|عصاير|drink|beverage|juice/.test(t)) return 2;
      if (/حلو|dessert|sweet/.test(t)) return 1;
      return 0;
    };
    return [...new Set(items.map((i) => i.category).filter(Boolean))]
      .map((c, idx) => ({ c, idx, r: rank(c) }))
      .sort((a, b) => a.r - b.r || a.idx - b.idx)
      .map((x) => x.c);
  }, [items]);
  const tabs = offers.length ? [OFFERS, ...cats] : cats;
  const activeCat = tabs.includes(cat) ? cat : tabs[0]; // first tab by default (no "all" tab)
  const showOffers = offers.length > 0 && activeCat === OFFERS;
  const shown = showOffers ? [] : cats.length ? items.filter((i) => i.category === activeCat) : items;
  const byId = useMemo(() => Object.fromEntries(items.map((i) => [i.id, i])), [items]);
  const extrasOf = (i) => (i.menu_item_extras || []).filter((e) => e.available !== false)
    .sort((a, b) => (a.sort_order - b.sort_order) || a.name.localeCompare(b.name));
  const keyOf = (id, ex) => `${id}|${[...ex].sort().join(',')}`;
  const soldOut = (i) => i.track_stock && i.stock_qty <= 0;

  const lines = Object.entries(cart).map(([key, l]) => {
    const item = byId[l.id];
    const ex = extrasOf(item || {}).filter((e) => l.extras.includes(e.id));
    const unit = Number(item?.price || 0) + ex.reduce((s, e) => s + Number(e.price), 0);
    return { key, ...l, item, ex, unit };
  }).filter((l) => l.item);
  const offerById = useMemo(() => Object.fromEntries(offers.map((o) => [o.id, o])), [offers]);
  const olines = Object.entries(ocart).map(([id, qty]) => ({ id, qty, offer: offerById[id] })).filter((l) => l.offer && l.offer.price != null);
  const offerCount = olines.reduce((s, l) => s + l.qty, 0);
  const offerSum = olines.reduce((s, l) => s + l.qty * Number(l.offer.price), 0);
  const count = lines.reduce((s, l) => s + l.qty, 0) + offerCount;
  const linesTotal = lines.reduce((s, l) => s + l.qty * l.unit, 0);
  const total = linesTotal + offerSum;
  const itemsSum = lines.reduce((s, l) => s + l.qty * Number(l.item.price), 0) + offerSum;
  const extrasSum = linesTotal - lines.reduce((s, l) => s + l.qty * Number(l.item.price), 0);
  const changeOffer = (id, d) => setOcart((c) => {
    const q = Math.max(0, Math.min(50, (c[id] || 0) + d));
    const n = { ...c }; if (q) n[id] = q; else delete n[id];
    return n;
  });
  const fee = type === 'delivery' ? Number(info?.deliveryFee || 0) : 0; // display only: server recomputes
  const grand = total + fee;
  const qtyOfItem = (id) => lines.filter((l) => l.id === id).reduce((s, l) => s + l.qty, 0);

  // delta on a cart line; stock cap counts all lines of the same item
  const change = (id, extras, d) =>
    setCart((c) => {
      const it = byId[id]; if (!it) return c;
      const key = keyOf(id, extras);
      const others = Object.values(c).filter((l) => l.id === id && keyOf(l.id, l.extras) !== key).reduce((s, l) => s + l.qty, 0);
      const cap = it.track_stock ? Math.max(0, Math.min(50, it.stock_qty - others)) : 50;
      const q = Math.max(0, Math.min(cap, (c[key]?.qty || 0) + d));
      const n = { ...c };
      if (q) n[key] = { id, extras: [...extras].sort(), qty: q }; else delete n[key];
      return n;
    });

  const openDetail = (item) => setDetail({ item, sel: [], qty: 1 });
  const editLine = (l) => setDetail({ item: l.item, sel: l.extras, qty: l.qty, replaceKey: l.key });
  const quickAdd = (item) => (extrasOf(item).length ? openDetail(item) : change(item.id, [], 1));

  const detailUnit = detail
    ? Number(detail.item.price) + extrasOf(detail.item).filter((e) => detail.sel.includes(e.id)).reduce((s, e) => s + Number(e.price), 0)
    : 0;
  const detailMax = detail ? (detail.item.track_stock ? Math.max(1, Math.min(50, detail.item.stock_qty)) : 50) : 50;

  // Esc closes whichever dialog is on top
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') { if (detail) setDetail(null); else if (open) setOpen(false); } };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [detail, open]);

  async function submit(e) {
    e.preventDefault();
    setSt({ loading: true, error: '', invoice: null });
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, phone: buildPhone(cc, form.phone), type, address: type === 'pickup' ? '' : form.address, items: [...lines.map((l) => ({ id: l.id, qty: l.qty, extras: l.extras })), ...olines.map((l) => ({ offer_id: l.id, qty: l.qty }))] }),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(j.error || 'حصلت مشكلة، حاول تاني');
      // if the server could not re-read the order, build the invoice from what we just sent
      const invoice = j.invoice || {
        id: j.id, order_no: null, order_type: type, created_at: new Date().toISOString(),
        customer_name: form.name, phone: form.phone, address: type === 'pickup' ? 'استلام من المطعم' : form.address,
        notes: form.notes, status: 'pending', total: grand, delivery_fee: fee,
        order_items: [
          ...lines.map((l) => ({
            name: l.item.name, qty: l.qty, unit_price: l.item.price,
            extras: l.ex.map((x) => ({ name: x.name, price: x.price })),
            extras_total: l.ex.reduce((a, x) => a + Number(x.price), 0),
          })),
          ...olines.map((l) => ({ name: l.offer.title, qty: l.qty, unit_price: l.offer.price, extras: [], extras_total: 0 })),
        ],
      };
      setCart({}); setOcart({});
      setForm((f) => ({ ...f, address: '', area: '', notes: '' }));
      setSt({ loading: false, error: '', invoice });
    } catch (err) {
      setSt({ loading: false, error: err.message || 'حصلت مشكلة، حاول تاني', invoice: null });
    }
  }

  const closeCart = () => { setOpen(false); setSt((s) => ({ ...s, invoice: null, error: '' })); };

  return (
    <main id="menu" className="mx-auto max-w-6xl scroll-mt-16 px-4 pb-28 pt-14">
      <div className="mb-6 text-center">
        <p className="text-sm font-bold text-coral">المنيو</p>
        <h2 className="mt-1 text-3xl font-bold tracking-tight">اختار طلبك</h2>
      </div>
      <div className="sticky top-[61px] z-20 -mx-4 mb-6 flex gap-2 overflow-x-auto bg-[#F6F7F4]/90 px-4 py-3 backdrop-blur md:justify-center" role="tablist" aria-label="التصنيفات">
        {tabs.map((c) => (
          <button key={c} role="tab" aria-selected={activeCat === c} onClick={() => setCat(c)}
            className={`min-h-[44px] shrink-0 rounded-full px-5 text-sm font-semibold transition ${
              activeCat === c ? 'bg-ink text-white' : 'bg-white text-ink ring-1 ring-ink/15 hover:bg-mint'}`}>
            {c === OFFERS ? <span className="inline-flex items-center gap-1.5"><Tag className="h-4 w-4" aria-hidden /> العروض</span> : c}
          </button>
        ))}
      </div>

      {showOffers && (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-label="العروض">
          {offers.map((o) => {
            const pct = discountPct(o);
            const wa = String(info?.whatsapp || '').replace(/\D/g, '');
            const t = offerLook(o);
            const banner = o.card_layout === 'banner';
            return (
              <li key={o.id} className={`group flex overflow-hidden rounded-2xl shadow-sm ring-1 ring-ink/10 transition duration-300 hover:-translate-y-1 hover:shadow-lg ${banner ? 'flex-col sm:col-span-2 sm:flex-row lg:col-span-3' : 'flex-col'}`} style={{ background: t.bg, color: t.fg }}>
                <span className={`relative block overflow-hidden bg-mint ${banner ? 'aspect-[4/3] sm:aspect-auto sm:min-h-[200px] sm:w-2/5 sm:shrink-0' : 'aspect-[4/3]'}`}>
                  {o.image_url ? (
                    <Image src={o.image_url} alt="" fill sizes="(max-width:640px) 100vw, 33vw" className="object-cover transition duration-500 group-hover:scale-105" />
                  ) : (
                    <ImageOff className="absolute inset-0 m-auto h-8 w-8 text-ink/30" aria-hidden />
                  )}
                  <span className="absolute start-3 top-3 inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-bold shadow" style={{ background: t.badge, color: t.badgeFg }}><Tag className="h-3.5 w-3.5" aria-hidden /> {o.badge_text?.trim() || 'عرض'}</span>
                  {pct > 0 && <span className="absolute end-3 top-3 rounded-full px-3 py-1 text-xs font-bold shadow" style={{ background: t.pill, color: t.pillFg }}>خصم {pct.toLocaleString('ar-EG')}%</span>}
                </span>
                <div className="flex min-w-0 flex-1 flex-col">
                  <div className="px-4 pt-4">
                    <span className="block text-lg font-semibold">{o.title}</span>
                    {o.description && <span className="mt-1 line-clamp-2 block whitespace-pre-line text-sm opacity-75">{o.description}</span>}
                    {o.valid_until && <span className="mt-1 inline-flex items-center gap-1 text-xs opacity-70"><Clock className="h-3.5 w-3.5" aria-hidden /> ساري حتى {offerDate(o.valid_until)}</span>}
                  </div>
                  <div className="mt-auto flex items-center justify-between gap-2 p-4 pt-2">
                    {o.price != null ? (
                      <span className="flex items-baseline gap-2">
                        <span className="text-lg font-bold tabular-nums">{money(o.price)}</span>
                        {pct > 0 && <s className="text-sm tabular-nums opacity-60">{money(o.old_price)}</s>}
                      </span>
                    ) : <span />}
                    {o.price != null ? (
                      ocart[o.id] > 0 ? (
                        <div className="flex items-center gap-1">
                          <button aria-label="إنقاص" onClick={() => changeOffer(o.id, -1)} className="grid h-11 w-11 place-items-center rounded-xl" style={offerRing(t)}><Minus className="h-4 w-4" /></button>
                          <span className="w-8 text-center font-semibold" aria-live="polite">{ocart[o.id]}</span>
                          <button aria-label="زيادة" onClick={() => changeOffer(o.id, 1)} className="grid h-11 w-11 place-items-center rounded-xl" style={{ background: t.accent, color: t.accentFg }}><Plus className="h-4 w-4" /></button>
                        </div>
                      ) : (
                        <button onClick={() => changeOffer(o.id, 1)} className="inline-flex min-h-[44px] items-center gap-1 rounded-xl px-4 text-sm font-semibold transition hover:brightness-95" style={{ background: t.accent, color: t.accentFg }}>
                          <Plus className="h-4 w-4" aria-hidden /> أضف
                        </button>
                      )
                    ) : wa && (
                      <a href={`https://wa.me/${wa}?text=${encodeURIComponent(`عايز أطلب عرض: ${o.title}`)}`} target="_blank" rel="noopener noreferrer"
                        className="inline-flex min-h-[44px] items-center gap-1 rounded-xl px-4 text-sm font-semibold transition hover:brightness-95" style={{ background: t.accent, color: t.accentFg }}>
                        <MessageCircle className="h-4 w-4" aria-hidden /> اطلب
                      </a>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {shown.length === 0 && !showOffers && <p className="py-16 text-center text-ink/60">المنيو فاضي حاليًا.</p>}

      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {shown.map((i) => (
          <li key={i.id} className="group flex flex-col overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-ink/10 transition duration-300 hover:-translate-y-1 hover:shadow-lg">
            <button type="button" onClick={() => openDetail(i)} aria-label={`تفاصيل ${i.name}`} className="text-start">
              <span className="relative block aspect-[4/3] overflow-hidden bg-mint">
                {i.image_url ? (
                  <Image src={i.image_url} alt="" fill sizes="(max-width:640px) 100vw, 33vw" className="object-cover transition duration-500 group-hover:scale-105" />
                ) : (
                  <ImageOff className="absolute inset-0 m-auto h-8 w-8 text-ink/30" aria-hidden />
                )}
              </span>
              <span className="block px-4 pt-4">
                <span className="block text-lg font-semibold">{i.name}</span>
                {i.description && <span className="mt-1 line-clamp-2 block text-sm text-ink/70">{i.description}</span>}
              </span>
            </button>
            <div className="mt-auto flex items-center justify-between gap-2 p-4 pt-2">
              <span className="text-lg font-bold tabular-nums">{money(i.price)}</span>
              {soldOut(i) ? (
                <span className="inline-flex min-h-[44px] items-center rounded-xl bg-ink/10 px-4 text-sm font-semibold text-ink/60">خلص</span>
              ) : extrasOf(i).length === 0 && qtyOfItem(i.id) > 0 ? (
                <div className="flex items-center gap-1">
                  <button aria-label="إنقاص" onClick={() => change(i.id, [], -1)} className="grid h-11 w-11 place-items-center rounded-xl ring-1 ring-ink/20 hover:bg-mint"><Minus className="h-4 w-4" /></button>
                  <span className="w-8 text-center font-semibold" aria-live="polite">{qtyOfItem(i.id)}</span>
                  <button aria-label="زيادة" onClick={() => change(i.id, [], 1)} className="grid h-11 w-11 place-items-center rounded-xl bg-ink text-white hover:bg-ink/90"><Plus className="h-4 w-4" /></button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  {qtyOfItem(i.id) > 0 && <span className="rounded-full bg-mint px-2.5 py-1 text-xs font-semibold">في السلة: {qtyOfItem(i.id)}</span>}
                  <button onClick={() => quickAdd(i)} className="inline-flex min-h-[44px] items-center gap-1 rounded-xl bg-saf px-4 text-sm font-semibold text-ink transition hover:brightness-95">
                    <Plus className="h-4 w-4" aria-hidden /> {extrasOf(i).length ? 'اختار' : 'أضف'}
                  </button>
                </div>
              )}
            </div>
          </li>
        ))}
      </ul>

      {/* Cart button: icon + count badge + total. Only when the cart has items. */}
      {count > 0 && !open && !detail && (
        <button onClick={() => setOpen(true)} aria-label={`فتح السلة، ${count} عنصر، ${money(total)}`}
          className="fixed inset-x-4 bottom-4 z-40 mx-auto flex min-h-[56px] max-w-md items-center justify-between rounded-2xl bg-ink px-5 font-semibold text-white shadow-xl transition hover:bg-ink/90">
          <span className="flex items-center gap-3">
            <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-white/10">
              <ShoppingCart className="h-5 w-5" aria-hidden />
              <span className="absolute -end-1.5 -top-1.5 grid h-5 min-w-[20px] place-items-center rounded-full bg-saf px-1 text-xs font-bold text-ink">{count}</span>
            </span>
            عرض السلة
          </span>
          <span className="tabular-nums">{money(total)}</span>
        </button>
      )}

      {/* Dish details */}
      {detail && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center bg-black/50 sm:items-center" role="dialog" aria-modal="true" aria-label={detail.item.name}
          onClick={(e) => { if (e.target === e.currentTarget) setDetail(null); }}>
          <div className="max-h-[92vh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-white sm:rounded-3xl">
            <div className="relative aspect-[16/10] bg-mint">
              {detail.item.image_url
                ? <Image src={detail.item.image_url} alt="" fill sizes="448px" className="object-cover" />
                : <ImageOff className="absolute inset-0 m-auto h-10 w-10 text-ink/30" aria-hidden />}
              <button aria-label="إغلاق" onClick={() => setDetail(null)} className="absolute end-3 top-3 grid h-11 w-11 place-items-center rounded-full bg-white/90 shadow hover:bg-white"><X className="h-5 w-5" /></button>
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <h2 className="text-xl font-bold">{detail.item.name}</h2>
                <span className="shrink-0 text-lg font-bold tabular-nums">{money(detail.item.price)}</span>
              </div>
              {detail.item.description && <p className="mt-2 text-sm leading-relaxed text-ink/70">{detail.item.description}</p>}

              {extrasOf(detail.item).length > 0 && (
                <fieldset className="mt-4">
                  <legend className="mb-2 text-sm font-semibold">الإضافات (اختياري)</legend>
                  <ul className="space-y-2">
                    {extrasOf(detail.item).map((e) => (
                      <li key={e.id}>
                        <label className="flex min-h-[48px] cursor-pointer items-center justify-between gap-3 rounded-xl px-3 ring-1 ring-ink/15 has-[:checked]:bg-mint">
                          <span className="flex items-center gap-3">
                            <input type="checkbox" className="h-5 w-5" checked={detail.sel.includes(e.id)}
                              onChange={(ev) => setDetail((d) => ({ ...d, sel: ev.target.checked ? [...d.sel, e.id] : d.sel.filter((x) => x !== e.id) }))} />
                            {e.name}
                          </span>
                          <span className="text-sm tabular-nums">{Number(e.price) > 0 ? `+ ${money(e.price)}` : 'مجاني'}</span>
                        </label>
                      </li>
                    ))}
                  </ul>
                </fieldset>
              )}

              {soldOut(detail.item) ? (
                <p className="mt-5 rounded-xl bg-ink/10 p-3 text-center font-semibold text-ink/70">الصنف خلص حاليًا</p>
              ) : (
                <div className="mt-5 flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <button aria-label="إنقاص" onClick={() => setDetail((d) => ({ ...d, qty: Math.max(1, d.qty - 1) }))} className="grid h-11 w-11 place-items-center rounded-xl ring-1 ring-ink/20 hover:bg-mint"><Minus className="h-4 w-4" /></button>
                    <span className="w-8 text-center font-semibold" aria-live="polite">{detail.qty}</span>
                    <button aria-label="زيادة" onClick={() => setDetail((d) => ({ ...d, qty: Math.min(detailMax, d.qty + 1) }))} className="grid h-11 w-11 place-items-center rounded-xl ring-1 ring-ink/20 hover:bg-mint"><Plus className="h-4 w-4" /></button>
                  </div>
                  <button onClick={() => {
                      if (detail.replaceKey) setCart((c) => { const n = { ...c }; delete n[detail.replaceKey]; return n; });
                      change(detail.item.id, detail.sel, detail.qty);
                      setDetail(null);
                    }}
                    className="flex min-h-[48px] flex-1 items-center justify-between rounded-xl bg-ink px-4 font-semibold text-white hover:bg-ink/90">
                    <span>{detail.replaceKey ? 'تحديث الطلب' : 'أضف للسلة'}</span>
                    <span className="tabular-nums">{money(detailUnit * detail.qty)}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Cart + checkout (guest allowed) + invoice */}
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center" role="dialog" aria-modal="true" aria-label="السلة"
          onClick={(e) => { if (e.target === e.currentTarget) closeCart(); }}>
          <div className="max-h-[92vh] w-full max-w-md overflow-y-auto rounded-t-3xl bg-white p-5 sm:rounded-3xl">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-xl font-bold">{st.invoice ? 'تم استلام طلبك' : 'طلبك'}</h2>
              <button aria-label="إغلاق" onClick={closeCart} className="grid h-11 w-11 place-items-center rounded-xl hover:bg-mint"><X className="h-5 w-5" /></button>
            </div>

            {st.invoice ? (
              <div className="space-y-4">
                <p className="flex items-center gap-2 text-sm font-semibold text-emerald-700"><CheckCircle2 className="h-5 w-5" aria-hidden /> هنكلمك على الموبايل للتأكيد.</p>
                <InvoiceView order={st.invoice} info={info} />
                <div className="flex gap-2">
                  <Link href={`/invoice/${st.invoice.id}`} target="_blank" className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-ink px-4 text-sm font-semibold text-white">
                    <ExternalLink className="h-4 w-4" aria-hidden /> فتح الفاتورة وطباعتها
                  </Link>
                  <button onClick={closeCart} className="min-h-[44px] rounded-xl px-5 text-sm font-semibold ring-1 ring-ink/20">تمام</button>
                </div>
              </div>
            ) : (
              <>
                <ul className="divide-y divide-ink/10">
                  {lines.map((l) => (
                    <li key={l.key} className="flex items-start justify-between gap-3 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="flex justify-between gap-2 font-semibold"><span>{l.item.name}</span><span className="tabular-nums">{money(l.item.price)}</span></p>
                        {l.ex.map((e) => (
                          <p key={e.id} className="flex justify-between gap-2 text-sm text-ink/70">
                            <span>+ {e.name}</span><span className="tabular-nums">{Number(e.price) > 0 ? `+ ${money(e.price)}` : 'مجاني'}</span>
                          </p>
                        ))}
                        <p className="mt-1 flex justify-between gap-2 text-sm font-semibold">
                          <span className="font-normal text-ink/60">{l.qty} × {money(l.unit)}</span><span className="tabular-nums">{money(l.qty * l.unit)}</span>
                        </p>
                        {extrasOf(l.item).length > 0 && (
                          <button type="button" onClick={() => editLine(l)} className="mt-1 inline-flex min-h-[32px] items-center text-xs font-semibold underline">
                            {l.ex.length ? 'تعديل الإضافات' : '+ إضافات'}
                          </button>
                        )}
                      </div>
                      <div className="flex shrink-0 items-center gap-1">
                        <button aria-label="إنقاص" onClick={() => change(l.id, l.extras, -1)} className="grid h-9 w-9 place-items-center rounded-lg ring-1 ring-ink/20"><Minus className="h-4 w-4" /></button>
                        <span className="w-6 text-center">{l.qty}</span>
                        <button aria-label="زيادة" onClick={() => change(l.id, l.extras, 1)} className="grid h-9 w-9 place-items-center rounded-lg ring-1 ring-ink/20"><Plus className="h-4 w-4" /></button>
                      </div>
                    </li>
                  ))}
                  {olines.map((l) => (
                    <li key={`o-${l.id}`} className="flex items-start justify-between gap-3 py-3">
                      <div className="min-w-0 flex-1">
                        <p className="flex justify-between gap-2 font-semibold"><span className="inline-flex items-center gap-1"><Tag className="h-3.5 w-3.5 text-saf" aria-hidden /> {l.offer.title}</span><span className="tabular-nums">{money(l.offer.price)}</span></p>
                        <p className="mt-1 flex justify-between gap-2 text-sm font-semibold">
                          <span className="font-normal text-ink/60">{l.qty} × {money(l.offer.price)}</span><span className="tabular-nums">{money(l.qty * Number(l.offer.price))}</span>
                        </p>
                      </div>
                      <div className="flex shrink-0 items-center gap-1">
                        <button aria-label="إنقاص" onClick={() => changeOffer(l.id, -1)} className="grid h-9 w-9 place-items-center rounded-lg ring-1 ring-ink/20"><Minus className="h-4 w-4" /></button>
                        <span className="w-6 text-center">{l.qty}</span>
                        <button aria-label="زيادة" onClick={() => changeOffer(l.id, 1)} className="grid h-9 w-9 place-items-center rounded-lg ring-1 ring-ink/20"><Plus className="h-4 w-4" /></button>
                      </div>
                    </li>
                  ))}
                </ul>
                {count === 0 && <p className="py-6 text-center text-ink/60">السلة فاضية.</p>}
                <dl className="my-3 space-y-1 border-t border-ink/10 pt-3 text-sm">
                  <div className="flex justify-between"><dt className="text-ink/70">سعر الأصناف</dt><dd className="tabular-nums">{money(itemsSum)}</dd></div>
                  {extrasSum > 0 && <div className="flex justify-between"><dt className="text-ink/70">الإضافات</dt><dd className="tabular-nums">{money(extrasSum)}</dd></div>}
                  {type === 'delivery' && <div className="flex justify-between"><dt className="text-ink/70">التوصيل</dt><dd className="tabular-nums">{fee > 0 ? money(fee) : 'مجاني'}</dd></div>}
                  <div className="flex justify-between text-base font-bold"><dt>الإجمالي</dt><dd className="tabular-nums">{money(grand)}</dd></div>
                </dl>

                <form onSubmit={submit} className="space-y-3">
                  <fieldset>
                    <legend className="mb-2 text-sm font-semibold">طريقة الاستلام</legend>
                    <div className="grid grid-cols-2 gap-2">
                      {[['delivery', 'توصيل'], ['pickup', 'استلام من المطعم']].map(([k, t]) => (
                        <label key={k} className={`flex min-h-[48px] cursor-pointer items-center justify-center rounded-xl px-3 text-sm font-semibold ring-1 transition has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ink ${
                          type === k ? 'bg-ink text-white ring-ink' : 'bg-white ring-ink/20 hover:bg-mint'}`}>
                          <input type="radio" name="type" value={k} checked={type === k} onChange={() => setType(k)} className="sr-only" />
                          {t}
                        </label>
                      ))}
                    </div>
                  </fieldset>
                  <input required minLength={2} maxLength={80} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} autoComplete="name" aria-label="الاسم" placeholder="الاسم" className={inputCls} />
                  <div className="flex gap-2">
                    <select value={cc} onChange={(e) => setCc(e.target.value)} aria-label="كود الدولة" className="min-h-[44px] w-[42%] shrink-0 rounded-xl border border-ink/20 bg-white px-2 text-sm">
                      {COUNTRIES.map(([k, t]) => <option key={k} value={k}>{t}</option>)}
                    </select>
                    <input required maxLength={30} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} type="tel" inputMode="tel" autoComplete="tel-national" aria-label="رقم الموبايل" placeholder="رقم الموبايل" dir="ltr" className={inputCls} />
                  </div>
                  {type === 'delivery' ? (
                    <>
                      <input required minLength={2} maxLength={80} value={form.area} onChange={(e) => setForm({ ...form, area: e.target.value })} aria-label="المنطقة" placeholder="المنطقة (مثال: المحلة - الجمهورية)" className={inputCls} />
                      <input required minLength={5} maxLength={300} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} autoComplete="street-address" aria-label="العنوان" placeholder="العنوان بالتفصيل" className={inputCls} />
                    </>
                  ) : (
                    <p className="rounded-xl bg-mint p-3 text-sm">هتستلم طلبك من المطعم{info?.address ? `: ${info.address}` : ''}. مش محتاجين عنوان.</p>
                  )}
                  <textarea maxLength={500} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} aria-label="ملاحظات" placeholder="ملاحظات (اختياري)" rows={2} className="w-full rounded-xl border border-ink/20 px-3 py-2" />
                  {st.error && <p role="alert" className="text-sm text-coral">{st.error}</p>}
                  <button disabled={st.loading || !count} className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-ink font-semibold text-white disabled:opacity-60">
                    {st.loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />} تأكيد الطلب
                  </button>
                  <p className="text-center text-xs text-ink/60">من غير ما تسجّل دخول · الدفع عند الاستلام</p>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </main>
  );
}
