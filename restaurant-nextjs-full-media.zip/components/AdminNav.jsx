'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ClipboardList, UtensilsCrossed, BarChart3, Users, Settings, Home, Megaphone, Bike, MessagesSquare } from 'lucide-react';

const links = [
  ['/admin', 'الطلبات', ClipboardList],
  ['/admin/chats', 'محادثات واتساب', MessagesSquare],
  ['/admin/menu', 'المنيو والمخزون', UtensilsCrossed],
  ['/admin/reports', 'التقارير', BarChart3],
  ['/admin/offers', 'العروض', Megaphone],
  ['/admin/delivery', 'الدليفري', Bike],
  ['/admin/staff', 'الموظفين', Users],
  ['/admin/settings', 'بيانات المطعم', Settings],
];
const STAFF_ONLY = ['/admin', '/admin/chats'];

export default function AdminNav({ role }) {
  const path = usePathname();
  const base = 'flex min-h-[44px] shrink-0 items-center gap-3 rounded-xl px-3 text-sm font-semibold transition';
  return (
    <nav aria-label="لوحة الإدارة" className="flex gap-1 overflow-x-auto px-3 pb-3 lg:flex-1 lg:flex-col lg:pb-4">
      {links.filter(([href]) => role === 'admin' || STAFF_ONLY.includes(href)).map(([href, t, Icon]) => {
        const active = href === '/admin' ? path === '/admin' : path.startsWith(href);
        return (
          <Link key={href} href={href} aria-current={active ? 'page' : undefined}
            className={`${base} ${active ? 'bg-white/15 text-white' : 'text-white/70 hover:bg-white/10 hover:text-white'}`}>
            <Icon className="h-5 w-5" aria-hidden /> {t}
          </Link>
        );
      })}
      <Link href="/" className={`${base} text-white/70 hover:bg-white/10 hover:text-white lg:mt-auto`}>
        <Home className="h-5 w-5" aria-hidden /> الموقع
      </Link>
    </nav>
  );
}
