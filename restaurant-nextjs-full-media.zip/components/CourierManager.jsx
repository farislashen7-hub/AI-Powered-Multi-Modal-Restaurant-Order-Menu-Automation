'use client';
import { useState } from 'react';
import { Bike, Phone, Mail, Loader2, Power, Ban, PackageCheck, ClipboardList, ChevronDown, MapPin } from 'lucide-react';
import { courierCode } from '@/lib/courier';

const money = (n) => `${Number(n || 0).toLocaleString('ar-EG')} ج.م`;
const nameOf = (p) => (p?.full_name || '').trim() || (p?.email ? p.email.split('@')[0] : '') || 'بدون اسم';

function DeliveredOrder({ o }) {
  const items = o.order_items || [];
  return (
    <li className="rounded-xl bg-ink/5 p-3 text-sm">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate font-bold">{o.customer_name || 'عميل'} <span className="text-xs font-normal text-ink/60 tabular-nums">#{o.order_no}</span></p>
          <p className="text-xs text-ink/60">{o.delivered_at ? new Date(o.delivered_at).toLocaleString('ar-EG') : '—'}</p>
        </div>
        <span className="shrink-0 rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-900">تم التسليم</span>
      </div>
      {o.phone && <p className="mt-2 flex items-center gap-2"><Phone className="h-4 w-4 shrink-0" aria-hidden /><a href={`tel:${o.phone}`} dir="ltr">{o.phone}</a></p>}
      <p className="mt-1 flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0" aria-hidden /><span>{o.order_type === 'pickup' ? 'استلام من المطعم' : `${o.area ? `${o.area} · ` : ''}${o.address || ''}`}</span></p>
      <ul className="my-2 divide-y divide-ink/10 rounded-lg bg-white px-2">
        {items.map((it) => (
          <li key={it.id} className="py-1">
            <div className="flex justify-between gap-2"><span>{it.qty}× {it.name}</span><span className="tabular-nums">{money(it.qty * (Number(it.unit_price) + Number(it.extras_total || 0)))}</span></div>
            {(it.extras || []).length > 0 && <p className="text-xs text-ink/60">+ {it.extras.map((x) => x.name).join('، ')}</p>}
          </li>
        ))}
        {items.length === 0 && <li className="py-1 text-ink/60">مفيش أصناف.</li>}
      </ul>
      {Number(o.delivery_fee) > 0 && <p className="flex justify-between text-ink/70"><span>التوصيل</span><span className="tabular-nums">{money(o.delivery_fee)}</span></p>}
      {o.notes && <p className="mt-1 rounded-lg bg-mint p-2">{o.notes}</p>}
      <p className="mt-1 flex justify-between font-bold"><span>الإجمالي</span><span className="tabular-nums">{money(o.total)}</span></p>
    </li>
  );
}

export default function CourierManager({ initial, loadError }) {
  const [rows, setRows] = useState(initial);
  const [busy, setBusy] = useState(null);
  const [err, setErr] = useState(loadError || '');
  const [open, setOpen] = useState(null);

  async function setStatus(c, status) {
    if (status === 'out_of_service' && !confirm(`تحويل ${nameOf(c.profile)} لخارج الخدمة؟ طلباته الحالية هترجع للمطعم.`)) return;
    setBusy(c.id); setErr('');
    const res = await fetch(`/api/admin/couriers/${c.id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) setErr(j.error || 'تعذّر التحديث');
    else setRows((l) => l.map((x) => (x.id === c.id ? { ...x, status, out_reason: status === 'out_of_service' ? 'من الإدارة' : null, stats: status === 'out_of_service' ? { ...x.stats, active: 0 } : x.stats } : x)));
    setBusy(null);
  }

  const out = rows.filter((r) => r.status === 'out_of_service').length;

  return (
    <section>
      <h1 className="flex items-center gap-2 text-xl font-bold"><Bike className="h-5 w-5" aria-hidden /> المناديب (الدليفري)</h1>
      {err && <p role="alert" className="mt-3 rounded-xl bg-coral/10 p-3 text-sm text-coral">{err}</p>}
      <p className="mt-4 text-sm text-ink/70">{rows.length.toLocaleString('ar-EG')} مندوب · {out.toLocaleString('ar-EG')} خارج الخدمة</p>

      {rows.length === 0 && !err && <p className="mt-4 rounded-2xl bg-white p-8 text-center text-ink/60 ring-1 ring-ink/10">مفيش مناديب لسه.</p>}
      <ul className="mt-3 grid gap-4 md:grid-cols-2">
        {rows.map((c) => {
          const isOut = c.status === 'out_of_service';
          return (
            <li key={c.id} className={`rounded-2xl bg-white p-4 ring-1 ${isOut ? 'ring-coral/40' : 'ring-ink/10'}`}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-saf/30 font-bold" aria-hidden>{nameOf(c.profile).slice(0, 1)}</span>
                  <div className="min-w-0 leading-tight">
                    <p className="truncate font-bold">{nameOf(c.profile)}</p>
                    <p className="text-sm text-ink/60 tabular-nums" dir="ltr">ID {courierCode(c.courier_no)}</p>
                  </div>
                </div>
                <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-semibold ${isOut ? 'bg-coral/15 text-coral' : 'bg-emerald-100 text-emerald-900'}`}>
                  {isOut ? <Ban className="h-3.5 w-3.5" aria-hidden /> : <PackageCheck className="h-3.5 w-3.5" aria-hidden />}{isOut ? 'خارج الخدمة' : 'متاح'}
                </span>
              </div>
              <div className="mt-3 space-y-1 text-sm">
                {c.profile.phone && <p className="flex items-center gap-2"><Phone className="h-4 w-4" aria-hidden /><a href={`tel:${c.profile.phone}`} dir="ltr">{c.profile.phone}</a></p>}
                {c.profile.email && <p className="flex items-center gap-2 text-ink/70"><Mail className="h-4 w-4" aria-hidden /><span dir="ltr" className="truncate">{c.profile.email}</span></p>}
                {isOut && <p className="text-coral">السبب: {c.out_reason || '—'} · {new Date(c.status_changed_at).toLocaleString('ar-EG')}</p>}
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center text-sm">
                {[['حاليًا معاه', c.stats.active], ['النهاردة', c.stats.today], ['آخر 30 يوم', c.stats.month]].map(([t, v]) => (
                  <div key={t} className="rounded-xl bg-ink/5 p-2"><p className="font-bold tabular-nums">{Number(v).toLocaleString('ar-EG')}</p><p className="text-xs text-ink/60">{t}</p></div>
                ))}
              </div>
              {(() => {
                const list = c.delivered || [];
                const isOpen = open === c.id;
                return (
                  <div className="mt-3">
                    <button type="button" onClick={() => setOpen(isOpen ? null : c.id)} aria-expanded={isOpen}
                      className="inline-flex min-h-[44px] w-full items-center justify-between gap-2 rounded-xl bg-emerald-50 px-3 text-sm font-semibold text-emerald-900 ring-1 ring-emerald-200">
                      <span className="inline-flex items-center gap-2"><PackageCheck className="h-4 w-4" aria-hidden /> الطلبات اللي سلّمها ({list.length.toLocaleString('ar-EG')})</span>
                      <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} aria-hidden />
                    </button>
                    {isOpen && (
                      <ul className="mt-2 max-h-[420px] space-y-2 overflow-y-auto">
                        {list.length === 0 && <li className="rounded-xl bg-ink/5 p-3 text-center text-sm text-ink/60">مفيش طلبات متسلّمة لسه.</li>}
                        {list.map((o) => <DeliveredOrder key={o.id} o={o} />)}
                      </ul>
                    )}
                  </div>
                );
              })()}
              <button onClick={() => setStatus(c, isOut ? 'available' : 'out_of_service')} disabled={busy === c.id}
                className={`mt-3 inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl text-sm font-semibold ${isOut ? 'bg-[#0F7B4F] text-white' : 'text-coral ring-1 ring-coral/40 hover:bg-coral/10'}`}>
                {busy === c.id ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : isOut ? <Power className="h-4 w-4" aria-hidden /> : <Ban className="h-4 w-4" aria-hidden />}
                {isOut ? 'رجّعه للخدمة' : 'حوّله لخارج الخدمة'}
              </button>
            </li>
          );
        })}
      </ul>
      <p className="mt-4 flex items-center gap-2 text-xs text-ink/60"><ClipboardList className="h-4 w-4" aria-hidden /> الطلبات بتتوزع على المناديب من صفحة &quot;الطلبات&quot; (طلبات التوصيل بس).</p>
    </section>
  );
}
