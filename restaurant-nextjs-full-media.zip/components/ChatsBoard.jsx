'use client';
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Bot, UserRound, Send, ArrowRight, Search, Loader2, Radio, MessagesSquare, Headset, Power, Trash2 } from 'lucide-react';
import ConfirmDialog from '@/components/ConfirmDialog';
import { createClient } from '@/lib/supabase/client';

const sameDay = (a, b) => new Date(a).toDateString() === new Date(b).toDateString();
const fmtTime = (d) => new Date(d).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
const fmtList = (d) => (sameDay(d, Date.now()) ? fmtTime(d) : new Date(d).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' }));
const MEDIA = { image: '📷 صورة', video: '🎥 فيديو', audio: '🎤 رسالة صوتية', sticker: 'ملصق', document: '📄 ملف', location: '📍 موقع' };
const mediaLabel = (b) => { const m = /^\[(\w+)\]$/.exec(String(b || '').trim()); return m ? (MEDIA[m[1].toLowerCase()] || b) : b; };
const isLid = (p) => String(p).endsWith('@lid');
const sortChats = (l) => [...l].sort((a, b) => b.last_message_at.localeCompare(a.last_message_at));

function beep() {
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)();
    const o = c.createOscillator(); const g = c.createGain();
    o.connect(g); g.connect(c.destination);
    o.frequency.value = 660; g.gain.value = 0.06;
    o.start(); o.stop(c.currentTime + 0.2);
  } catch { /* autoplay policy: ignore */ }
}

const SENDER = {
  customer: { name: '', box: 'bg-white ring-1 ring-ink/10', align: 'justify-start' },
  ai: { name: 'المساعد الذكي', box: 'bg-mint', align: 'justify-end', Icon: Bot },
  human: { name: 'موظف', box: 'bg-ink text-white', align: 'justify-end', Icon: UserRound },
};

const EXT = {
  image: /\.(png|jpe?g|webp|gif|heic)$/i,
  video: /\.(mp4|webm|mov|3gp)$/i,
  audio: /\.(ogg|opus|mp3|m4a|aac|wav)$/i,
};
const bodyKind = (b) => { const m = /^\[(\w+)\]$/.exec(String(b || '').trim()); return m ? m[1].toLowerCase() : ''; };
// media_url = https URL (direct) or a Storage path (resolved by the server with a short-lived signed URL).
const mediaSrc = (v) => {
  const s = String(v || '').trim();
  if (!s) return '';
  if (/^https:\/\/[^\s]+$/.test(s)) return s;
  if (/^[\w./-]{1,500}$/.test(s) && !s.startsWith('/') && !s.includes('..')) return `/api/admin/chats/media?path=${encodeURIComponent(s)}`;
  return '';
};
const mediaKind = (m) => {
  const clean = String(m.media_url || '').split(/[?#]/)[0];
  for (const k of ['image', 'video', 'audio']) if (EXT[k].test(clean)) return k;
  const l = bodyKind(m.body);
  if (l === 'sticker') return 'image';
  return ['image', 'video', 'audio'].includes(l) ? l : 'file';
};

// الصورة بتظهر جوه الفقاعة. لو فشل تحميلها بنرجع لرابط "فتح المرفق".
function MsgImage({ url }) {
  const [failed, setFailed] = useState(false);
  if (failed) return <a href={url} target="_blank" rel="noopener noreferrer" className="mb-1 block text-xs underline">تعذّر عرض الصورة · فتح المرفق</a>;
  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className="mb-1 block">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={url} alt="صورة مرسلة في المحادثة" loading="lazy" onError={() => setFailed(true)}
        className="max-h-72 min-h-[96px] w-full max-w-[260px] rounded-xl bg-ink/5 object-cover" />
    </a>
  );
}

function Bubble({ m }) {
  if (m.sender === 'system') {
    return <li className="my-2 flex justify-center"><span className="rounded-full bg-saf/25 px-3 py-1 text-xs font-semibold">{m.body}</span></li>;
  }
  const s = SENDER[m.sender] || SENDER.customer;
  const Icon = s.Icon;
  const src = mediaSrc(m.media_url);
  const kind = src ? mediaKind(m) : '';
  const onlyLabel = /^\[\w+\]$/.test(String(m.body || '').trim()); // "[image]" وحدها: مفيش داعي نكررها تحت الميديا
  return (
    <li className={`flex ${s.align}`}>
      <div className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${s.box}`}>
        {s.name && <p className="mb-0.5 flex items-center gap-1 text-[11px] font-semibold opacity-70">{Icon && <Icon className="h-3 w-3" aria-hidden />}{s.name}</p>}
        {src && kind === 'image' && <MsgImage url={src} />}
        {src && kind === 'video' && <video controls preload="metadata" src={src} className="mb-1 max-h-72 w-full max-w-[260px] rounded-xl bg-ink/5" />}
        {src && kind === 'audio' && <audio controls preload="none" src={src} className="mb-1 h-10 w-56 max-w-full" />}
        {src && kind === 'file' && <a href={src} target="_blank" rel="noopener noreferrer" className="mb-1 block text-xs underline">فتح المرفق</a>}
        {m.body && !(src && kind !== 'file' && onlyLabel) && <p className="whitespace-pre-wrap break-words">{mediaLabel(m.body)}</p>}
        <p className="mt-1 text-[10px] opacity-60" dir="ltr">{fmtTime(m.created_at)}</p>
      </div>
    </li>
  );
}

export default function ChatsBoard({ initial, initialAi = true, loadError = '', isAdmin = false }) {
  const supabase = useMemo(() => createClient(), []);
  const [chats, setChats] = useState(initial);
  const [active, setActive] = useState(null); // phone
  const [messages, setMessages] = useState([]);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState('');
  const [wipeOpen, setWipeOpen] = useState(false);
  const [wipeText, setWipeText] = useState('');
  const [err, setErr] = useState(loadError);
  const [live, setLive] = useState(false);
  const [aiOn, setAiOn] = useState(initialAi); // global switch: false = human intervention, AI silent everywhere
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all');
  const activeRef = useRef(null);
  const endRef = useRef(null);
  activeRef.current = active;

  const chat = chats.find((c) => c.phone === active) || null;

  const markRead = useCallback((phone) => {
    fetch('/api/admin/chats/read', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone }) }).catch(() => {});
  }, []);

  const loadChats = useCallback(async () => {
    const { data } = await supabase.from('wa_chats').select('*').order('last_message_at', { ascending: false }).limit(200);
    if (data) setChats(data);
  }, [supabase]);

  const loadMessages = useCallback(async (phone, quiet) => {
    if (!quiet) setLoadingMsgs(true);
    const { data, error } = await supabase.from('wa_messages').select('*').eq('phone', phone).order('id', { ascending: false }).limit(500);
    if (phone !== activeRef.current) return;
    if (!error && data) setMessages(data.reverse());
    setLoadingMsgs(false);
  }, [supabase]);

  function open(phone) {
    setActive(phone); setMessages([]); setText(''); setErr('');
    loadMessages(phone);
    markRead(phone);
    setChats((l) => l.map((c) => (c.phone === phone ? { ...c, unread_count: 0 } : c)));
  }

  // realtime + slow polling fallback so every message shows even if the socket drops
  useEffect(() => {
    const ch = supabase.channel('wa-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wa_chats' }, (p) => {
        const row = p.new;
        if (!row?.phone) return;
        const isOpen = row.phone === activeRef.current;
        setChats((l) => sortChats([{ ...row, unread_count: isOpen ? 0 : row.unread_count }, ...l.filter((c) => c.phone !== row.phone)]));
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'wa_messages' }, (p) => {
        const m = p.new;
        if (m.sender === 'customer') beep();
        if (m.phone !== activeRef.current) return;
        setMessages((l) => (l.some((x) => x.id === m.id) ? l : [...l, m]));
        if (m.sender === 'customer') markRead(m.phone);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'wa_messages' }, (p) => {
        const m = p.new;
        if (!m?.id || m.phone !== activeRef.current) return;
        setMessages((l) => l.map((x) => (x.id === m.id ? { ...x, ...m } : x)));
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wa_settings' }, (p) => {
        if (typeof p.new?.ai_enabled === 'boolean') setAiOn(p.new.ai_enabled);
      })
      .subscribe((s) => setLive(s === 'SUBSCRIBED'));
    const t = setInterval(() => {
      loadChats();
      if (activeRef.current) loadMessages(activeRef.current, true);
    }, 10000);
    return () => { clearInterval(t); supabase.removeChannel(ch); };
  }, [supabase, loadChats, loadMessages, markRead]);

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [messages, active]);

  async function setMode(mode) {
    if (!chat) return;
    setBusy('mode'); setErr('');
    const res = await fetch('/api/admin/chats/mode', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone: chat.phone, mode }),
    });
    if (!res.ok) { const j = await res.json().catch(() => ({})); setErr(j.error || 'تعذّر تغيير الوضع'); }
    else {
      setChats((l) => l.map((c) => (c.phone === chat.phone ? { ...c, mode } : c)));
      loadMessages(chat.phone, true);
    }
    setBusy('');
  }

  async function toggleGlobal() {
    const next = !aiOn;
    setBusy('global'); setErr('');
    const res = await fetch('/api/admin/chats/global', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ai: next }),
    });
    if (!res.ok) { const j = await res.json().catch(() => ({})); setErr(j.error || 'تعذّر تغيير الوضع'); }
    else setAiOn(next);
    setBusy('');
  }

  async function wipeAll() {
    if (busy === 'wipe' || wipeText.trim() !== 'مسح') return;
    setBusy('wipe'); setErr('');
    const res = await fetch('/api/admin/wipe-all', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirm: wipeText.trim() }),
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) setErr(j.error || 'تعذّر المسح');
    else { setChats([]); setActive(null); setMessages([]); setWipeOpen(false); setWipeText(''); }
    setBusy('');
  }

  async function send() {
    const body = text.trim();
    if (!chat || !body || busy) return;
    setBusy('send'); setErr('');
    const res = await fetch('/api/admin/chats/send', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone: chat.phone, text: body }),
    });
    if (!res.ok) { const j = await res.json().catch(() => ({})); setErr(j.error || 'تعذّر الإرسال'); }
    else { setText(''); loadMessages(chat.phone, true); }
    setBusy('');
  }

  const shown = chats.filter((c) => {
    if (filter === 'human' && c.mode !== 'human') return false;
    if (filter === 'unread' && !(c.unread_count > 0)) return false;
    const s = q.trim().toLowerCase();
    return !s || (c.customer_name || '').toLowerCase().includes(s) || c.phone.includes(s.replace(/\s/g, ''));
  });
  const humanCount = chats.filter((c) => c.mode === 'human').length;
  const canWrite = chat && (chat.mode === 'human' || !aiOn);
  const unreadTotal = chats.reduce((n, c) => n + (c.unread_count || 0), 0);

  return (
    <section>
      <div className="mb-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
        <span className="flex items-center gap-2">
          <Radio className={`h-4 w-4 ${live ? 'text-emerald-600' : 'text-ink/40'}`} aria-hidden />
          <span className={live ? 'text-emerald-700' : 'text-ink/50'}>{live ? 'تحديث لحظي شغال' : 'جاري الاتصال…'}</span>
        </span>
        <span className="text-ink/60">{chats.length} محادثة · {humanCount} بتدخّل بشري · {unreadTotal} رسالة جديدة</span>
        <button onClick={toggleGlobal} disabled={busy === 'global'} aria-pressed={!aiOn}
          className={`ms-auto flex min-h-[44px] items-center gap-2 rounded-xl px-4 text-sm font-bold text-white disabled:opacity-60 ${aiOn ? 'bg-red-600 hover:bg-red-700' : 'bg-red-700 ring-2 ring-red-300'}`}>
          {busy === 'global' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : aiOn ? <Headset className="h-4 w-4" aria-hidden /> : <Power className="h-4 w-4" aria-hidden />}
          {aiOn ? 'تدخّل بشري' : 'تدخّل بشري شغال · شغّل المساعد الذكي'}
        </button>
        {isAdmin && (
          <button type="button" onClick={() => { setWipeText(''); setWipeOpen(true); }}
            className="flex min-h-[44px] items-center gap-2 rounded-xl border-2 border-red-600 px-4 text-sm font-bold text-red-700 hover:bg-red-50">
            <Trash2 className="h-4 w-4" aria-hidden /> مسح كل حاجة
          </button>
        )}
      </div>
      {err && <p role="alert" className="mb-3 rounded-xl bg-coral/10 p-3 text-sm text-coral">{err}</p>}

      <ConfirmDialog
        open={wipeOpen}
        title="مسح كل رسائل وملفات واتساب؟"
        description="هيتمسح كل المحادثات والرسائل وجهات الاتصال والملفات نهائيًا، ومفيش رجوع."
        confirmLabel="امسح كل حاجة"
        loading={busy === 'wipe'}
        onConfirm={wipeAll}
        onCancel={() => busy !== 'wipe' && setWipeOpen(false)}
      >
        <label className="block text-sm font-semibold">اكتب كلمة <b>مسح</b> للتأكيد
          <input value={wipeText} onChange={(e) => setWipeText(e.target.value)} dir="rtl"
            className="mt-1 w-full rounded-xl border border-ink/20 px-3 py-2" />
        </label>
      </ConfirmDialog>

      <div className="grid h-[calc(100vh-9rem)] min-h-[480px] overflow-hidden rounded-2xl bg-white ring-1 ring-ink/10 lg:grid-cols-[320px_1fr]">
        {/* conversations */}
        <aside className={`${active ? 'hidden lg:flex' : 'flex'} min-h-0 flex-col border-ink/10 lg:border-l`}>
          <div className="space-y-2 border-b border-ink/10 p-3">
            <label className="relative block">
              <span className="sr-only">بحث</span>
              <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" aria-hidden />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث بالاسم أو الرقم"
                className="min-h-[44px] w-full rounded-xl border border-ink/20 bg-white pr-9 pl-3 text-sm" />
            </label>
            <div className="flex gap-2">
              {[['all', 'الكل'], ['human', 'تدخّل بشري'], ['unread', 'غير مقروء']].map(([k, t]) => (
                <button key={k} onClick={() => setFilter(k)}
                  className={`min-h-[36px] rounded-full px-3 text-xs font-semibold ${filter === k ? 'bg-ink text-white' : 'bg-white ring-1 ring-ink/15'}`}>{t}</button>
              ))}
            </div>
          </div>
          <ul className="min-h-0 flex-1 divide-y divide-ink/10 overflow-y-auto">
            {shown.length === 0 && <li className="p-8 text-center text-sm text-ink/60">مفيش محادثات.</li>}
            {shown.map((c) => (
              <li key={c.phone}>
                <button onClick={() => open(c.phone)} aria-current={c.phone === active ? 'true' : undefined}
                  className={`flex min-h-[64px] w-full items-start gap-3 px-3 py-3 text-right transition ${c.phone === active ? 'bg-mint' : 'hover:bg-ink/5'}`}>
                  <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full ${c.mode === 'human' ? 'bg-saf text-ink' : 'bg-ink text-white'}`}>
                    {c.mode === 'human' ? <Headset className="h-5 w-5" aria-hidden /> : <Bot className="h-5 w-5" aria-hidden />}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-bold">{c.customer_name || 'عميل'}</span>
                      <span className="shrink-0 text-[11px] text-ink/50">{fmtList(c.last_message_at)}</span>
                    </span>
                    <span className="block text-xs text-ink/50" dir="ltr" style={{ textAlign: 'right' }}>{c.phone}</span>
                    <span className="mt-0.5 flex items-center justify-between gap-2">
                      <span className="truncate text-xs text-ink/70">{c.last_sender === 'ai' ? 'المساعد: ' : c.last_sender === 'human' ? 'موظف: ' : ''}{mediaLabel(c.last_message)}</span>
                      {c.unread_count > 0 && <span className="grid h-5 min-w-5 shrink-0 place-items-center rounded-full bg-coral px-1 text-[11px] font-bold text-white">{c.unread_count}</span>}
                    </span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </aside>

        {/* thread */}
        <div className={`${active ? 'flex' : 'hidden lg:flex'} min-h-0 min-w-0 flex-col`}>
          {!chat ? (
            <div className="m-auto p-8 text-center text-ink/50">
              <MessagesSquare className="mx-auto mb-3 h-10 w-10" aria-hidden />
              <p>اختار محادثة من القايمة</p>
            </div>
          ) : (
            <>
              <header className="flex flex-wrap items-center gap-2 border-b border-ink/10 p-3">
                <button onClick={() => setActive(null)} aria-label="رجوع للمحادثات" className="grid h-11 w-11 place-items-center rounded-xl ring-1 ring-ink/15 lg:hidden">
                  <ArrowRight className="h-5 w-5" aria-hidden />
                </button>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-bold">{chat.customer_name || 'عميل'}</p>
                  {isLid(chat.phone)
                    ? <p dir="ltr" className="text-right text-xs text-ink/60" title="واتساب مخفي الرقم: ده معرّف مش رقم تليفون">{chat.phone}</p>
                    : <a href={`tel:${chat.phone}`} dir="ltr" className="block text-right text-xs text-ink/60">{chat.phone}</a>}
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-semibold ${chat.mode === 'human' ? 'bg-saf/25' : 'bg-mint'}`}>
                  {!aiOn ? 'تدخّل بشري · المساعد متوقف' : chat.mode === 'human' ? 'تدخّل بشري · المساعد متوقف' : 'المساعد الذكي بيرد'}
                </span>
                {!aiOn ? null : chat.mode === 'ai' ? (
                  <button onClick={() => setMode('human')} disabled={busy === 'mode'}
                    className="flex min-h-[44px] items-center gap-2 rounded-xl bg-saf px-4 text-sm font-bold text-ink disabled:opacity-60">
                    {busy === 'mode' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Headset className="h-4 w-4" aria-hidden />} تدخّل بشري
                  </button>
                ) : (
                  <button onClick={() => setMode('ai')} disabled={busy === 'mode'}
                    className="flex min-h-[44px] items-center gap-2 rounded-xl bg-ink px-4 text-sm font-bold text-white disabled:opacity-60">
                    {busy === 'mode' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Bot className="h-4 w-4" aria-hidden />} المساعد الذكي
                  </button>
                )}
              </header>

              <div className="min-h-0 flex-1 overflow-y-auto bg-[#F6F7F4] p-3">
                {loadingMsgs && <p className="py-6 text-center text-sm text-ink/50"><Loader2 className="mx-auto h-5 w-5 animate-spin" aria-hidden /></p>}
                <ul className="space-y-2">
                  {messages.map((m, i) => (
                    <Fragment key={m.id}>
                      {(i === 0 || !sameDay(messages[i - 1].created_at, m.created_at)) && (
                        <li className="my-2 text-center text-[11px] text-ink/50">{new Date(m.created_at).toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' })}</li>
                      )}
                      <Bubble m={m} />
                    </Fragment>
                  ))}
                </ul>
                <div ref={endRef} />
              </div>

              <footer className="border-t border-ink/10 p-3">
                {canWrite ? (
                  <div className="flex items-end gap-2">
                    <label className="flex-1">
                      <span className="sr-only">رسالتك للعميل</span>
                      <textarea value={text} onChange={(e) => setText(e.target.value)} rows={2} maxLength={1000} placeholder="اكتب ردك للعميل… (Enter للإرسال)"
                        onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(); } }}
                        className="w-full resize-none rounded-xl border border-ink/20 bg-white p-3 text-sm" />
                    </label>
                    <button onClick={send} disabled={!text.trim() || busy === 'send'} aria-label="إرسال"
                      className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-ink text-white disabled:opacity-50">
                      {busy === 'send' ? <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> : <Send className="h-5 w-5 -scale-x-100" aria-hidden />}
                    </button>
                  </div>
                ) : (
                  <p className="rounded-xl bg-mint p-3 text-center text-sm">المساعد الذكي هو اللي بيرد دلوقتي. اضغط «تدخّل بشري» لو عايز تكتب للعميل بنفسك.</p>
                )}
              </footer>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
