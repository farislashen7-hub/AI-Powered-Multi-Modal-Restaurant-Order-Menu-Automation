'use client';
import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import { Megaphone, Send, Pencil, Trash2, Loader2, Plus, Eye, EyeOff, Users, CheckCircle2, ImageOff, X } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import ConfirmDialog from '@/components/ConfirmDialog';
import WhatsAppPreview from '@/components/WhatsAppPreview';
import { buildOfferMessage, discountPct } from '@/lib/offerMessage';
import OfferCardPreview from '@/components/OfferCardPreview';
import { OFFER_THEMES, OFFER_LAYOUTS, CUSTOM_DEFAULT, HEX } from '@/lib/offerStyle';

const BUCKET = 'menu-images';
const MAX = 3 * 1024 * 1024;
const TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const blank = { id: null, title: '', description: '', price: '', old_price: '', valid_until: '', active: true, image_url: null, image_path: null, card_theme: 'classic', card_layout: 'card', badge_text: '', wa_message: '', ...CUSTOM_DEFAULT };
const toForm = (o) => ({ id: o.id, title: o.title, description: o.description || '', price: o.price ?? '', old_price: o.old_price ?? '', valid_until: o.valid_until || '', active: o.active, image_url: o.image_url || null, image_path: o.image_path || null, card_theme: o.card_theme || 'classic', card_layout: o.card_layout || 'card', badge_text: o.badge_text || '', wa_message: o.wa_message || '', card_bg: o.card_bg || CUSTOM_DEFAULT.card_bg, card_fg: o.card_fg || CUSTOM_DEFAULT.card_fg, card_accent: o.card_accent || CUSTOM_DEFAULT.card_accent });
const inp = 'min-h-[44px] w-full min-w-0 rounded-xl border border-ink/20 bg-white px-3';
const money = (n) => `${Number(n).toLocaleString('ar-EG')} ج.م`;
const toNum = (v) => (v === '' || v == null ? null : Math.max(0, Number(v)));

// resize (max 1280px) + flatten onto white + JPEG: same bytes in preview, storage and WhatsApp
async function toJpeg(file) {
  const bmp = await createImageBitmap(file);
  const k = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
  const x = c.getContext('2d');
  x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
  x.drawImage(bmp, 0, 0, c.width, c.height);
  bmp.close?.();
  const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.85));
  if (!blob) throw new Error('تعذّر معالجة الصورة');
  return blob;
}

// module level: defining this inside the component remounts every input on each keystroke (focus lost)
const L = ({ t, children, cls = '' }) => (<label className={`block min-w-0 ${cls}`}><span className="mb-1 block text-sm font-medium">{t}</span>{children}</label>);

export default function OffersManager({ initial, loadError, siteName, siteUrl, recipientCount }) {
  const supabase = createClient();
  const [offers, setOffers] = useState(initial);
  const [f, setF] = useState(blank);
  const [busy, setBusy] = useState(null);
  const [msg, setMsg] = useState({ type: '', text: loadError });
  const [confirm, setConfirm] = useState(null); // { kind: 'send'|'delete', offer }
  const [file, setFile] = useState(null); // newly picked image
  const [removeImg, setRemoveImg] = useState(false);
  const preview = useMemo(() => (file ? URL.createObjectURL(file) : null), [file]);
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);
  const shownImg = removeImg ? null : preview || f.image_url;

  const autoMessage = useMemo(
    () => buildOfferMessage(f, { siteName, siteUrl: siteUrl || (typeof window !== 'undefined' ? window.location.origin : '') }),
    [f, siteName, siteUrl]
  );
  const message = f.wa_message.trim() ? f.wa_message : autoMessage; // custom text overrides auto
  const time = new Date().toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit' });
  const pct = discountPct(f);
  const priceWarn = f.old_price !== '' && f.price !== '' && Number(f.old_price) <= Number(f.price);
  const editing = Boolean(f.id);

  async function upload(raw) {
    if (!TYPES.includes(raw.type)) throw new Error('الصورة لازم JPG أو PNG أو WebP');
    if (raw.size > MAX) throw new Error('حجم الصورة أقصاه 3MB');
    const fl = await toJpeg(raw); // WhatsApp caption works on JPEG; WebP can arrive as a sticker (no caption)
    const path = `offers/${crypto.randomUUID()}.jpg`;
    const { error } = await supabase.storage.from(BUCKET).upload(path, fl, { contentType: 'image/jpeg', cacheControl: '31536000' });
    if (error) throw error;
    return { image_path: path, image_url: supabase.storage.from(BUCKET).getPublicUrl(path).data.publicUrl };
  }

  async function save(e) {
    e.preventDefault();
    if (f.title.trim().length < 2) return setMsg({ type: 'error', text: 'اكتب عنوان العرض' });
    setBusy('save'); setMsg({ type: '', text: '' });
    let img = {};
    try {
      if (file) img = await upload(file);
      else if (removeImg) img = { image_url: null, image_path: null };
    } catch (err) {
      setBusy(null);
      return setMsg({ type: 'error', text: err.message || 'تعذّر رفع الصورة' });
    }
    const row = {
      title: f.title.trim().slice(0, 80),
      description: f.description.trim().slice(0, 500) || null,
      price: toNum(f.price), old_price: toNum(f.old_price),
      valid_until: f.valid_until || null, active: f.active,
      card_theme: f.card_theme, card_layout: f.card_layout, badge_text: f.badge_text.trim().slice(0, 20) || null,
      wa_message: f.wa_message.trim().slice(0, 1000) || null,
      card_bg: f.card_theme === 'custom' && HEX.test(f.card_bg) ? f.card_bg : null,
      card_fg: f.card_theme === 'custom' && HEX.test(f.card_fg) ? f.card_fg : null,
      card_accent: f.card_theme === 'custom' && HEX.test(f.card_accent) ? f.card_accent : null,
      ...img,
    };
    const q = editing
      ? supabase.from('offers').update(row).eq('id', f.id).select().single()
      : supabase.from('offers').insert(row).select().single();
    const { data, error } = await q;
    setBusy(null);
    if (error) {
      if (img.image_path) await supabase.storage.from(BUCKET).remove([img.image_path]); // no orphan file
      return setMsg({ type: 'error', text: 'تعذّر حفظ العرض. لو بتضيف صورة اتأكد إنك شغّلت migration_12 و migration_16_offer_style.sql و migration_17_offer_custom_colors.sql و migration_18_offer_wa_message.sql' });
    }
    if (editing && f.image_path && 'image_path' in img) await supabase.storage.from(BUCKET).remove([f.image_path]); // old image replaced/removed
    setOffers((l) => (editing ? l.map((o) => (o.id === data.id ? data : o)) : [data, ...l]));
    setF(blank); setFile(null); setRemoveImg(false);
    setMsg({ type: 'ok', text: editing ? 'اتعدّل العرض' : 'اتضاف العرض. دوس "إرسال على واتساب" من القائمة تحت.' });
  }

  async function toggle(o) {
    setBusy(o.id);
    const { error } = await supabase.from('offers').update({ active: !o.active }).eq('id', o.id);
    if (!error) setOffers((l) => l.map((x) => (x.id === o.id ? { ...x, active: !o.active } : x)));
    setBusy(null);
  }

  async function runConfirm() {
    const { kind, offer } = confirm;
    setBusy(offer.id); setMsg({ type: '', text: '' });
    if (kind === 'delete') {
      const { error } = await supabase.from('offers').delete().eq('id', offer.id);
      if (error) setMsg({ type: 'error', text: 'تعذّر الحذف' });
      else {
        if (offer.image_path) await supabase.storage.from(BUCKET).remove([offer.image_path]);
        setOffers((l) => l.filter((x) => x.id !== offer.id));
        if (f.id === offer.id) { setF(blank); setFile(null); setRemoveImg(false); }
      }
    } else {
      const res = await fetch(`/api/offers/${offer.id}/send`, { method: 'POST' });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) setMsg({ type: 'error', text: j.error || 'تعذّر الإرسال' });
      else {
        setOffers((l) => l.map((x) => (x.id === offer.id ? { ...x, last_sent_at: new Date().toISOString(), sent_count: j.count } : x)));
        setMsg({ type: 'ok', text: `اتبعت العرض لـ ${j.count.toLocaleString('ar-EG')} عميل (n8n بيبعتهم واحد واحد).` });
      }
    }
    setBusy(null); setConfirm(null);
  }

  return (
    <section>
      <h1 className="flex items-center gap-2 text-xl font-bold"><Megaphone className="h-5 w-5" aria-hidden /> العروض</h1>
      {msg.text && (
        <p role={msg.type === 'error' ? 'alert' : 'status'} className={`mt-3 rounded-xl p-3 text-sm ${msg.type === 'ok' ? 'bg-mint text-ink' : 'bg-coral/10 text-coral'}`}>{msg.text}</p>
      )}

      <div className="mt-5 grid items-start gap-6 lg:grid-cols-2">
        {/* RTL: first column = right side (form), second = left side (WhatsApp preview) */}
        <div className="space-y-6">
          <form onSubmit={save} className="space-y-3 rounded-2xl bg-white p-4 ring-1 ring-ink/10">
            <h2 className="font-bold">{editing ? 'تعديل العرض' : 'عرض جديد'}</h2>
            <div>
              <span className="mb-1 block text-sm font-medium">صورة العرض (اختياري)</span>
              <div className="flex items-center gap-3">
                <span className="relative grid h-20 w-24 shrink-0 place-items-center overflow-hidden rounded-xl bg-mint">
                  {shownImg
                    ? <Image src={shownImg} alt="" fill sizes="96px" unoptimized={Boolean(preview)} className="object-cover" />
                    : <ImageOff className="h-6 w-6 text-ink/30" aria-hidden />}
                </span>
                <div className="min-w-0 flex-1 space-y-2">
                  <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => { setFile(e.target.files?.[0] || null); setRemoveImg(false); }}
                    className={`${inp} py-2 text-sm file:me-3 file:rounded-lg file:border-0 file:bg-mint file:px-3 file:py-1.5 file:text-sm file:font-semibold`} />
                  {shownImg && (
                    <button type="button" onClick={() => { setFile(null); setRemoveImg(true); }} className="inline-flex items-center gap-1 text-sm font-semibold text-coral">
                      <X className="h-4 w-4" aria-hidden /> شيل الصورة
                    </button>
                  )}
                </div>
              </div>
              <p className="mt-1 text-xs text-ink/60">JPG أو PNG أو WebP، أقصى حجم 3MB.</p>
            </div>
            <L t="عنوان العرض"><input required maxLength={80} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} className={inp} placeholder="مثال: عرض العيلة" /></L>
            <L t="تفاصيل العرض">
              <textarea maxLength={500} rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} className="w-full rounded-xl border border-ink/20 bg-white px-3 py-2" placeholder="مثال: ٢ شاورما فراخ + بطاطس + ٢ كولا" />
            </L>
            <div className="grid gap-3 sm:grid-cols-2">
              <L t="سعر العرض (ج.م)"><input type="number" min="0" step="0.5" inputMode="decimal" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} className={inp} /></L>
              <L t="السعر قبل الخصم (اختياري)"><input type="number" min="0" step="0.5" inputMode="decimal" value={f.old_price} onChange={(e) => setF({ ...f, old_price: e.target.value })} className={inp} /></L>
            </div>
            {priceWarn && <p role="alert" className="text-sm text-coral">السعر قبل الخصم لازم يكون أكبر من سعر العرض.</p>}
            {pct > 0 && <p className="text-sm text-emerald-700">نسبة الخصم: {pct.toLocaleString('ar-EG')}%</p>}
            <L t="ساري لحد (اختياري)"><input type="date" value={f.valid_until} onChange={(e) => setF({ ...f, valid_until: e.target.value })} className={inp} /></L>
            <fieldset className="space-y-3 rounded-xl bg-ink/5 p-3">
              <legend className="px-1 text-sm font-bold">شكل العرض</legend>
              <div>
                <span className="mb-1 block text-sm font-medium">الألوان</span>
                <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="ألوان العرض">
                  {Object.entries(OFFER_THEMES).map(([k, t]) => (
                    <button key={k} type="button" role="radio" aria-checked={f.card_theme === k} onClick={() => setF({ ...f, card_theme: k })}
                      className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-white px-3 text-sm font-semibold ${f.card_theme === k ? 'ring-2 ring-ink' : 'ring-1 ring-ink/20'}`}>
                      <span className="h-5 w-5 rounded-full ring-1 ring-ink/20" style={{ background: `linear-gradient(135deg, ${t.bg} 50%, ${t.accent} 50%)` }} aria-hidden /> {t.label}
                    </button>
                  ))}
                  <button type="button" role="radio" aria-checked={f.card_theme === 'custom'} onClick={() => setF({ ...f, card_theme: 'custom' })}
                    className={`inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-white px-3 text-sm font-semibold ${f.card_theme === 'custom' ? 'ring-2 ring-ink' : 'ring-1 ring-ink/20'}`}>
                    <span className="h-5 w-5 rounded-full ring-1 ring-ink/20" style={{ background: 'conic-gradient(#E4572E, #E8A317, #2E9E6B, #2B6CE4, #8B3FD9, #E4572E)' }} aria-hidden /> ألوان حرّة
                  </button>
                </div>
                {f.card_theme === 'custom' && (
                  <div className="mt-3 grid gap-3 sm:grid-cols-3">
                    {[['card_bg', 'لون الخلفية'], ['card_fg', 'لون الكلام'], ['card_accent', 'لون الزرار والشارة']].map(([k, label]) => (
                      <label key={k} className="flex min-w-0 items-center gap-2 rounded-xl bg-white p-2 ring-1 ring-ink/20">
                        <input type="color" value={HEX.test(f[k]) ? f[k] : CUSTOM_DEFAULT[k]} onChange={(e) => setF({ ...f, [k]: e.target.value.toUpperCase() })} className="h-10 w-12 shrink-0 cursor-pointer rounded-lg border-0 bg-transparent p-0" aria-label={label} />
                        <span className="min-w-0 text-sm font-medium">{label}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <span className="mb-1 block text-sm font-medium">التخطيط</span>
                <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="تخطيط العرض">
                  {Object.entries(OFFER_LAYOUTS).map(([k, label]) => (
                    <button key={k} type="button" role="radio" aria-checked={f.card_layout === k} onClick={() => setF({ ...f, card_layout: k })}
                      className={`min-h-[44px] rounded-xl bg-white px-4 text-sm font-semibold ${f.card_layout === k ? 'ring-2 ring-ink' : 'ring-1 ring-ink/20'}`}>{label}</button>
                  ))}
                </div>
              </div>
              <L t="كلمة الشارة (اختياري)"><input maxLength={20} value={f.badge_text} onChange={(e) => setF({ ...f, badge_text: e.target.value })} className={inp} placeholder="عرض" /></L>
            </fieldset>
            <fieldset className="space-y-2 rounded-xl bg-ink/5 p-3">
              <legend className="px-1 text-sm font-bold">رسالة واتساب</legend>
              <textarea maxLength={1000} rows={9} dir="rtl" value={f.wa_message} onChange={(e) => setF({ ...f, wa_message: e.target.value })}
                className="w-full rounded-xl border border-ink/20 bg-white px-3 py-2 text-sm" placeholder="سيبها فاضية والرسالة هتتكتب أوتوماتيك من بيانات العرض" />
              <div className="flex flex-wrap items-center gap-2">
                <button type="button" onClick={() => setF({ ...f, wa_message: autoMessage })} className="min-h-[44px] rounded-xl bg-white px-4 text-sm font-semibold ring-1 ring-ink/20">املا بالنص التلقائي وعدّل عليه</button>
                {f.wa_message && <button type="button" onClick={() => setF({ ...f, wa_message: '' })} className="min-h-[44px] rounded-xl px-4 text-sm font-semibold text-coral ring-1 ring-coral/30">رجّع تلقائي</button>}
              </div>
              <p className="text-xs text-ink/60">*غامق* و ~مشطوب~ شغالين زي واتساب. {f.wa_message.trim() ? 'الرسالة دي هي اللي هتتبعت زي ما هي.' : 'دلوقتي الرسالة تلقائية.'}</p>
            </fieldset>
            <label className="flex min-h-[44px] items-center gap-2">
              <input type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} className="h-5 w-5" />
              <span className="text-sm font-medium">العرض شغال</span>
            </label>
            <div className="flex flex-wrap gap-2">
              <button disabled={busy === 'save'} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-ink px-5 font-semibold text-white disabled:opacity-60">
                {busy === 'save' ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Plus className="h-4 w-4" aria-hidden />} {editing ? 'حفظ التعديل' : 'إضافة العرض'}
              </button>
              {editing && <button type="button" onClick={() => { setF(blank); setFile(null); setRemoveImg(false); }} className="min-h-[44px] rounded-xl px-5 font-semibold ring-1 ring-ink/20">إلغاء</button>}
            </div>
          </form>

          <div>
            <h2 className="mb-2 font-bold">العروض المضافة</h2>
            {offers.length === 0 && <p className="rounded-2xl bg-white p-6 text-center text-sm text-ink/60 ring-1 ring-ink/10">مفيش عروض لسه.</p>}
            <ul className="space-y-3">
              {offers.map((o) => {
                const expired = o.valid_until && o.valid_until < new Date().toISOString().slice(0, 10);
                return (
                  <li key={o.id} className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      {o.image_url && <span className="relative h-14 w-16 shrink-0 overflow-hidden rounded-lg bg-mint"><Image src={o.image_url} alt="" fill sizes="64px" className="object-cover" /></span>}
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-bold">{o.title}</p>
                        <p className="text-sm text-ink/60">
                          {o.price != null && <span className="font-semibold text-ink">{money(o.price)}</span>}
                          {o.old_price != null && o.price != null && <s className="ms-2">{money(o.old_price)}</s>}
                        </p>
                      </div>
                      <span className={`rounded-full px-3 py-1 text-xs font-semibold ${expired ? 'bg-ink/10 text-ink/70' : o.active ? 'bg-emerald-100 text-emerald-900' : 'bg-coral/15 text-coral'}`}>
                        {expired ? 'منتهي' : o.active ? 'شغال' : 'متوقف'}
                      </span>
                    </div>
                    {o.last_sent_at && (
                      <p className="mt-2 flex items-center gap-1 text-xs text-ink/60"><CheckCircle2 className="h-4 w-4 text-emerald-600" aria-hidden />
                        اتبعت لـ {Number(o.sent_count).toLocaleString('ar-EG')} عميل · {new Date(o.last_sent_at).toLocaleString('ar-EG')}
                      </p>
                    )}
                    <div className="mt-3 flex flex-wrap gap-2">
                      <button onClick={() => setConfirm({ kind: 'send', offer: o })} disabled={busy === o.id || !o.active || expired}
                        className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#0F7B4F] px-4 text-sm font-semibold text-white disabled:opacity-50">
                        {busy === o.id ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Send className="h-4 w-4" aria-hidden />} إرسال على واتساب
                      </button>
                      <button onClick={() => { setFile(null); setRemoveImg(false); setF(toForm(o)); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                        className="inline-flex min-h-[44px] items-center gap-2 rounded-xl px-4 text-sm font-semibold ring-1 ring-ink/20"><Pencil className="h-4 w-4" aria-hidden /> تعديل</button>
                      <button onClick={() => toggle(o)} disabled={busy === o.id} className="inline-flex min-h-[44px] items-center gap-2 rounded-xl px-4 text-sm font-semibold ring-1 ring-ink/20">
                        {o.active ? <><EyeOff className="h-4 w-4" aria-hidden /> إيقاف</> : <><Eye className="h-4 w-4" aria-hidden /> تفعيل</>}
                      </button>
                      <button onClick={() => setConfirm({ kind: 'delete', offer: o })} aria-label={`حذف ${o.title}`} className="grid h-11 w-11 place-items-center rounded-xl text-coral ring-1 ring-coral/30 hover:bg-coral/10"><Trash2 className="h-4 w-4" aria-hidden /></button>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <aside className="lg:sticky lg:top-6">
          <p className="mb-2 text-sm font-semibold">شكل العرض في الموقع</p>
          <div className="mb-5"><OfferCardPreview offer={f} image={shownImg} pct={pct} unoptimized={Boolean(preview)} /></div>
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold"><Users className="h-4 w-4" aria-hidden /> هيوصل لـ {recipientCount.toLocaleString('ar-EG')} عميل سابق</p>
          <WhatsAppPreview message={message} sender={siteName} time={time} image={shownImg} />
          <p className="mt-2 text-xs text-ink/60">المعاينة بتتحدث وإنت بتكتب. الشكل النهائي على موبايل العميل ممكن يختلف شوية حسب نسخة واتساب.</p>
        </aside>
      </div>

      <ConfirmDialog
        open={Boolean(confirm)}
        tone={confirm?.kind === 'send' ? 'success' : 'danger'}
        title={confirm?.kind === 'send' ? `إرسال "${confirm?.offer.title}"؟` : `حذف "${confirm?.offer.title}"؟`}
        description={confirm?.kind === 'send' ? `هيتبعت لـ ${recipientCount.toLocaleString('ar-EG')} عميل على واتساب. مينفعش يتراجع.` : 'العرض هيتمسح نهائي.'}
        confirmLabel={confirm?.kind === 'send' ? 'ابعت' : 'احذف'}
        loading={Boolean(confirm) && busy === confirm.offer.id}
        onConfirm={runConfirm}
        onCancel={() => setConfirm(null)}
      />
    </section>
  );
}
