// Presentational only (no hooks): used in the checkout modal and on /invoice/[id].
const money = (n) => `${Number(n).toLocaleString('ar-EG')} ج.م`;
const STATUS = { pending: 'قيد الانتظار', preparing: 'بيتحضّر', ready: 'جاهز', delivered: 'اتسلّم', cancelled: 'ملغي' };

export default function InvoiceView({ order, info }) {
  const items = order.order_items || [];
  const itemsSum = items.reduce((s, it) => s + it.qty * Number(it.unit_price), 0);
  const extrasSum = items.reduce((s, it) => s + it.qty * Number(it.extras_total || 0), 0);
  const fee = order.order_type === 'pickup' ? 0 : Number(order.delivery_fee || 0);
  const when = new Date(order.created_at).toLocaleString('ar-EG', { timeZone: 'Africa/Cairo', dateStyle: 'medium', timeStyle: 'short' });
  return (
    <article className="rounded-2xl bg-white p-5 ring-1 ring-ink/10 print:rounded-none print:ring-0" aria-label="الفاتورة">
      <header className="border-b border-dashed border-ink/20 pb-3 text-center">
        <p className="text-lg font-bold">{info?.name}</p>
        {info?.phone && <p className="text-xs text-ink/60" dir="ltr">{info.phone}</p>}
        <p className="mt-2 font-semibold">فاتورة · كود الطلب {order.order_no ? `#${order.order_no}` : `#${String(order.id).slice(0, 8).toUpperCase()}`}</p>
      </header>

      <dl className="my-3 space-y-1 text-sm">
        <div className="flex justify-between gap-3"><dt className="text-ink/60">الاسم</dt><dd>{order.customer_name}</dd></div>
        <div className="flex justify-between gap-3"><dt className="text-ink/60">الموبايل</dt><dd dir="ltr">{order.phone}</dd></div>
        <div className="flex justify-between gap-3"><dt className="text-ink/60">نوع الطلب</dt><dd>{order.order_type === 'pickup' ? 'استلام من المطعم' : 'توصيل'}</dd></div>
        {order.order_type !== 'pickup' && (
          <div className="flex justify-between gap-3"><dt className="text-ink/60">العنوان</dt><dd className="text-end">{order.address}</dd></div>
        )}
        <div className="flex justify-between gap-3"><dt className="text-ink/60">وقت الطلب</dt><dd>{when}</dd></div>
        <div className="flex justify-between gap-3"><dt className="text-ink/60">الحالة</dt><dd>{STATUS[order.status] || order.status}</dd></div>
      </dl>

      <ul className="divide-y divide-ink/10 border-y border-ink/10 text-sm">
        {items.map((it, n) => (
          <li key={n} className="space-y-0.5 py-2">
            <div className="flex justify-between gap-3 font-semibold">
              <span>{it.qty}× {it.name}</span>
              <span className="tabular-nums">{money(it.qty * Number(it.unit_price))}</span>
            </div>
            {(it.extras || []).map((x, i) => (
              <div key={i} className="flex justify-between gap-3 text-xs text-ink/70">
                <span>+ {x.name}</span>
                <span className="tabular-nums">{Number(x.price) > 0 ? money(it.qty * Number(x.price)) : 'مجاني'}</span>
              </div>
            ))}
          </li>
        ))}
      </ul>

      <dl className="mt-3 space-y-1 text-sm">
        <div className="flex justify-between"><dt className="text-ink/70">سعر الأصناف</dt><dd className="tabular-nums">{money(itemsSum)}</dd></div>
        {extrasSum > 0 && <div className="flex justify-between"><dt className="text-ink/70">الإضافات</dt><dd className="tabular-nums">{money(extrasSum)}</dd></div>}
        {order.order_type !== 'pickup' && <div className="flex justify-between"><dt className="text-ink/70">التوصيل</dt><dd className="tabular-nums">{fee > 0 ? money(fee) : 'مجاني'}</dd></div>}
        <div className="flex justify-between text-lg font-bold"><dt>الإجمالي</dt><dd className="tabular-nums">{money(order.total)}</dd></div>
      </dl>
      {order.notes && <p className="mt-2 text-xs text-ink/60">ملاحظات: {order.notes}</p>}
      <p className="mt-4 text-center text-xs text-ink/60">الدفع عند الاستلام · شكرًا لاختيارك {info?.name}</p>
    </article>
  );
}
