'use client';
import { useEffect, useMemo, useState } from 'react';
import { Phone, MapPin, Loader2, Radio, BellRing, ChefHat, ReceiptText, Banknote, Bike } from 'lucide-react';
import { courierCode } from '@/lib/courier';
import { createClient } from '@/lib/supabase/client';

const STATUSES = [
  ['pending', 'جديد', 'bg-saf/25 text-ink'],
  ['preparing', 'قيد التحضير', 'bg-sky-100 text-sky-900'],
  ['ready', 'جاهز', 'bg-mint text-ink'],
  ['delivered', 'تم التسليم', 'bg-emerald-100 text-emerald-900'],
  ['cancelled', 'ملغي', 'bg-coral/15 text-coral'],
];
const label = Object.fromEntries(STATUSES.map(([k, v, c]) => [k, [v, c]]));
const money = (n) => `${Number(n).toLocaleString('ar-EG')} ج.م`;
const SEL = '*, order_items(id, name, qty, unit_price, extras, extras_total)';

function beep() {
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)();
    const o = c.createOscillator(); const g = c.createGain();
    o.connect(g); g.connect(c.destination);
    o.frequency.value = 880; g.gain.value = 0.08;
    o.start(); o.stop(c.currentTime + 0.25);
  } catch { /* autoplay policy: ignore */ }
}

export default function OrdersBoard({ initial, couriers = [] }) {
  const [orders, setOrders] = useState(initial);
  const [busy, setBusy] = useState(null);
  const [filter, setFilter] = useState('all');
  const [live, setLive] = useState(false);
  const [err, setErr] = useState('');
  const courierById = useMemo(() => Object.fromEntries(couriers.map((c) => [c.id, c])), [couriers]);

  useEffect(() => {
    const supabase = createClient();
    const upsert = async (id, sound) => {
      const { data } = await supabase.from('orders').select(SEL).eq('id', id).single();
      if (!data) return;
      setOrders((o) => [data, ...o.filter((x) => x.id !== id)].sort((a, b) => b.created_at.localeCompare(a.created_at)));
      if (sound) beep();
    };
    const ch = supabase.channel('orders-live')
      // order_items are inserted right after the order row, so wait a moment
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'orders' }, (p) => setTimeout(() => upsert(p.new.id, true), 700))
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'orders' }, (p) => upsert(p.new.id, false))
      .subscribe((s) => setLive(s === 'SUBSCRIBED'));
    return () => { supabase.removeChannel(ch); };
  }, []);

  async function setStatus(id, status) {
    setBusy(id);
    const prev = orders;
    setOrders((o) => o.map((x) => (x.id === id ? { ...x, status } : x)));
    const res = await fetch(`/api/orders/${id}/status`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }),
    });
    if (!res.ok) setOrders(prev);
    setBusy(null);
  }

  async function assign(id, courierId) {
    setBusy(id); setErr('');
    const prev = orders;
    setOrders((o) => o.map((x) => (x.id === id ? { ...x, courier_id: courierId || null } : x)));
    const res = await fetch(`/api/orders/${id}/assign`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ courier_id: courierId || null }),
    });
    if (!res.ok) { const j = await res.json().catch(() => ({})); setErr(j.error || 'تعذّر تعيين المندوب'); setOrders(prev); }
    setBusy(null);
  }

  const stats = useMemo(() => {
    const day = new Date().toDateString();
    const today = orders.filter((o) => new Date(o.created_at).toDateString() === day && o.status !== 'cancelled');
    return {
      pending: orders.filter((o) => o.status === 'pending').length,
      preparing: orders.filter((o) => o.status === 'preparing').length,
      todayCount: today.length,
      todaySales: today.reduce((s, o) => s + Number(o.total), 0),
    };
  }, [orders]);

  const shown = filter === 'all' ? orders : orders.filter((o) => o.status === filter);
  const cards = [
    [BellRing, 'طلبات جديدة', stats.pending, 'bg-saf/25'],
    [ChefHat, 'قيد التحضير', stats.preparing, 'bg-sky-100'],
    [ReceiptText, 'طلبات اليوم', stats.todayCount, 'bg-mint'],
    [Banknote, 'مبيعات اليوم', money(stats.todaySales), 'bg-emerald-100'],
  ];

  return (
    <section>
      <div className="mb-3 flex items-center gap-2 text-sm">
        <Radio className={`h-4 w-4 ${live ? 'text-emerald-600' : 'text-ink/40'}`} aria-hidden />
        <span className={live ? 'text-emerald-700' : 'text-ink/50'}>{live ? 'تحديث لحظي شغال' : 'جاري الاتصال…'}</span>
      </div>
      {err && <p role="alert" className="mb-3 rounded-xl bg-coral/10 p-3 text-sm text-coral">{err}</p>}
      <div className="mb-5 grid grid-cols-2 gap-3 md:grid-cols-4">
        {cards.map(([Icon, t, v, bg]) => (
          <div key={t} className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-ink/10">
            <span className={`grid h-10 w-10 place-items-center rounded-xl ${bg}`}><Icon className="h-5 w-5" aria-hidden /></span>
            <p className="mt-3 text-2xl font-bold tabular-nums">{v}</p>
            <p className="text-sm text-ink/60">{t}</p>
          </div>
        ))}
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {[['all', 'الكل'], ...STATUSES.map(([k, v]) => [k, v])].map(([k, v]) => (
          <button key={k} onClick={() => setFilter(k)}
            className={`min-h-[44px] rounded-full px-4 text-sm font-semibold ${filter === k ? 'bg-ink text-white' : 'bg-white ring-1 ring-ink/15'}`}>
            {v}
          </button>
        ))}
      </div>
      {shown.length === 0 && <p className="py-16 text-center text-ink/60">مفيش طلبات.</p>}
      <ul className="grid gap-4 md:grid-cols-2">
        {shown.map((o) => (
          <li key={o.id} className={`rounded-2xl bg-white p-4 ring-1 ${o.status === 'pending' ? 'ring-2 ring-saf' : 'ring-ink/10'}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-bold">{o.customer_name || 'عميل'} <span className="text-xs font-normal text-ink/60">#{o.order_no}</span></p>
                <p className="text-xs text-ink/60">{new Date(o.created_at).toLocaleString('ar-EG')}</p>
              </div>
              <span className={`rounded-full px-3 py-1 text-xs font-semibold ${label[o.status][1]}`}>{label[o.status][0]}</span>
            </div>
            <p className="mt-2 flex items-center gap-2 text-sm"><Phone className="h-4 w-4" aria-hidden /> <a href={`tel:${o.phone}`} dir="ltr">{o.phone}</a></p>
            <p className="mt-1 flex items-center gap-2 text-sm"><MapPin className="h-4 w-4" aria-hidden /> {o.order_type === 'pickup' ? 'استلام من المطعم' : `${o.area ? `${o.area} · ` : ''}${o.address}`}</p>
            <ul className="my-3 divide-y divide-ink/10 text-sm">
              {(o.order_items || []).map((it) => (
                <li key={it.id} className="py-1">
                  <div className="flex justify-between"><span>{it.qty}× {it.name}</span><span>{money(it.qty * (Number(it.unit_price) + Number(it.extras_total || 0)))}</span></div>
                  {(it.extras || []).length > 0 && (
                    <p className="text-xs text-ink/60">+ {it.extras.map((x) => x.name).join('، ')}</p>
                  )}
                </li>
              ))}
            </ul>
            {o.order_type !== 'pickup' && (couriers.length > 0 || o.courier_id) && (() => {
              const cur = courierById[o.courier_id];
              const closed = ['delivered', 'cancelled'].includes(o.status);
              return (
                <div className="mb-2 flex flex-wrap items-center gap-2 text-sm">
                  <Bike className="h-4 w-4 shrink-0" aria-hidden />
                  {closed ? (
                    <span className="text-ink/70">{cur ? `المندوب: ${cur.name} (${courierCode(cur.no)})` : 'بدون مندوب'}</span>
                  ) : (
                    <select aria-label="المندوب" value={o.courier_id || ''} disabled={busy === o.id} onChange={(e) => assign(o.id, e.target.value)}
                      className="min-h-[44px] min-w-0 flex-1 rounded-xl border border-ink/20 bg-white px-3 text-sm">
                      <option value="">بدون مندوب</option>
                      {couriers.filter((c) => c.status === 'available' || c.id === o.courier_id).map((c) => (
                        <option key={c.id} value={c.id}>{c.name} ({courierCode(c.no)}){c.status !== 'available' ? ' - خارج الخدمة' : ''}</option>
                      ))}
                    </select>
                  )}
                </div>
              );
            })()}
            {o.order_type !== 'pickup' && Number(o.delivery_fee) > 0 && (
              <p className="mb-2 flex justify-between text-sm text-ink/70"><span>التوصيل</span><span>{money(o.delivery_fee)}</span></p>
            )}
            {o.notes && <p className="mb-2 rounded-lg bg-mint p-2 text-sm">{o.notes}</p>}
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold">{money(o.total)}</span>
              <div className="flex items-center gap-2">
                {busy === o.id && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                <select aria-label="حالة الطلب" value={o.status} disabled={o.status === 'cancelled'} onChange={(e) => setStatus(o.id, e.target.value)}
                  className="min-h-[44px] rounded-xl border border-ink/20 bg-white px-3 text-sm disabled:opacity-60">
                  {STATUSES.map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
