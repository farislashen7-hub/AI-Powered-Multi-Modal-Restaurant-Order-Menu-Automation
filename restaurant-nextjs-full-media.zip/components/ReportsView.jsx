'use client';
import { useCallback, useEffect, useState } from 'react';
import { Banknote, ReceiptText, XCircle, PackageCheck, AlertTriangle, Loader2, Trophy, MapPin, Clock, Truck, Store, Wallet } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

const money = (n) => `${Number(n || 0).toLocaleString('ar-EG')} ج.م`;
const RANGES = [['today', 'اليوم', 1], ['7', 'آخر 7 أيام', 7], ['30', 'آخر 30 يوم', 30]];

const TZ = 'Africa/Cairo';
const dayFmt = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' });
const hourFmt = new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', hourCycle: 'h23' });
const cairoDay = (d) => dayFmt.format(d); // 'YYYY-MM-DD' in Cairo time
const addDays = (day, n) => { const [y, m, d] = day.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); };
// instant of 00:00 Cairo on `day` (handles +02/+03 DST)
function cairoMidnight(day) {
  for (const off of ['+02:00', '+03:00']) {
    const t = new Date(`${day}T00:00:00${off}`);
    if (cairoDay(t) === day && hourFmt.format(t) === '00') return t;
  }
  return new Date(`${day}T00:00:00+02:00`);
}

function bounds(days) {
  const today = cairoDay(new Date());
  const fromDay = addDays(today, -(days - 1));
  const list = Array.from({ length: days }, (_, i) => addDays(fromDay, i));
  return { from: cairoMidnight(fromDay).toISOString(), to: cairoMidnight(addDays(today, 1)).toISOString(), list, today };
}

export default function ReportsView() {
  const [range, setRange] = useState('today');
  const [data, setData] = useState(null);
  const [stock, setStock] = useState([]);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    const supabase = createClient();
    const days = RANGES.find((r) => r[0] === range)[2];
    const { from, to } = bounds(days);
    setData(null); setErr('');
    const [rep, inv] = await Promise.all([
      supabase.rpc('sales_report', { p_from: from, p_to: to }),
      supabase.from('menu_items').select('id, name, stock_qty, low_stock_at').eq('track_stock', true).order('stock_qty'),
    ]);
    if (rep.error) return setErr('تعذّر تحميل التقرير. اتأكد إنك شغّلت migration_02_inventory_reports.sql');
    setData(rep.data);
    setStock((inv.data || []));
  }, [range]);

  useEffect(() => { load(); }, [load]);

  const days = RANGES.find((r) => r[0] === range)[2];
  const { list: dayList, today } = bounds(days);
  const byDay = Object.fromEntries((data?.daily || []).map((d) => [String(d.day).slice(0, 10), d]));
  const daily = dayList.map((day) => ({ day, revenue: Number(byDay[day]?.revenue || 0), orders: Number(byDay[day]?.orders || 0) }));
  const todayRow = daily.find((d) => d.day === today) || { revenue: 0, orders: 0 };
  const maxRev = Math.max(1, ...daily.map((d) => d.revenue));
  const low = stock.filter((s) => s.stock_qty <= s.low_stock_at);
  const cards = data && [
    [Banknote, 'إجمالي المبيعات', money(data.revenue), 'bg-emerald-100'],
    [PackageCheck, 'مبيعات تم تسليمها', money(data.delivered_revenue), 'bg-mint'],
    [ReceiptText, 'عدد الطلبات', data.orders, 'bg-saf/25'],
    [XCircle, 'طلبات ملغية', data.cancelled, 'bg-coral/15'],
  ];
  const topItem = data?.top_items?.[0];
  const areas = data?.top_areas || [];
  const topArea = areas.find((a) => a.area !== 'غير محدد') || null;
  const maxArea = Math.max(1, ...areas.map((a) => a.orders));
  const hours = Array.from({ length: 24 }, (_, h) => ({ h, n: Number((data?.by_hour || []).find((x) => x.hour === h)?.orders || 0) }));
  const peak = hours.reduce((m, x) => (x.n > m.n ? x : m), { h: 0, n: 0 });
  const maxHour = Math.max(1, peak.n);
  const typeMap = Object.fromEntries((data?.by_type || []).map((t) => [t.type, t]));
  const hourLabel = (h) => `${(h % 12 || 12).toLocaleString('ar-EG')} ${h < 12 ? 'ص' : 'م'}`;

  return (
    <section className="space-y-6">
      <div className="flex flex-wrap gap-2">
        {RANGES.map(([k, v]) => (
          <button key={k} onClick={() => setRange(k)} className={`min-h-[44px] rounded-full px-4 text-sm font-semibold ${range === k ? 'bg-ink text-white' : 'bg-white ring-1 ring-ink/15'}`}>{v}</button>
        ))}
      </div>

      {err && <p role="alert" className="rounded-xl bg-coral/10 p-3 text-sm text-coral">{err}</p>}
      {!data && !err && <Loader2 className="mx-auto h-6 w-6 animate-spin" aria-label="تحميل" />}

      {data && (
        <>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {cards.map(([Icon, t, v, bg]) => (
              <div key={t} className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-ink/10">
                <span className={`grid h-10 w-10 place-items-center rounded-xl ${bg}`}><Icon className="h-5 w-5" aria-hidden /></span>
                <p className="mt-3 text-2xl font-bold tabular-nums">{v}</p>
                <p className="text-sm text-ink/60">{t}</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-ink/60">المبيعات = كل الطلبات ما عدا الملغي.</p>

          <div className="grid gap-3 md:grid-cols-3">
            <div className="rounded-2xl bg-ink p-4 text-white">
              <p className="flex items-center gap-2 text-sm text-white/70"><Trophy className="h-4 w-4 text-saf" aria-hidden /> أكتر وجبة اتطلبت</p>
              {topItem ? (<><p className="mt-2 text-xl font-bold">{topItem.name}</p><p className="text-sm text-white/70 tabular-nums">{topItem.qty.toLocaleString('ar-EG')} مرة · {money(topItem.revenue)}</p></>) : <p className="mt-2 text-sm text-white/60">مفيش بيانات.</p>}
            </div>
            <div className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
              <p className="flex items-center gap-2 text-sm text-ink/60"><MapPin className="h-4 w-4 text-coral" aria-hidden /> أكتر منطقة اطلب منها</p>
              {topArea ? (<><p className="mt-2 text-xl font-bold">{topArea.area}</p><p className="text-sm text-ink/60 tabular-nums">{topArea.orders.toLocaleString('ar-EG')} طلب · {money(topArea.revenue)}</p></>) : <p className="mt-2 text-sm text-ink/60">مفيش مناطق مسجلة لسه.</p>}
            </div>
            <div className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
              <p className="flex items-center gap-2 text-sm text-ink/60"><Wallet className="h-4 w-4" aria-hidden /> متوسط قيمة الطلب</p>
              <p className="mt-2 text-xl font-bold tabular-nums">{money(data.avg_order)}</p>
              <p className="flex flex-wrap gap-x-3 text-sm text-ink/60">
                <span className="inline-flex items-center gap-1"><Truck className="h-4 w-4" aria-hidden /> توصيل: {Number(typeMap.delivery?.orders || 0).toLocaleString('ar-EG')}</span>
                <span className="inline-flex items-center gap-1"><Store className="h-4 w-4" aria-hidden /> استلام: {Number(typeMap.pickup?.orders || 0).toLocaleString('ar-EG')}</span>
              </p>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
              <h2 className="mb-3 flex items-center gap-2 font-bold"><MapPin className="h-4 w-4" aria-hidden /> المناطق الأكتر طلبًا</h2>
              {areas.length === 0 ? <p className="text-sm text-ink/60">مفيش طلبات توصيل في الفترة دي.</p> : (
                <ol className="space-y-2">
                  {areas.map((a, i) => (
                    <li key={a.area}>
                      <div className="flex items-center justify-between gap-2 text-sm">
                        <span className="min-w-0 truncate"><span className="me-2 tabular-nums text-ink/50">{(i + 1).toLocaleString('ar-EG')}.</span>{a.area}</span>
                        <span className="shrink-0 font-semibold tabular-nums">{a.orders.toLocaleString('ar-EG')} طلب</span>
                      </div>
                      <div className="mt-1 h-2 rounded-full bg-ink/10" aria-hidden><div className="h-2 rounded-full bg-saf" style={{ width: `${Math.max(4, Math.round((a.orders / maxArea) * 100))}%` }} /></div>
                    </li>
                  ))}
                </ol>
              )}
              {areas.some((a) => a.area === 'غير محدد') && <p className="mt-3 text-xs text-ink/60">&quot;غير محدد&quot; = طلبات قديمة اتسجلت قبل إضافة خانة المنطقة.</p>}
            </div>

            <div className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
              <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
                <h2 className="flex items-center gap-2 font-bold"><Clock className="h-4 w-4" aria-hidden /> ساعات الذروة</h2>
                {peak.n > 0 && <p className="text-sm text-ink/60">الأعلى: <span className="font-bold text-ink">{hourLabel(peak.h)}</span> ({peak.n.toLocaleString('ar-EG')} طلب)</p>}
              </div>
              {peak.n === 0 ? <p className="text-sm text-ink/60">مفيش بيانات.</p> : (
                <div className="flex h-36 items-end gap-[3px]" role="img" aria-label={`ساعة الذروة ${hourLabel(peak.h)}`}>
                  {hours.map((x) => (
                    <div key={x.h} className="flex h-full flex-1 flex-col items-center justify-end gap-1" title={`${hourLabel(x.h)}: ${x.n}`}>
                      <div className={`w-full rounded-t ${x.h === peak.h ? 'bg-ink' : 'bg-saf'}`} style={{ height: `${x.n ? Math.max(4, Math.round((x.n / maxHour) * 100)) : 2}px` }} />
                      <span className="text-[9px] text-ink/50 tabular-nums">{x.h % 3 === 0 ? x.h.toLocaleString('ar-EG') : ''}</span>
                    </div>
                  ))}
                </div>
              )}
              <p className="mt-2 text-xs text-ink/60">الأرقام تحت = الساعة (٠–٢٣) بتوقيت القاهرة.</p>
            </div>
          </div>

          <div className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
            <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
              <h2 className="font-bold">المبيعات يوميًا</h2>
              <p className="text-sm">
                <span className="text-ink/60">مبيعات اليوم: </span>
                <span className="font-bold tabular-nums">{money(todayRow.revenue)}</span>
                <span className="text-ink/60"> · {todayRow.orders} طلب</span>
              </p>
            </div>
            <div className="flex h-52 items-end gap-2 overflow-x-auto" role="img" aria-label="رسم بياني للمبيعات اليومية">
              {daily.map((d) => {
                const isToday = d.day === today;
                return (
                  <div key={d.day} className="flex h-full min-w-[52px] flex-1 flex-col items-center justify-end gap-1">
                    <span className="text-[11px] font-semibold tabular-nums">{d.revenue.toLocaleString('ar-EG')}</span>
                    <div className={`w-full rounded-t-lg ${isToday ? 'bg-ink' : 'bg-saf'}`} style={{ height: `${Math.max(4, Math.round((d.revenue / maxRev) * 120))}px` }} />
                    <span className={`text-[11px] ${isToday ? 'font-bold text-ink' : 'text-ink/60'}`}>
                      {isToday ? 'اليوم' : new Date(`${d.day}T12:00:00Z`).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short', timeZone: 'UTC' })}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
              <h2 className="mb-3 font-bold">الأكثر مبيعًا</h2>
              {data.top_items.length === 0 ? <p className="text-sm text-ink/60">مفيش بيانات.</p> : (
                <table className="w-full text-sm">
                  <thead><tr className="text-right text-ink/60"><th className="pb-2 font-medium">الصنف</th><th className="pb-2 font-medium">الكمية</th><th className="pb-2 font-medium">الإيراد</th></tr></thead>
                  <tbody className="divide-y divide-ink/10">
                    {data.top_items.map((t) => (<tr key={t.name}><td className="py-2">{t.name}</td><td>{t.qty}</td><td>{money(t.revenue)}</td></tr>))}
                  </tbody>
                </table>
              )}
            </div>

            <div className="rounded-2xl bg-white p-4 ring-1 ring-ink/10">
              <h2 className="mb-3 flex items-center gap-2 font-bold">تقرير المخزون {low.length > 0 && <span className="rounded-full bg-coral/15 px-2 py-0.5 text-xs text-coral">{low.length} ناقص</span>}</h2>
              {stock.length === 0 ? <p className="text-sm text-ink/60">مفيش أصناف متتبَّع مخزونها. فعّل "تتبّع المخزون" من صفحة المنيو.</p> : (
                <ul className="divide-y divide-ink/10 text-sm">
                  {stock.map((s) => {
                    const isLow = s.stock_qty <= s.low_stock_at;
                    return (
                      <li key={s.id} className="flex items-center justify-between py-2">
                        <span>{s.name}</span>
                        <span className={`inline-flex items-center gap-1 font-semibold ${isLow ? 'text-coral' : ''}`}>
                          {isLow && <AlertTriangle className="h-4 w-4" aria-hidden />}{s.stock_qty === 0 ? 'خلص' : s.stock_qty}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </>
      )}
    </section>
  );
}
