'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { MessageCircle, Bot, UserRound, Send, Search, Loader2, Radio, ArrowRight, Inbox, Headset, Power, Trash2 } from 'lucide-react';
import ConfirmDialog from '@/components/ConfirmDialog';
import { createClient } from '@/lib/supabase/client';

const FILTERS = [['all', 'الكل'], ['unread', 'غير مقروء'], ['human', 'تدخل بشري'], ['ai', 'المساعد الذكي']];
const SENDER = { customer: 'العميل', ai: 'المساعد الذكي', human: 'موظف' };

const byLast = (a, b) => String(b.last_message_at).localeCompare(String(a.last_message_at));
const title = (c) => c.contact_name || c.phone;
const initial = (c) => (c.contact_name ? [...c.contact_name.trim()][0] : '#');
const hhmm = (iso) => new Date(iso).toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit' });
function stamp(iso) {
  const d = new Date(iso); const now = new Date();
  if (d.toDateString() === now.toDateString()) return hhmm(iso);
  const y = new Date(now); y.setDate(now.getDate() - 1);
  if (d.toDateString() === y.toDateString()) return 'امبارح';
  return d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' });
}
const dayLabel = (iso) => {
  const d = new Date(iso); const now = new Date();
  if (d.toDateString() === now.toDateString()) return 'النهارده';
  return d.toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' });
};

function beep() {
  try {
    const c = new (window.AudioContext || window.webkitAudioContext)();
    const o = c.createOscillator(); const g = c.createGain();
    o.connect(g); g.connect(c.destination);
    o.frequency.value = 660; g.gain.value = 0.06;
    o.start(); o.stop(c.currentTime + 0.2);
  } catch { /* autoplay policy: ignore */ }
}

function ModeBadge({ ai }) {
  return ai
    ? <span className="inline-flex items-center gap-1 rounded-full bg-mint px-2 py-0.5 text-[11px] font-semibold text-ink"><Bot className="h-3 w-3" aria-hidden /> مساعد ذكي</span>
    : <span className="inline-flex items-center gap-1 rounded-full bg-saf/25 px-2 py-0.5 text-[11px] font-semibold text-ink"><UserRound className="h-3 w-3" aria-hidden /> تدخل بشري</span>;
}

export default function WhatsAppInbox({ initial: initialList, initialGlobalAi = true, loadError }) {
  const [convs, setConvs] = useState(initialList);
  const [selId, setSelId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [filter, setFilter] = useState('all');
  const [q, setQ] = useState('');
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [globalAi, setGlobalAi] = useState(initialGlobalAi); // false = human intervention on for ALL chats
  const [togglingGlobal, setTogglingGlobal] = useState(false);
  const [wipeOpen, setWipeOpen] = useState(false);
  const [wipeText, setWipeText] = useState('');
  const [wiping, setWiping] = useState(false);
  const [live, setLive] = useState(false);
  const [err, setErr] = useState(loadError || '');
  const selRef = useRef(null);
  const endRef = useRef(null);
  const sel = useMemo(() => convs.find((c) => c.id === selId) || null, [convs, selId]);
  const selAi = !!sel && globalAi && sel.ai_enabled; // effective: AI answers this chat only if global AND chat are on

  useEffect(() => { selRef.current = selId; }, [selId]);

  const markRead = useCallback((id) => {
    setConvs((l) => l.map((c) => (c.id === id ? { ...c, unread_count: 0 } : c)));
    fetch(`/api/whatsapp/conversations/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mark_read: true }),
    }).catch(() => {});
  }, []);

  const loadMessages = useCallback(async (id) => {
    const supabase = createClient();
    const { data, error } = await supabase.from('wa_messages')
      .select('id, conversation_id, direction, sender, body, created_at')
      .eq('conversation_id', id).order('created_at', { ascending: false }).limit(300);
    if (selRef.current !== id) return; // user switched chats meanwhile
    if (error) { setErr('تعذّر تحميل الرسائل'); return; }
    setMessages((data || []).reverse());
  }, []);

  const loadConvs = useCallback(async () => {
    const supabase = createClient();
    const { data } = await supabase.from('wa_conversations').select('*').order('last_message_at', { ascending: false }).limit(300);
    if (data) setConvs(data);
  }, []);

  // realtime + slow polling fallback
  useEffect(() => {
    const supabase = createClient();
    const ch = supabase.channel('wa-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wa_conversations' }, (p) => {
        if (p.eventType === 'DELETE') { setConvs((l) => l.filter((c) => c.id !== p.old.id)); return; }
        const row = p.new;
        // the open chat is being read right now: keep its badge at zero
        const next = row.id === selRef.current ? { ...row, unread_count: 0 } : row;
        setConvs((l) => [next, ...l.filter((c) => c.id !== row.id)].sort(byLast));
        if (row.id === selRef.current && row.unread_count > 0) markRead(row.id);
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'wa_settings' }, (p) => {
        if (typeof p.new?.ai_enabled === 'boolean') setGlobalAi(p.new.ai_enabled);
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'wa_messages' }, (p) => {
        const m = p.new;
        if (m.sender === 'customer') beep();
        if (m.conversation_id === selRef.current) {
          setMessages((l) => (l.some((x) => x.id === m.id) ? l : [...l, m]));
        }
      })
      .subscribe((s) => setLive(s === 'SUBSCRIBED'));
    const t = setInterval(() => {
      loadConvs();
      if (selRef.current) loadMessages(selRef.current);
    }, 30000);
    return () => { clearInterval(t); supabase.removeChannel(ch); };
  }, [loadConvs, loadMessages, markRead]);

  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [messages, selId]);

  function open(c) {
    setSelId(c.id); selRef.current = c.id;
    setMessages([]); setDraft(''); setErr('');
    setLoadingMsgs(true);
    loadMessages(c.id).finally(() => setLoadingMsgs(false));
    if (c.unread_count > 0) markRead(c.id);
  }

  async function setAi(enabled) {
    if (!sel || toggling || sel.ai_enabled === enabled) return;
    setToggling(true); setErr('');
    const prev = convs;
    setConvs((l) => l.map((c) => (c.id === sel.id ? { ...c, ai_enabled: enabled, human_since: enabled ? null : new Date().toISOString() } : c)));
    const res = await fetch(`/api/whatsapp/conversations/${sel.id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ai_enabled: enabled }),
    });
    if (!res.ok) { const j = await res.json().catch(() => ({})); setErr(j.error || 'تعذّر تغيير الوضع'); setConvs(prev); }
    setToggling(false);
  }

  async function toggleGlobal() {
    if (togglingGlobal) return;
    const next = !globalAi;
    setTogglingGlobal(true); setErr('');
    const res = await fetch('/api/whatsapp/global', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ai: next }),
    });
    if (!res.ok) { const j = await res.json().catch(() => ({})); setErr(j.error || 'تعذّر تغيير الوضع'); }
    else setGlobalAi(next);
    setTogglingGlobal(false);
  }

  async function wipeAll() {
    if (wiping || wipeText.trim() !== 'مسح') return;
    setWiping(true); setErr('');
    const res = await fetch('/api/admin/wipe-all', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ confirm: wipeText.trim() }),
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) setErr(j.error || 'تعذّر المسح');
    else { setConvs([]); setSelId(null); setMessages([]); setWipeOpen(false); setWipeText(''); }
    setWiping(false);
  }

  async function send() {
    const text = draft.trim();
    if (!sel || !text || sending || selAi) return;
    setSending(true); setErr('');
    const res = await fetch(`/api/whatsapp/conversations/${sel.id}/send`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }),
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok) { setErr(j.error || 'تعذّر إرسال الرسالة'); setSending(false); return; }
    setDraft('');
    setMessages((l) => (l.some((x) => x.id === j.message.id) ? l : [...l, j.message]));
    setConvs((l) => l.map((c) => (c.id === sel.id ? { ...c, last_message: text.slice(0, 200), last_message_at: j.message.created_at } : c)).sort(byLast));
    setSending(false);
  }

  const counts = useMemo(() => ({
    unread: convs.filter((c) => c.unread_count > 0).length,
    human: convs.filter((c) => !c.ai_enabled).length,
  }), [convs]);

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return convs.filter((c) => {
      if (filter === 'unread' && !(c.unread_count > 0)) return false;
      const ai = globalAi && c.ai_enabled;
      if (filter === 'human' && ai) return false;
      if (filter === 'ai' && !ai) return false;
      if (!needle) return true;
      return `${c.contact_name || ''} ${c.phone}`.toLowerCase().includes(needle);
    });
  }, [convs, filter, q, globalAi]);

  // messages grouped under a day heading
  const groups = useMemo(() => {
    const out = []; let last = '';
    for (const m of messages) {
      const k = new Date(m.created_at).toDateString();
      if (k !== last) { out.push({ type: 'day', key: `d-${m.id}`, label: dayLabel(m.created_at) }); last = k; }
      out.push({ type: 'msg', key: m.id, m });
    }
    return out;
  }, [messages]);

  return (
    <section aria-label="محادثات واتساب">
      <header className="mb-4 flex flex-wrap items-center gap-3">
        <h1 className="flex items-center gap-2 text-2xl font-bold"><MessageCircle className="h-6 w-6 text-[#25D366]" aria-hidden /> محادثات واتساب</h1>
        <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${live ? 'bg-mint text-ink' : 'bg-ink/10 text-ink/60'}`}>
          <Radio className="h-3.5 w-3.5" aria-hidden /> {live ? 'مباشر' : 'بيتحدّث كل 30 ثانية'}
        </span>
        <span className="text-sm text-ink/60">{convs.length.toLocaleString('ar-EG')} محادثة · {(globalAi ? counts.human : convs.length).toLocaleString('ar-EG')} تحت التدخل البشري</span>
        <button type="button" onClick={toggleGlobal} disabled={togglingGlobal} aria-pressed={!globalAi}
          className={`ms-auto flex min-h-[44px] items-center gap-2 rounded-xl px-4 text-sm font-bold text-white disabled:opacity-60 ${globalAi ? 'bg-red-600 hover:bg-red-700' : 'bg-red-700 ring-2 ring-red-300'}`}>
          {togglingGlobal ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : globalAi ? <Headset className="h-4 w-4" aria-hidden /> : <Power className="h-4 w-4" aria-hidden />}
          {globalAi ? 'تدخل بشري' : 'تدخل بشري شغال · شغّل المساعد الذكي'}
        </button>
        <button type="button" onClick={() => { setWipeText(''); setWipeOpen(true); }}
          className="flex min-h-[44px] items-center gap-2 rounded-xl border-2 border-red-600 px-4 text-sm font-bold text-red-700 hover:bg-red-50">
          <Trash2 className="h-4 w-4" aria-hidden /> مسح كل حاجة
        </button>
      </header>

      <ConfirmDialog
        open={wipeOpen}
        title="مسح كل رسائل وملفات واتساب؟"
        description="هيتمسح كل الرسائل وجهات الاتصال والملفات نهائيًا، ومفيش رجوع."
        confirmLabel="امسح كل حاجة"
        loading={wiping}
        onConfirm={wipeAll}
        onCancel={() => !wiping && setWipeOpen(false)}
      >
        <label className="block text-sm font-semibold">اكتب كلمة <b>مسح</b> للتأكيد
          <input value={wipeText} onChange={(e) => setWipeText(e.target.value)} dir="rtl"
            className="mt-1 w-full rounded-xl border border-ink/20 px-3 py-2" />
        </label>
      </ConfirmDialog>

      {err && <p role="alert" className="mb-3 rounded-xl bg-coral/10 px-4 py-3 text-sm font-semibold text-coral">{err}</p>}

      <div className="grid h-[calc(100vh-9rem)] min-h-[480px] overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-ink/10 lg:grid-cols-[340px_1fr]">
        {/* ===== conversations list ===== */}
        <div className={`${sel ? 'hidden lg:flex' : 'flex'} min-h-0 flex-col border-ink/10 lg:border-l`}>
          <div className="space-y-2 border-b border-ink/10 p-3">
            <label className="relative block">
              <span className="sr-only">بحث بالاسم أو الرقم</span>
              <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/40" aria-hidden />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث بالاسم أو الرقم"
                className="min-h-[44px] w-full rounded-xl border border-ink/20 bg-white ps-9 pe-3 text-sm" />
            </label>
            <div className="flex flex-wrap gap-1.5" role="group" aria-label="تصفية المحادثات">
              {FILTERS.map(([k, t]) => (
                <button key={k} type="button" aria-pressed={filter === k} onClick={() => setFilter(k)}
                  className={`min-h-[36px] rounded-full px-3 text-xs font-semibold transition ${filter === k ? 'bg-ink text-white' : 'bg-ink/5 text-ink/70 hover:bg-ink/10'}`}>
                  {t}{k === 'unread' && counts.unread > 0 ? ` (${counts.unread.toLocaleString('ar-EG')})` : ''}
                </button>
              ))}
            </div>
          </div>
          <ul className="min-h-0 flex-1 overflow-y-auto">
            {shown.length === 0 && (
              <li className="grid place-items-center gap-2 px-6 py-16 text-center text-sm text-ink/50">
                <Inbox className="h-8 w-8" aria-hidden />
                {convs.length === 0 ? 'لسه مفيش محادثات. أول رسالة من عميل هتظهر هنا.' : 'مفيش محادثات مطابقة.'}
              </li>
            )}
            {shown.map((c) => (
              <li key={c.id}>
                <button type="button" onClick={() => open(c)} aria-current={c.id === selId ? 'true' : undefined}
                  className={`flex min-h-[64px] w-full items-center gap-3 border-b border-ink/5 px-3 py-2.5 text-start transition hover:bg-ink/5 ${c.id === selId ? 'bg-mint/60' : ''}`}>
                  <span aria-hidden className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-ink/10 text-base font-bold text-ink">{initial(c)}</span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center justify-between gap-2">
                      <span className={`truncate text-sm ${c.unread_count > 0 ? 'font-bold' : 'font-semibold'}`} dir={c.contact_name ? undefined : 'ltr'}>{title(c)}</span>
                      <span className="shrink-0 text-[11px] text-ink/50">{stamp(c.last_message_at)}</span>
                    </span>
                    <span className="mt-0.5 flex items-center justify-between gap-2">
                      <span className="truncate text-xs text-ink/60">{c.last_message || '—'}</span>
                      {c.unread_count > 0 && (
                        <span className="grid h-5 min-w-[20px] shrink-0 place-items-center rounded-full bg-[#25D366] px-1.5 text-[11px] font-bold text-white" aria-label={`${c.unread_count} غير مقروء`}>
                          {c.unread_count.toLocaleString('ar-EG')}
                        </span>
                      )}
                    </span>
                    <span className="mt-1 block"><ModeBadge ai={globalAi && c.ai_enabled} /></span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* ===== chat ===== */}
        <div className={`${sel ? 'flex' : 'hidden lg:flex'} min-h-0 min-w-0 flex-col bg-[#f4efe6]`}>
          {!sel ? (
            <div className="grid flex-1 place-items-center p-6 text-center text-ink/50">
              <div><MessageCircle className="mx-auto mb-2 h-10 w-10" aria-hidden /><p className="text-sm">اختار محادثة من القايمة</p></div>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-3 border-b border-ink/10 bg-white px-3 py-2.5">
                <button type="button" onClick={() => setSelId(null)} aria-label="رجوع للمحادثات"
                  className="grid h-10 w-10 place-items-center rounded-xl hover:bg-ink/5 lg:hidden"><ArrowRight className="h-5 w-5" aria-hidden /></button>
                <span aria-hidden className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-ink/10 font-bold">{initial(sel)}</span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-bold">{sel.contact_name || 'عميل'}</p>
                  <p className="text-xs text-ink/60" dir="ltr" style={{ textAlign: 'start' }}>{sel.phone}</p>
                </div>
                {/* the two buttons: human takeover / smart assistant (hidden while the global switch holds the AI off) */}
                {!globalAi ? (
                  <span className="rounded-full bg-saf/25 px-3 py-1 text-xs font-semibold">تدخل بشري عام · المساعد متوقف</span>
                ) : (
                <div role="group" aria-label="مين بيرد على العميل" className="flex overflow-hidden rounded-xl ring-1 ring-ink/20">
                  <button type="button" aria-pressed={!sel.ai_enabled} onClick={() => setAi(false)} disabled={toggling}
                    className={`flex min-h-[44px] items-center gap-1.5 px-3 text-sm font-semibold transition disabled:opacity-60 ${!sel.ai_enabled ? 'bg-saf text-ink' : 'bg-white text-ink/70 hover:bg-ink/5'}`}>
                    <UserRound className="h-4 w-4" aria-hidden /> تدخل بشري
                  </button>
                  <button type="button" aria-pressed={sel.ai_enabled} onClick={() => setAi(true)} disabled={toggling}
                    className={`flex min-h-[44px] items-center gap-1.5 border-s border-ink/20 px-3 text-sm font-semibold transition disabled:opacity-60 ${sel.ai_enabled ? 'bg-ink text-white' : 'bg-white text-ink/70 hover:bg-ink/5'}`}>
                    {toggling ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Bot className="h-4 w-4" aria-hidden />} المساعد الذكي
                  </button>
                </div>
                )}
              </div>

              <p className={`px-4 py-1.5 text-xs font-semibold ${selAi ? 'bg-mint text-ink' : 'bg-saf/25 text-ink'}`} role="status">
                {selAi
                  ? 'المساعد الذكي بيرد على العميل ده تلقائي.'
                  : !globalAi
                  ? 'تدخل بشري عام: المساعد الذكي ساكت في كل المحادثات لحد ما تضغط زر "شغّل المساعد الذكي" فوق.'
                  : 'تدخل بشري: المساعد الذكي ساكت ومش هيرد لحد ما تضغط "المساعد الذكي".'}
              </p>

              <div className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
                {loadingMsgs && messages.length === 0 && <div className="grid place-items-center py-10"><Loader2 className="h-6 w-6 animate-spin text-ink/40" aria-label="جاري التحميل" /></div>}
                {!loadingMsgs && messages.length === 0 && <p className="py-10 text-center text-sm text-ink/50">مفيش رسائل.</p>}
                <ol className="flex flex-col gap-1.5">
                  {groups.map((g) => g.type === 'day' ? (
                    <li key={g.key} className="my-2 self-center rounded-full bg-white/80 px-3 py-0.5 text-[11px] font-semibold text-ink/60">{g.label}</li>
                  ) : (
                    <li key={g.key} className={`max-w-[85%] sm:max-w-[70%] ${g.m.direction === 'in' ? 'self-start' : 'self-end'}`}>
                      <div className={`rounded-2xl px-3 py-2 text-sm shadow-sm ${g.m.direction === 'in' ? 'rounded-ss-sm bg-white' : g.m.sender === 'ai' ? 'rounded-se-sm bg-mint' : 'rounded-se-sm bg-[#d9fdd3]'}`}>
                        {g.m.direction === 'out' && (
                          <p className="mb-0.5 flex items-center gap-1 text-[11px] font-bold text-ink/60">
                            {g.m.sender === 'ai' ? <Bot className="h-3 w-3" aria-hidden /> : <UserRound className="h-3 w-3" aria-hidden />}
                            {SENDER[g.m.sender]}
                          </p>
                        )}
                        <p className="whitespace-pre-wrap break-words">{g.m.body}</p>
                        <p className="mt-1 text-end text-[10px] text-ink/45">{hhmm(g.m.created_at)}</p>
                      </div>
                    </li>
                  ))}
                </ol>
                <div ref={endRef} />
              </div>

              <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex items-end gap-2 border-t border-ink/10 bg-white p-3">
                <label className="min-w-0 flex-1">
                  <span className="sr-only">رسالتك للعميل</span>
                  <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={1} maxLength={4000}
                    disabled={selAi || sending}
                    onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(); } }}
                    placeholder={selAi ? 'المساعد الذكي شغال. اضغط "تدخل بشري" عشان ترد بنفسك' : 'اكتب ردك (Enter للإرسال، Shift+Enter سطر جديد)'}
                    className="max-h-32 min-h-[44px] w-full resize-none rounded-xl border border-ink/20 bg-white px-3 py-2.5 text-sm disabled:bg-ink/5 disabled:text-ink/50" />
                </label>
                <button type="submit" disabled={selAi || sending || !draft.trim()} aria-label="إرسال"
                  className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#25D366] text-white transition disabled:opacity-40">
                  {sending ? <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> : <Send className="h-5 w-5 -scale-x-100" aria-hidden />}
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
